/*
 * Lock.h
 *
 *  Created on: Dec 1, 2019
 *      Author: bright
 */

#ifndef LIBENET_LOCK_H_
#define LIBENET_LOCK_H_

#include <assert.h>
#include <pthread.h>

namespace enet {

class Mutex {
public:
	Mutex() {
		pthread_mutex_init(&mMutex, NULL);
	}

	~Mutex() {
		pthread_mutex_destroy(&mMutex);
	}

	void Lock() {
		pthread_mutex_lock(&mMutex);
	}

	void UnLock() {
		pthread_mutex_unlock(&mMutex);
	}

	pthread_mutex_t* Instance() {
		return &mMutex;
	}

private:
	pthread_mutex_t mMutex;
};

class RWLock {
public:
	RWLock() {
		pthread_rwlock_init(&mRWLock, NULL);
	}

	~RWLock() {
		pthread_rwlock_destroy(&mRWLock);
	}

	void RLock() {
		pthread_rwlock_rdlock(&mRWLock);
	}

	void WLock() {
		pthread_rwlock_wrlock(&mRWLock);
	}

	void UnLock() {
		pthread_rwlock_unlock(&mRWLock);
	}

	pthread_rwlock_t* Instance() {
		return &mRWLock;
	}

private:
	pthread_rwlock_t mRWLock;
};


class LockTestOnce {
public:
	LockTestOnce() {
		mFlag = true;
	}

	bool TestOnce() {
		bool flag = mFlag;
		mFlag = false;
		return flag;
	}

private:
	bool mFlag;
};


class MutexGuard: public LockTestOnce {
public:
	MutexGuard(pthread_mutex_t* mutex) {
		assert(mutex != NULL);
		mMutexPtr = mutex;
		pthread_mutex_lock(mMutexPtr);
	}

	MutexGuard(Mutex& mutex) {
		mMutexPtr = mutex.Instance();
		pthread_mutex_lock(mMutexPtr);
	}

	~MutexGuard() {
		pthread_mutex_unlock(mMutexPtr);
	}

private:
	pthread_mutex_t* mMutexPtr;
};

enum LockType {
	RLOCK,
	WLOCK
};

class RWLockGuard: public LockTestOnce {
public:
	RWLockGuard(pthread_rwlock_t* rwlock, LockType lockType) {
		assert(rwlock != NULL);
		mRWLock = rwlock;
		if(lockType == RLOCK) {
			pthread_rwlock_rdlock(mRWLock);
		} else if(lockType == WLOCK) {
			pthread_rwlock_wrlock(mRWLock);
		}
	}

	RWLockGuard(RWLock& rwlock, LockType lockType) {
		mRWLock = NULL;
		mRWLock = rwlock.Instance();
		if(lockType == RLOCK) {
			pthread_rwlock_rdlock(mRWLock);
		} else if(lockType == WLOCK) {
			pthread_rwlock_wrlock(mRWLock);
		}
	}

	~RWLockGuard() {
		pthread_rwlock_unlock(mRWLock);
	}

private:
	pthread_rwlock_t* mRWLock;
};

#define LOCK(mutex) for(MutexGuard __lock_guard(mutex); __lock_guard.TestOnce(); )
#define RLOCK(rwLock) for(RWLockGuard __lock_guard(rwLock, RLOCK); __lock_guard.TestOnce(); )
#define WLOCK(rwLock) for(RWLockGuard __lock_guard(rwLock, WLOCK); __lock_guard.TestOnce(); )

}
#endif /* LIBENET_LOCK_H_ */
