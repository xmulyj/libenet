/*
 * Net.h
 *
 *  Created on: Nov 1, 2020
 *      Author: bright
 */

#ifndef INCLUDE_NET_H_
#define INCLUDE_NET_H_

#include <assert.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <list>
#include <map>
#include <string>
#include <vector>
using std::list;
using std::map;
using std::string;
using std::vector;

#include "NetConf.h"
#include "Spliter.h"
namespace enet {

class Net;
typedef uint64_t ConnId;
#define ConnIdToFd(connId) ((connId) & 0xFFFF)
#define FdToConnId(seq, fd) (((seq) << 32) | fd)

// 路由方式
typedef enum {
	ROUTE_NONE = -1,
	ROUTE_RR = 0,     // 轮询(一般用于无状态和负载均衡服务)
	ROUTE_HASH = 1,   // 取模(一般用于数据分片服务)
	ROUTE_RANGE = 2   // 范围(一般用于滚服扩容)
}RouteType;

// 下游节点Id
typedef struct {
	RouteType routeType;   // 路由方式
	uint32_t groupId;      // 集群id(最好从1开始)
	uint16_t groupIndex;   // 服务在集群中的索引号,集群中唯一
	uint16_t groupSize;    // 集群大小,ROUTE_HASH时必填
	uint32_t rangeFrom;    // 服务器根据key映射的范围[rangeFrom, rangeStop), ROUTE_HASH和ROUTE_RANGE时必填
	uint32_t rangeStop;

	string host;           // 下游地址
	uint32_t port;         // 下游端口
}DownNodeId;

class TaskHandler {
public:
	virtual ~TaskHandler() {}

	// 处理任务
	virtual bool OnTask(void *task) { return true; }
};

// 网络请求处理接口
class NetHandler: public TaskHandler {
public:
	virtual ~NetHandler() {}

	// 链接成功通知,连接下游成功后回调
	// 参数:
	//     net: 网络模块实例
	//     connectId: 当前链接id, 表示唯一的一个链接
	//     downNodeId: 下游节点
	//     userData: 添加下游节点时传入的用户数据
	virtual void OnConnected(Net *net, ConnId connId, const DownNodeId &downNodeId, void *userData) {};

	// 链接关闭通知
	// 参数:
	//     net: 网络模块实例
	//     connectId: 当前链接id, 表示唯一的一个链接
	virtual void OnClosed(Net *net, ConnId connId) {};

	// 连接空闲通知
	// 参数:
	//     net: 网络模块实例
	//     connectId: 当前链接id, 表示唯一的一个链接
	// 返回值:
	//     true: 允许连接保持存活
	//     false: 不允许连接保持存活
	virtual bool OnIdle(Net *net, ConnId connId) { return true; }

	// 定时器触发通知
	virtual void OnTimer() {}

	// 接收数据包
	// 参数:
	//     net: 网络模块实例
	//     connectId: 当前会话id, 表示一个链接. connectId相同, 表示数据来自同一个链接
	//     pack: 接收到的数据包
	//     readTIme: 包收到的时间(单位微秒)
	// 返回值:
	//     true: 接收成功
	//     false: 接收失败, connId表示的链接将变为无效, 后续在connId上的操作都将失败
	virtual bool OnPack(Net *net, ConnId connId, const string &pack, uint64_t readTime) = 0;
};

// 发送数据结果回调函数
// 参数:
//     net: 网络模块实例
//     connectId: 当前会话id, 表示一个链接
//     sendCode: 发送结果. 0发送成功, 其他发送错误码
//     pack: 发送的数据包
//     sendSize: 已经发送的长度
//     userData: net发送数据接口传入的用户数据
typedef enum {
	SEND_SUCC,            // 发送成功
	SEND_DOWNINVALID,     // 没有有效的下游节点
	SEND_CONNIDINVALID,   // 连接id无效
	SEND_IOERROR          // io错误
}SendCode;
const char* SendCodeStr(SendCode sendCode);
typedef void(*SendCallback)(Net *net, ConnId connId, SendCode sendCode, const string &pack, uint32_t sendSize, void *userData);

// 网络模块
class Net {
public:
	virtual ~Net() {}

	// 创建网络实例
	static Net* New(NetConf *conf);
	static Net* New(const char *confPath);

	// 删除网络实例
	static void Free(Net *net);

	// 获取网络配置实例
	NetConf* GetConf();

	// 设置处理上有请求的分包器和处理器
	// 参数:
	//     spliter: 数据包分包实例
	//     handler: 数据包处理器
	void SetUpSteamHandler(PackSpliter *spliter, NetHandler *handler, uint32_t timerMs = 0);
	NetHandler* UpStreamHandler();

	// 设置处理上有请求的分包器和处理器
	// 参数:
	//     spliter: 数据包分包实例
	//     handler: 数据包处理器
	//     timerMs: >0时添加定时器,每timerMs毫秒触发一次NetHandler::OnTimer
	void SetDownSteamHandler(PackSpliter *spliter, NetHandler *handler, uint32_t timerMs = 0);
	NetHandler* DownStreamHandler();

public:
	// 启动网络模块
	virtual void Start() = 0;

	// 停止网络模块
	virtual void Stop() = 0;

	// 停止监听端口
	virtual void StopListen() = 0;

	// 关闭链接
	// 参数:
	//     connId: 需要关闭的链接id
	virtual void CloseConn(ConnId connId) = 0;

	// 添加下游节点
	// 参数:
	//     downNodeId: 下游节点id
	//     userData: 传给NetHandler::
	// 返回值:
	//    <0: 存在相同id不同数值的其他节点
	//     0: 已有完全相同节点
	//     1: 添加新节点
	virtual int AddDownNode(const DownNodeId &downNodeId, void *userData = NULL) = 0;

	// 删除下游节点
	virtual void DelDownNode(uint32_t groupId, uint16_t groupIndex) = 0;

	// 给上游的请求发送回包数据
	// 参数:
	//     connId: 链接id
	//     pack: 发送的数据包(长度必须大于0)
	//     cb: 发送结果回调接口
	//     userData: 传给sendResult的用户数据
	virtual void SendRsp(ConnId connId, const string &pack, SendCallback cb = NULL, void *userData = NULL) = 0;

	// 发送请求给下游节点
	// 参数:
	//     groupId: 下游集群id
	//     key: 路由的key值
	//     pack: 发送的数据包
	//     cb: 发送结果回调函数
	//     userData: 传给cb的用户数据
	virtual void SendReq(uint32_t groupId, uint64_t key, const string &pack, SendCallback cb = NULL, void *userData = NULL) = 0;

	// 发送请求给下游节点
	// 参数:
	//     connId: 下游节点的连接Id
	//     key: 路由的key值
	//     pack: 发送的数据包
	//     cb: 发送结果回调函数
	//     userData: 传给cb的用户数据
	virtual void SendReq(ConnId connId, const string &pack, SendCallback cb = NULL, void *userData = NULL) = 0;

	// 注册服务
	virtual void KeepService(uint32_t waitMS = 100) = 0;

	// 接注册服务
	virtual void StopService() = 0;

protected:
	bool mConfOwn;
	NetConf *mConf;
	PackSpliter *mUpStreamSpliter;
	NetHandler *mUpStreamHandler;
	PackSpliter *mDownStreamSpliter;
	NetHandler *mDownStreamHandler;

	uint32_t mUpStreamTimerMs;
	uint32_t mDownStreamTimerMs;

	Net();
};


}
#endif /* INCLUDE_NET_H_ */
