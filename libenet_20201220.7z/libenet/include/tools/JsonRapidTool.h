/*
 * RapidJsonTool.h
 *
 *  Created on: 2018年7月15日
 *      Author: bright
 */

#ifndef LIBENET_TOOLS_RAPIDJSONTOOL_H_
#define LIBENET_TOOLS_RAPIDJSONTOOL_H_

#include <rapidjson/rapidjson.h>
#include <rapidjson/document.h>
#include <rapidjson/stringbuffer.h>
#include <rapidjson/writer.h>
#include <rapidjson/istreamwrapper.h>
#include <rapidjson/error/en.h>
using namespace rapidjson;
typedef Document JsonObj;

#include <string>
using std::string;
#include <fstream>
using std::ifstream;

namespace enet {
class RapidJsonTool {
public:
	static bool ParseFromFile(JsonObj& jsonObj, const char* fileName);
	static bool ParseFromStr(JsonObj& jsonObj, const char* str);
	static bool ParseFromStr(JsonObj& jsonObj, const char* str, unsigned int size);
	static bool ParseFromStr(JsonObj& jsonObj, const string& str);
	static bool WriteToFile(JsonObj& jsonObj, const char* fileName);
	static bool WriteToStr(JsonObj& jsonObj, string& str);
};

inline
bool RapidJsonTool::ParseFromFile(JsonObj& jsonObj, const char* fileName) {
	jsonObj.SetNull();
	ifstream ifs(fileName);
	IStreamWrapper isw(ifs);
	jsonObj.ParseStream(isw);
	return !jsonObj.HasParseError();
}

inline
bool RapidJsonTool::ParseFromStr(JsonObj& jsonObj, const char* str) {
	jsonObj.SetNull();
	jsonObj.Parse(str);
	return !jsonObj.HasParseError();
}

inline
bool RapidJsonTool::ParseFromStr(JsonObj& jsonObj, const char* str, unsigned int size) {
	jsonObj.SetNull();
	jsonObj.Parse(str, size);
	return !jsonObj.HasParseError();
}

inline
bool RapidJsonTool::ParseFromStr(JsonObj& jsonObj, const string& str) {
	return ParseFromStr(jsonObj, str.c_str());
}

inline
bool RapidJsonTool::WriteToFile(JsonObj& jsonObj, const char* fileName) {
	std::ofstream outFile;
	outFile.open(fileName);
	if (outFile.fail()) {
		return false;
	}
	string str;
	WriteToStr(jsonObj, str);
	outFile<<str;
	outFile.close();
	return true;
}

inline
bool RapidJsonTool::WriteToStr(JsonObj& jsonObj, string& str) {
	StringBuffer buffer;
	Writer<StringBuffer> writer(buffer);
	jsonObj.Accept(writer);
	str.assign(buffer.GetString());
	return true;
}

}
#endif /* LIBENET_TOOLS_RAPIDJSONTOOL_H_ */
