/*
 * MD5Tool.h
 *
 *  Created on: 2016年1月18日
 *      Author: bright
 */

#ifndef LIBENET_TOOLS_MD5TOOL_H_
#define LIBENET_TOOLS_MD5TOOL_H_

#include <stdio.h>
#include <string.h>
#include <openssl/md5.h>

#include <string>
using std::string;

namespace enet {

class MD5Tool {
public:
	//str:需要做md5的字符串
	//uppercase:输出结果是否大写,true大小,false小写
	static string MD5Sum(const string &src, bool uppercase=true);
	static string MD5Sum(const char*src, int size, bool uppercase=true);
};

inline
string MD5Tool::MD5Sum(const string &src, bool uppercase) {
	return MD5Sum(src.c_str(), src.size(), uppercase);
}

inline
string MD5Tool::MD5Sum(const char*src, int size, bool uppercase) {
	string dst = "";
	if(src == NULL || size <= 0) {
		return dst;
	}

	unsigned char digest[MD5_DIGEST_LENGTH];
	MD5((const unsigned char *)src, (size_t)size, digest);

	char buff[MD5_DIGEST_LENGTH * 2 + 1];
	const char *fmt = (uppercase ? "%02X" : "%02x");
	for(int i = 0; i < MD5_DIGEST_LENGTH; i++) {
		sprintf(buff + (i * 2), fmt, digest[i]);
	}
	buff[MD5_DIGEST_LENGTH * 2] = 0;

	dst = buff;
	return dst;
}


}
#endif /* LIBENET_TOOLS_MD5TOOL_H_ */
