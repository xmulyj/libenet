/*
 * NetThread.h
 *
 *  Created on: Nov 5, 2020
 *      Author: bright
 */

#ifndef SRC_NETTHREAD_H_
#define SRC_NETTHREAD_H_

#include <event.h>
#define EventBase struct event_base

#include <atomic>
#include <list>
#include <map>
#include <set>
using std::atomic_flag;
using std::list;
using std::map;
using std::set;


#include "Conn.h"
#include "Lock.h"
#include "Notifier.h"
#include "Thread.h"
namespace enet {


class XNet;
class NetThread: public Thread {
private:  // 线程接口实现
	// 唤醒线程
	void WakeUp();
	// 运行线程
	int Run();

public:
	NetThread();
	~NetThread();

	// 设置网络实例
	void SetNet(XNet *net, PackSpliter *spliter, NetHandler *handler, bool downStream);
	// 设置定时器
	void SetTimer(uint32_t timerMs);
	// 设置监听的端口
	void ListenAddr(string host, int port);

	// 关闭监听
	void StopListen();
	// 关闭重连
	void StopConnect();

	// 接收外部分发过来的链接
	void RecvConn(ConnId connId);
	// 关闭链接
	void CloseConn(ConnId connId);
	// 发送数据
	void SendData(ConnId connId, const string &pack, SendCallback cb, void *userData);

	// 添加下游节点
	int AddDownNode(const DownNodeId &downNodeId, void *userData);
	// 删除下游节点
	void DelDownNode(uint32_t groupId, uint16_t groupIndex);
	// 给下游节点发送数据
	void SendReq(uint32_t groupId, uint64_t key, const string &pack, SendCallback cb, void *userData);

// 监听端口模块
private:
	string mHost;
	int mPort;
	XNet* mNet;
	NetConf *mConf;
	PackSpliter *mSpliter;
	NetHandler *mHandler;
	bool mDownStream;    // 是否下游线程
	bool mStopConnect;   // 是否禁止断线重连

	int mListenFd;
	struct event mListenEvent;

	// 链接事件回调函数
	static void Callback_Listen(evutil_socket_t fd, short events, void* arg);
	// 接收链接
	void OnAccept(int fd);
	// 开始监听端口
	void BeginListen();

// 新链接处理模块
private:
	EventBase* mEventBase;              // 事件管理实例

	// 新连接通知
	atomic_flag mConnectSetLock = ATOMIC_FLAG_INIT;
	int mConnectSetIndex;               // 当前使用的链接队列index
	set<ConnId> mConnectSet[2];         // 链接队列
	Notifier<NetThread> mNotifyNewConnect;
	// 响应新的链接
	void OnNotifyNewConnect();

	// 关闭连接通知
	atomic_flag mConnectCloseSetLock = ATOMIC_FLAG_INIT;
	int mConnectCloseSetIndex;          // 当前使用的待关闭链接队列index
	set<ConnId> mConnectCloseSet[2];    // 待关闭链接集合
	Notifier<NetThread> mNotifyConnectClose;
	// 响应关闭链接
	void OnNotifyConnectClose();

	// 发送数据通知
	atomic_flag mSendListLock = ATOMIC_FLAG_INIT;
	int mSendListIndex;                 // 当前使用的发送队列index
	list<ConnId> mSendList[2];          // 发送队列
	Notifier<NetThread> mNotifySendData;
	void NotifySendData(ConnId connId);
	// 响应通知发送数据
	void OnNotifySendData();

	// 连接节点管理
	list<Conn*> mFreeConnList;          // 空闲链接实例
	map<ConnId, Conn*> mActiveConnMap;  // 活跃链接实例
	RWLock mActiveConnMapRWLock;


	// 获取空闲链接实例
	Conn* GetFreeConn();
	// 回收空闲链接实例
	void PutFreeConn(Conn *conn);
	// 清除空闲链接实例
	void ClearFreeConn();
	// 清除活跃链接实例
	void ClearActiveConn();


	// 初始化链接IO事件
	void InitConnEvent(Conn *conn);
	// 注册链接可读事件
	void AddConnReadEvent(Conn *conn);
	// 解注册链接可读事件
	void DelConnReadEvent(Conn *conn);
	// 注册链接可写事件
	void AddConnWriteEvent(Conn *conn);
	// 解注册链接可写事件
	void DelConnWriteEvent(Conn *conn);
	// 发送所有待发送的数据
	void FlushAll(Conn *conn);

	// 读数据,成功返回0
	int OnRead(int fd, Conn *conn);
	// 写数据,成功返回0
	int OnWrite(int fd, Conn *conn);
	// 处理超时,成功返回0
	int OnTimeout(int fd, Conn *conn);
	// 处理错误:关闭连接,清理数据等
	void OnClose(int fd, Conn *conn);
	// 链接读写事件回调方法
	static void Callback_Socket(evutil_socket_t fd, short events, void* arg);

	// 添加新的链接
	void AddNewConn(ConnId connId, const struct sockaddr_in &peerAddr);

private:
	// 下游节点相关:
	//    添加下游节点->添加到待连接集合->触发连接定时器,响应函数中进行连接(成功后方的连接-节点map,失败重新放到待连接集合等下次重试连接)
	//    删除节点时设置删除标记,连接关闭时/或者重连定时器回调方法中,根据该标记是否被设置判断是需要重连还是删除节点

	// 下游节点
	class DownNode {
	public:
		DownNodeId nodeId;    // 节点
		bool deleted;         // 是否已经删除掉
		ConnId connId;        // 连接id,0时表示未连接
		uint32_t tryTimes;    // 连接重试次数
		uint64_t nextTime;    // 下次进行连接的时间点,0立即连接
		void *userData;       // 用户数据

		DownNode(const DownNodeId &nodeId, void *userData) {
			this->nodeId = nodeId;
			this->deleted = false;
			this->connId = 0;
			this->tryTimes = 0;
			this->nextTime = 0;
			this->userData = userData;
		}
	};

	// 下游集群
	class DownGroup {
	public:
		DownGroup(uint32_t groupId, uint32_t groupSize, RouteType routeType) {
			this->groupId = groupId;
			this->groupSize = groupSize;
			this->routeType = routeType;
			this->downNodeArray.clear();
			this->nextIndex = 0;
		}

		uint32_t groupId;
		uint32_t groupSize;
		RouteType routeType;
		vector<DownNode*> downNodeArray;
		uint32_t nextIndex;
	};

	RWLock mDownGroupRWLock;
	map<uint32_t, DownGroup> mDownGroupMap;
	bool DownNodeTryDelete(DownNode *downNode);     // 如果节点被标记deleted,删除该节点返回true; 否则返回false
	void DownNodeDeleteNoLock(DownNode *downNode);  // 删除被标记为deleted的节点

	// 待连接节点集合
	Mutex mDownNodeConnectSetLock;                  // 队列保护锁
	set<DownNode*> mDownNodeConnectSet;             // 待连接下游节点集合
	map<ConnId, DownNode*> mConnDownNodeMap;        // connId->downNode
	set<ConnId> mWaitRealConnectSet;                // 等待真正连接成功
	void DownNodeConnect(DownNode *downNode, bool needNotify = false);
	void DownNodeClose(ConnId connId);

	// 下游节点连接定时器
	struct event mConnectTimer;	     // 连接定时回调函数
	void ActiveConnectTimer(uint32_t ms);  // 在ms毫秒激活连接定时器, ms=0时立即激活
	void OnConnectTimer();
	static void Callback_ConnectTimer(evutil_socket_t fd, short events, void *arg);

private:
	// 普通定时器
	struct event mTimer;
	static void Callback_Timer(evutil_socket_t fd, short events, void *arg);
};

}
#endif /* SRC_NETTHREAD_H_ */
