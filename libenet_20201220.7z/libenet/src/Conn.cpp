/*
 * Conn.cpp
 *
 *  Created on: Nov 6, 2020
 *      Author: bright
 */
#include "Conn.h"


#include "NetThread.h"
#include "TCPSocket.h"
#include "tools/TimeTool.h"
using namespace enet;

SendNode::SendNode(const string &pack, uint32_t sendSize, uint64_t sendTime, SendCallback cb, void *userData) {
	this->pack = pack;
	this->sendSize = sendSize;
	this->sendTime = sendTime;
	this->cb = cb;
	this->userData = userData;
}

void SendNode::SendFinished(Net *net, ConnId connId, SendCode sendCode) {
	if(cb != NULL) {
		cb(net, connId, sendCode, pack, sendSize, userData);
	}
}


Conn::Conn() {
	mConnId = 0;
	mThread = NULL;
	mActiveTs = 0;

	mBuff.clear();
	mPackReadTs = 0;
	mPackSize = 0;
	mPackUserData = NULL;
}

void Conn::Init(NetThread *thread, ConnId connId) {
	mThread = thread;
	mConnId = connId;
}

void Conn::Close() {
	int fd = ConnIdToFd(mConnId);
	TCPSocket::CloseSocket(fd);

	mConnId = 0;
	mThread = NULL;
	mActiveTs = 0;

	mBuff.clear();
	mPackReadTs = 0;
	mPackSize = 0;
	assert(mPackUserData == NULL);  // 用户数据必须已经处理掉
	assert(mSendList.size() == 0);  // 待发送数据必须已经处理掉
	assert(event_pending(&mReadEvent, EV_READ, NULL) == 0);    // 可读事件必须已经移除掉
	assert(event_pending(&mWriteEvent, EV_WRITE, NULL) == 0);  // 可写事件必须已经移除掉
}


