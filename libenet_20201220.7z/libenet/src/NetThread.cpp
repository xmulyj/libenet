/*
 * NetThread.cpp
 *
 *  Created on: Nov 5, 2020
 *      Author: bright
 */
#include "NetThread.h"


#include "NetImp.h"
#include "TCPSocket.h"
#include "tools/TimeTool.h"
using namespace enet;

#define LOGGER (mDownStream ? NetConf::downLogger : NetConf::netLogger)
#define S_LOGGER (thread->mDownStream ? NetConf::downLogger : NetConf::netLogger)

enum ErrCode {
	ERR_NONE = 0,
	ERR_PEER_CLOSE = 1,      // 对端关闭
	ERR_IO = 2,              // io读写错误
	ERR_TIMEOUT = 3,         // 空闲超时
	ERR_PACK_LEN = 4,        // 包长错误
	ERR_PACK_SPLIT = 5,      // 分包失败
	ERR_PROCESS = 6,         // 处理失败
	ERR_SEND_TIMEOUT = 7,    // 发送超时
	ERR_CONNECT = 8          // 连接失败
};

static const char *ErrorMsg[] = {
	"succ",
	"peer close gracefully",
	"io error",
	"idle timeout",
	"pack length limited",
	"pack split failed",
	"pack process failed",
	"send timeout",
	"connet failed"
};

// ConnID
static map<uint32_t, uint32_t> gConnSeqMap;
static std::atomic_flag gConnIdLock = ATOMIC_FLAG_INIT;
#define ATOMIC_LOCK(a) while(a.test_and_set(std::memory_order_acquire))
#define ATOMIC_UNLOCK(a) a.clear(std::memory_order_release)

// fd转为对应的为一的ConnId
static ConnId GenConnId(uint32_t fd) {
	ATOMIC_LOCK(gConnIdLock);
	uint64_t seq = gConnSeqMap[fd]++;
	ATOMIC_UNLOCK(gConnIdLock);
	return FdToConnId(seq, fd);
}


////////////// 线程接口方法  //////////////
// 唤醒线程
void NetThread::WakeUp() {
	event_base_loopexit(mEventBase, NULL);
	mNotifyConnectClose.Notify();
}

// 运行线程
int NetThread::Run() {
	LOG_INFO(LOGGER, "NetThread::Run|begin.index="<<Index()<<",name="<<Name());
	// 开始监听端口(只有第0个线程才有)
	BeginListen();
	// 循环处理数据
	while(true) {
		int ret = event_base_loop(mEventBase, 0);
		if(IsNeedStop()) {
			break;
		}
		LOG_ERROR(LOGGER, "NetThread::Run|event loop break and continue.ret="<<ret<<".index="<<Index()<<",name="<<Name());
		usleep(1000);
	}
	// 停止监听端口(只有第0个线程才有)
	StopListen();
	// 清理活跃的链接
	ClearActiveConn();
	// 清理空闲的链接
	ClearFreeConn();
	LOG_INFO(LOGGER, "NetThread::Run|end.index="<<Index()<<",name="<<Name());
	return 0;
}


//////////////////////////////////////////
NetThread::NetThread() {
	mHost = "";
	mPort = 0;
	mNet = NULL;
	mConf = NULL;
	mSpliter = NULL;
	mHandler = NULL;
	mDownStream = false;
	mStopConnect = false;
	mListenFd = 0;

	// 事件管理
	mEventBase = (EventBase*)event_base_new();
	assert(mEventBase != NULL);

	// 新链接通知机制
	mConnectSetIndex = 0;
	mNotifyNewConnect.Init(mEventBase, this, &NetThread::OnNotifyNewConnect);

	// 待关闭链接通知机制
	mConnectCloseSetIndex = 0;
	mNotifyConnectClose.Init(mEventBase, this, &NetThread::OnNotifyConnectClose);

	// 发送数据通知机制
	mSendListIndex = 0;
	mNotifySendData.Init(mEventBase, this, &NetThread::OnNotifySendData);

	// 初始化连接下游节点定时器
	int ret = event_assign(&mConnectTimer, mEventBase, -1, 0, Callback_ConnectTimer, (void*)this);
	assert(ret == 0);
}

NetThread::~NetThread() {
	event_base_free(mEventBase);
}

// 设置网络实例
void NetThread::SetNet(XNet *net, PackSpliter *spliter, NetHandler *handler, bool downStream) {
	assert(net != NULL && spliter != NULL && handler != NULL);
	mNet = net;
	mConf = net->GetConf();
	mSpliter = spliter;
	mHandler = handler;
	mDownStream = downStream;
}

// 设置定时器
void NetThread::SetTimer(uint32_t timerMs) {
	if(timerMs == 0) {
		return ;
	}
	// 初始定时器
	int ret = event_assign(&mTimer, mEventBase, -1, EV_PERSIST, Callback_Timer, (void*)mHandler);
	assert(ret == 0);

	struct timeval tv;
	tv.tv_sec = timerMs / 1000;
	tv.tv_usec = (timerMs % 1000) * 1000;
	ret = event_add(&mTimer, &tv);
	assert(ret == 0);
}

// 设置监听端口
void NetThread::ListenAddr(string host, int port) {
	mHost = host;
	mPort = port;
}

// 接收外部分发过来的链接
void NetThread::RecvConn(ConnId connId) {
	int fd = ConnIdToFd(connId);
	LOG_DEBUG(LOGGER, "NetThread::RecvConn|fd="<<fd<<",connId="<<connId);

	ATOMIC_LOCK(mConnectSetLock);
	mConnectSet[mConnectSetIndex].insert(connId);
	ATOMIC_UNLOCK(mConnectSetLock);
	mNotifyNewConnect.Notify();
}

// 关闭链接
void NetThread::CloseConn(ConnId connId) {
	int fd = ConnIdToFd(connId);
	LOG_DEBUG(LOGGER, "NetThread::CloseConn|fd="<<fd<<",connId="<<connId);

	ATOMIC_LOCK(mConnectCloseSetLock);
	mConnectCloseSet[mConnectCloseSetIndex].insert(connId);
	ATOMIC_UNLOCK(mConnectCloseSetLock);
	mNotifyConnectClose.Notify();
}

// 发送数据
void NetThread::SendData(ConnId connId, const string &pack, SendCallback cb, void *userData) {
	// 检查数据有效性
	assert(pack.size() > 0);
	// 检查connId有效性
	int fd = ConnIdToFd(connId);
	assert(fd > 0);
	// 查询链接是否存在
	Conn *conn = NULL;
	mActiveConnMapRWLock.RLock();
	map<ConnId, Conn*>::iterator it = mActiveConnMap.find(connId);
	if(it != mActiveConnMap.end()) {
		conn = it->second;
		assert(conn->mConnId == connId);
		ATOMIC_LOCK(conn->mSendListLock);  // 先加conn的锁再释放读锁,确保使用中不会在OnClose中被释放掉
	}
	mActiveConnMapRWLock.UnLock();
	// 判断链接是否有效
	if(conn == NULL) {
		if(cb != NULL) {
			cb(mNet, connId, SEND_CONNIDINVALID, pack, 0, userData);
		}
		return ;
	}
	// 连接活跃时间戳
	conn->mActiveTs = TimeTool::TimeUS();
	// 开始发送数据: 待发送队列为空时,尝试直接发送节点数据
	SendCode sendCode = SEND_SUCC;
	const char *data = pack.data();
	int remainSize = pack.size();
	int sendSize = 0;
	if(conn->mSendList.size() == 0) {
		sendSize = TCPSocket::Send(fd, data, remainSize);
		// 发送失败或者发送部分数据
		if(sendSize < 0) {
			sendSize = 0;
			if(!SOCKET_WOULDBLOCK) {  // 发送失败
				sendCode = SEND_IOERROR;
			}
		}
	}
	// 没有错误并且还有数据未发送完毕
	bool needNotify = false;
	if(sendCode == SEND_SUCC && sendSize < remainSize) {
		conn->mSendList.push_back(SendNode(pack, sendSize, conn->mActiveTs, cb, userData));
		needNotify = (conn->mSendList.size() == 1);
	}
	ATOMIC_UNLOCK(conn->mSendListLock);
	// 通知该连接上有数据等待发送
	if(needNotify == true) {
		if(pthread_self() == mThreadId) {
			AddConnWriteEvent(conn);
		} else {
			NotifySendData(connId);
		}
	}
	if(sendCode == SEND_SUCC) {
		LOG_DEBUG(LOGGER, "NetThread::SendData|sendCode="<<sendCode<<",errMsg="<<strerror(errno)<<",size="<<remainSize<<",sendSize="<<sendSize<<".fd="<<fd<<",connId="<<connId);
	} else {
		LOG_ERROR(LOGGER, "NetThread::SendData|sendCode="<<sendCode<<",errMsg="<<strerror(errno)<<",size="<<remainSize<<",sendSize="<<sendSize<<".fd="<<fd<<",connId="<<connId);
	}
	// 有回调接口时:发送完毕或者出错
	if(cb != NULL && (sendSize >= remainSize || sendCode != SEND_SUCC)) {
		cb(mNet, connId, sendCode, pack, sendSize, userData);
	}
}


// 接收连接事件回调函数
void NetThread::Callback_Listen(evutil_socket_t fd, short events, void* arg) {
	NetThread *thread = (NetThread*)arg;
	thread->OnAccept(fd);
}
// 接收连接
void NetThread::OnAccept(int fd) {
	while(true) {
		struct sockaddr_in peerAddr;
		int connFd = TCPSocket::Accept(fd, peerAddr);
		if(connFd < 0) {
			if(!SOCKET_WOULDBLOCK) {
				LOG_ERROR(LOGGER, "NetThread::OnAccept|accept failed.fd="<<fd<<",errMsg="<<strerror(errno));
			}
			break;
		}
		// 分发新链接
		ConnId connId = GenConnId(connFd);
		int index = connFd % mNet->mNetThreadPool.Size();
		LOG_DEBUG(LOGGER, "NetThread::OnAccept|fd="<<connFd<<",connId="<<connId<<",targetIndex="<<index);
		if(index == 0) {
			AddNewConn(connId, peerAddr);
		} else {
			mNet->mNetThreadPool.DispatchConn(connId);
		}
	}
}
// 开始监听端口
void NetThread::BeginListen() {
	if(mHost == "" || mPort <= 0) {
		return ;
	}
	int fd = TCPSocket::Listen(mHost.c_str(), mPort);
	if(fd <= 0) {
		LOG_ERROR(LOGGER, "NetThread::BeginListen|listen failed.host="<<mHost<<":"<<mPort<<",err="<<strerror(errno));
		usleep(300);
		assert(false);
	}
	int ret = event_assign(&mListenEvent, mEventBase, fd, EV_PERSIST | EV_READ, Callback_Listen, (void*)this);
	if(ret != 0) {
		LOG_ERROR(LOGGER, "NetThread::BeginListen|assign listen event failed and close listen socket.ret="<<ret<<".host="<<mHost<<":"<<mPort<<",fd="<<fd);
		TCPSocket::CloseSocket(fd);
		usleep(300);
		assert(false);
	}
	ret = event_add(&mListenEvent, NULL);
	if(ret != 0) {
		LOG_ERROR(LOGGER, "NetThread::BeginListen|add listen event failed and close listen socket.ret="<<ret<<".host="<<mHost<<":"<<mPort<<",fd="<<fd);
		TCPSocket::CloseSocket(fd);
		usleep(300);
		assert(false);
	}
	mListenFd = fd;
	LOG_INFO(LOGGER, "NetThread::BeginListen|listen succ.host="<<mHost<<":"<<mPort<<",listenFd="<<fd);
}
// 关闭监听
void NetThread::StopListen() {
	if(mListenFd > 0) {
		event_del(&(mListenEvent));
		TCPSocket::CloseSocket(mListenFd);
		LOG_INFO(LOGGER, "NetThread::StopListen|stop listen succ.host="<<mHost<<":"<<mPort<<",listenFd="<<mListenFd);
	}
	mListenFd = 0;
}
// 禁止断线后重连
void NetThread::StopConnect() {
	mStopConnect = true;
}


// 响应新的链接
void NetThread::OnNotifyNewConnect() {
	if(mDownStream == false) {
		// 获取新的链接列表
		int index = 0;
		ATOMIC_LOCK(mConnectSetLock);
		index = mConnectSetIndex;
		mConnectSetIndex = (mConnectSetIndex + 1) % 2;
		ATOMIC_UNLOCK(mConnectSetLock);

		LOG_DEBUG(LOGGER, "NetThread::OnNotifyNewConnect|connectListIndex="<<index<<",connectListSize="<<mConnectSet[index].size());
		for_each(mConnectSet[index].begin(), mConnectSet[index].end(), [this](ConnId connId) {
			int fd = ConnIdToFd(connId);
			struct sockaddr_in peerAddr = TCPSocket::GetSocketAddr(fd);
			AddNewConn(connId, peerAddr);
		});
		mConnectSet[index].clear();
	}else {
		// 添加新下游连接
		LOG_DEBUG(LOGGER, "NetThread::OnNotifyNewConnect|go to connect down nodes");
		// 触发重连定时器马上执行
		ActiveConnectTimer(0);
	}
}

// 响应关闭链接
void NetThread::OnNotifyConnectClose() {
	// 获取新的链接列表
	int index = 0;
	ATOMIC_LOCK(mConnectCloseSetLock);
	index = mConnectCloseSetIndex;
	mConnectCloseSetIndex = (mConnectCloseSetIndex + 1) % 2;
	ATOMIC_UNLOCK(mConnectCloseSetLock);

	LOG_DEBUG(LOGGER, "NetThread::OnNotifyCloseConnect|connectCloseListIndex="<<index<<",connectCloseListSize="<<mConnectCloseSet[index].size());
	for(set<ConnId>::iterator it = mConnectCloseSet[index].begin(); it != mConnectCloseSet[index].end(); ++it) {
		ConnId connId = *it;
		int fd = ConnIdToFd(connId);
		// 从活跃链接集合中查找conn
		Conn *conn = NULL;
		mActiveConnMapRWLock.RLock();  // 在io线程内,不会有别的线程修改mActiveConnMap,也可以不加锁
		map<ConnId, Conn*>::iterator mapIt = mActiveConnMap.find(connId);
		if(mapIt != mActiveConnMap.end()) {
			conn = mapIt->second;
		}
		mActiveConnMapRWLock.UnLock();
		if(conn != NULL) {
			LOG_DEBUG(LOGGER, "NetThread::OnNotifyCloseConnect|find active conn.fd="<<fd<<",connId="<<connId);
			OnClose(connId, conn);
		}
	}
	mConnectCloseSet[index].clear();
}

// 通知发送数据
void NetThread::NotifySendData(ConnId connId) {
	ATOMIC_LOCK(mSendListLock);
	mSendList[mSendListIndex].push_back(connId);
	ATOMIC_UNLOCK(mSendListLock);
	mNotifySendData.Notify();
}
// 响应通知发送数据
void NetThread::OnNotifySendData() {
	// 获取新的发送列表
	int index = 0;
	ATOMIC_LOCK(mSendListLock);
	index = mSendListIndex;
	mSendListIndex = (mSendListIndex + 1) % 2;
	ATOMIC_UNLOCK(mSendListLock);

	LOG_DEBUG(LOGGER, "NetThread::OnNotifySendData|sendListIndex="<<index<<",sendListSize="<<mSendList[index].size());
	for(list<ConnId>::iterator it = mSendList[index].begin(); it != mSendList[index].end(); ++it) {
		ConnId connId = *it;
		map<ConnId, Conn*>::iterator mapIt = mActiveConnMap.find(connId);
		if(mapIt == mActiveConnMap.end()) {
			continue;
		}
		Conn *conn = mapIt->second;
		if(conn->mSendList.size() == 0) {
			continue;
		}
		AddConnWriteEvent(conn);
	}
	mSendList[index].clear();
}

// 获取空闲链接实例
Conn* NetThread::GetFreeConn() {
	Conn *conn = NULL;
	if(mFreeConnList.size() > 0) {
		conn = mFreeConnList.front();
		mFreeConnList.pop_front();
	} else {
		conn = new Conn;
	}
	return conn;
}
// 回收空闲链接实例
void NetThread::PutFreeConn(Conn *conn) {
	if(conn == NULL) {
		return;
	}
	if(mFreeConnList.size() > 1024) {
		delete conn;
	} else {
		mFreeConnList.push_front(conn);
	}
}
// 清除空闲链接实例
void NetThread::ClearFreeConn() {
	while(!mFreeConnList.empty()) {
		delete mFreeConnList.front();
		mFreeConnList.pop_front();
	}
}
// 清除活跃链接实例
void NetThread::ClearActiveConn() {
	// 停止断线重连
	StopConnect();
	// 将剩余的数据写出去
	for(map<ConnId, Conn*>::iterator it = mActiveConnMap.begin(); it != mActiveConnMap.end(); ++it) {
		Conn *conn = it->second;
		// 删除事件
		DelConnReadEvent(conn);
		DelConnWriteEvent(conn);
		// 发送所有数据
		FlushAll(conn);
	}
	// sleep,尽量保证对方收到数据后再close链接
	usleep(500);
	// 开始close链接
	for(map<ConnId, Conn*>::iterator it = mActiveConnMap.begin(); it != mActiveConnMap.end(); ) {
		Conn *conn = it->second;
		conn->Close();
		// 当是下游连接时
		DownNodeClose(it->first);
		// 回调关闭接口
		mHandler->OnClosed(mNet, it->first);

		delete conn;
		mActiveConnMap.erase(it++);
	}
}


// 初始化链接IO事件
void NetThread::InitConnEvent(Conn *conn) {
	int fd = ConnIdToFd(conn->mConnId);
	int ret = 0;
	ret = event_assign(&conn->mReadEvent, mEventBase, fd, EV_PERSIST | EV_READ, Callback_Socket, conn);
	assert(ret == 0);
	ret = event_assign(&conn->mWriteEvent, mEventBase, fd, EV_WRITE, Callback_Socket, conn);  // wirte事件不设persist:一般一次可写事件时,数据都能发送完. 如果没有写完再调用event_add添加可写事件即可
	assert(ret == 0);
}
// 注册链接可读事件
void NetThread::AddConnReadEvent(Conn *conn) {
	const int IDLE_TIME = (!mDownStream ? mConf->idleTime : mConf->downIdleTime);
	// 设置timeout时间
	struct timeval tv;
	struct timeval *tvPtr = NULL;
	if(IDLE_TIME > 0) {
		tv.tv_sec = IDLE_TIME;
		tv.tv_usec = 0;
		tvPtr = &tv;
	}
	int ret = event_add(&conn->mReadEvent, tvPtr);
	assert(ret == 0);
}
// 解注册链接可读事件
void NetThread::DelConnReadEvent(Conn *conn) {
	event_del(&conn->mReadEvent);
}
// 注册链接可写事件
void NetThread::AddConnWriteEvent(Conn *conn) {
	if(event_pending(&conn->mWriteEvent, EV_WRITE, NULL) == 0) {
		int ret = event_add(&conn->mWriteEvent, NULL);
		assert(ret == 0);
	}
}
// 解注册链接可写事件
void NetThread::DelConnWriteEvent(Conn *conn) {
	event_del(&conn->mWriteEvent);
}

// 发送所有数据
void NetThread::FlushAll(Conn *conn) {
	int fd =  ConnIdToFd(conn->mConnId);
	const int MAX_WRITE_TIME_US = (!mDownStream ? mConf->writeTime * 1000000 : -1);

	SendCode sendCode = SEND_SUCC;
	conn->mActiveTs = TimeTool::TimeUS();

	ATOMIC_LOCK(conn->mSendListLock);
	bool empty = conn->mSendList.empty();
	ATOMIC_UNLOCK(conn->mSendListLock);
	while(!empty) {
		SendNode &sendNode = conn->mSendList.front();
		// 检查包发送是否超时(一个超时所有都超时, 或者一个io错误所有都io错误)
		if(sendCode == SEND_SUCC && (MAX_WRITE_TIME_US > 0 && conn->mActiveTs - sendNode.sendTime >= MAX_WRITE_TIME_US)) {
			sendCode = SEND_IOERROR;
		}
		// 发送数据
		if(sendCode == SEND_SUCC) {
			assert(sendNode.sendSize < sendNode.pack.size());
			const char *data = sendNode.pack.data();
			int reaminSize = sendNode.pack.size() - sendNode.sendSize;
			int sendSize = TCPSocket::SendAll(fd, data + sendNode.sendSize, reaminSize);
			if(sendSize >= reaminSize) {
				sendNode.sendSize += sendSize;
			} else {
				sendCode = SEND_IOERROR;
			}
		}
		sendNode.SendFinished(mNet, 0, sendCode);
		// 从队列中移除
		ATOMIC_LOCK(conn->mSendListLock);
		conn->mSendList.pop_front();
		empty = conn->mSendList.empty();
		ATOMIC_UNLOCK(conn->mSendListLock);
	}
}

// 读数据,成功返回0
int NetThread::OnRead(int fd, Conn *conn) {
	// 等待真正连接上对端
	if(mDownStream && mWaitRealConnectSet.find(conn->mConnId) != mWaitRealConnectSet.end()) {
		mWaitRealConnectSet.erase(conn->mConnId);
		int error;
		int len = sizeof(error);
		int ret = getsockopt(fd, SOL_SOCKET, SO_ERROR, (void*)&error, (socklen_t*)&len);
		if(ret < 0 || (ret == 0 && error != 0)) {
			errno = error;
			return ERR_CONNECT;
		}
		LOG_DEBUG(LOGGER, "NetThread::OnRead|wait real connect succ.ret="<<ret<<",error="<<error<<",connId="<<conn->mConnId);
		return ERR_NONE;
	}

	const int MAX_READ_TIME = (!mDownStream ? mConf->readTime : -1);   // 一个完整的数据包接收时间限制
	const int MAX_PACK_LEN = (!mDownStream ? mConf->maxPackLen : -1);  // 一个完整的数据包长度限制
	const int HEAD_SIZE = mSpliter->HeadSize();                  // 数据包头部长度, <=0表示头部长度未确定

	// 头部长度未确定下使用
	const int ADD_HEAD_SIZE = 256;    // 头部增长初始大小
	int addHeadSize = ADD_HEAD_SIZE;  // 数据包头长度未确定时(如http协议),预分配头部长度


	uint64_t nowTs = TimeTool::TimeUS();
	// conn->mActiveTs = TimeTool::TimeUS();
	bool socketHasData = true;
	while(socketHasData == true) {
		LOG_DEBUG(LOGGER, "NetThread::OnRead|cur pack info.size="<<conn->mBuff.size()<<",cap="<<conn->mBuff.capacity()<<",packSize="<<conn->mPackSize
				<<",maxPackLen="<<MAX_PACK_LEN<<".readTimeout="<<MAX_READ_TIME<<",readTs="<<conn->mPackReadTs/1000000
				<<".fd="<<fd<<",connId="<<conn->mConnId);
		// 准备工作
		if(conn->mPackSize <= 0) {
			// 未解析出包长,预分配包头空间
			if(HEAD_SIZE > 0) {
				if(conn->mBuff.capacity() < HEAD_SIZE) {
					conn->mBuff.reserve(HEAD_SIZE);
				}
			} else {
				if(conn->mBuff.capacity() - conn->mBuff.size() < addHeadSize) {
					conn->mBuff.reserve(conn->mBuff.capacity() + addHeadSize);
					addHeadSize *= 2;
				}
			}
		} else {
			// 已解析出包长
			// 检查包读取时间是否超时
			if(conn->mPackReadTs > 0 && MAX_READ_TIME > 0 && nowTs - conn->mPackReadTs > MAX_READ_TIME * 1000000) {
				return ERR_TIMEOUT;
			}
			// 预分配整个包的空间
			conn->mBuff.reserve(conn->mPackSize);
		}
		assert(conn->mBuff.size() < conn->mBuff.capacity());


		// 读取数据
		uint32_t curSize = conn->mBuff.size();
		conn->mBuff.resize(conn->mBuff.capacity());
		char *buff = (char*)conn->mBuff.data() + curSize;
		int readBuffSize = (conn->mPackSize > 0 ? (conn->mPackSize - curSize): (conn->mBuff.capacity() - curSize));
		int readSize = TCPSocket::Recv(fd, buff, readBuffSize);
		if(readSize == 0) {  // 对端关闭
			return ERR_PEER_CLOSE;
		} else if(readSize < 0) {  // 其他错误
			if(SOCKET_WOULDBLOCK) {
				conn->mBuff.resize(curSize);
				break;
			}
			return ERR_IO;
		}
		curSize += readSize;
		conn->mBuff.resize(curSize);
		socketHasData = readSize >= readBuffSize;  // 是否已经把缓冲区的数据都读出来了


		// 开始分包
		while(conn->mBuff.size() > 0) {
			// 如果还没有解析到包长,先解析包长
			if(conn->mPackSize == 0) {
				int packSize = 0;
				void *packUserData = conn->mPackUserData;
				conn->mPackUserData = NULL;
				SplitStatus splitStatus = mSpliter->Split(conn->mBuff.data(), conn->mBuff.size(), packSize, packUserData);
				if(splitStatus == SPLIT_FAIL) {
					if(packUserData != NULL) {
						mSpliter->Release(packUserData);
					}
					return ERR_PACK_SPLIT;
				} else if(splitStatus == SPLIT_WAIT) {
					conn->mPackUserData = packUserData;
					break;
				} else if(splitStatus == SPLIT_SUCC) {
					assert(packSize > 0);
					if(packUserData != NULL) {
						mSpliter->Release(packUserData);
					}
					if(MAX_PACK_LEN > 0 && packSize > MAX_PACK_LEN) {  // 检查最大包长
						return ERR_PACK_LEN;
					}
					conn->mPackSize = packSize;
				} else {
					assert(false);
				}
			}
			// 已经解析出包长
			// 数据还不完整
			if(conn->mBuff.size() < conn->mPackSize) {
				LOG_DEBUG(LOGGER, "NetThread::OnRead|need more pack data.size="<<conn->mBuff.size()<<",packeSize="<<conn->mPackSize<<".fd="<<fd<<",connId="<<conn->mConnId);
				break;
			}
			// 收到一个完整的数据包
			LOG_DEBUG(LOGGER, "NetThread::OnRead|full pack.size="<<conn->mBuff.size()<<",packSize="<<conn->mPackSize<<".fd="<<fd<<",connId="<<conn->mConnId);
			// 保存多余的数据
			string remainData;
			if(conn->mBuff.size() > conn->mPackSize) {
				remainData.assign(conn->mBuff.data() + conn->mPackSize, conn->mBuff.size() - conn->mPackSize);
				conn->mBuff.resize(conn->mPackSize);
			}
			// 设置包的读取时间
			if(conn->mPackReadTs == 0) {
				conn->mPackReadTs = nowTs;
			}
			if(mHandler->OnPack(mNet, conn->mConnId, conn->mBuff, conn->mPackReadTs) == false) {
				return ERR_PROCESS;
			}
			// 重置缓冲区,继续下一轮解析
			conn->mBuff = remainData;            // 重置缓冲区
			conn->mPackSize = 0;                 // 重置包大小
			conn->mPackReadTs = 0;               // 重置数据读取时间
			addHeadSize = ADD_HEAD_SIZE;         // 重置头部增长大小
		}  // while
	} // while


	// 还有残余数据,且是本轮新读入的
	if(conn->mBuff.size() > 0 && conn->mPackReadTs == 0) {
		conn->mPackReadTs = nowTs;
	}
	return ERR_NONE;
}
// 写数据,成功返回0
int NetThread::OnWrite(int fd, Conn *conn) {
	const int MAX_WRITE_TIME_US = (!mDownStream ? mConf->writeTime * 1000000: -1);
	int errCode = SEND_SUCC;

	LOG_DEBUG(LOGGER, "NetThread::OnWrite|begin.sendListSize="<<conn->mSendList.size()<<".fd="<<fd<<",connId="<<conn->mConnId);
	conn->mActiveTs = TimeTool::TimeUS();

	ATOMIC_LOCK(conn->mSendListLock);
	bool empty = conn->mSendList.empty();
	ATOMIC_UNLOCK(conn->mSendListLock);
	while(!empty) {
		SendNode &sendNode = conn->mSendList.front();
		// 检查包发送是否超时
		if(MAX_WRITE_TIME_US > 0 && conn->mActiveTs - sendNode.sendTime >= MAX_WRITE_TIME_US) {
			return ERR_IO;
		}
		// 发送数据
		assert(sendNode.sendSize < sendNode.pack.size());
		const char *data = sendNode.pack.data();
		int reaminSize = sendNode.pack.size() - sendNode.sendSize;
		int sendSize = TCPSocket::Send(fd, data + sendNode.sendSize, reaminSize);
		if(sendSize <= 0) {
			if(SOCKET_WOULDBLOCK) {
				break;
			}
			return ERR_IO;
		}
		sendNode.sendSize += sendSize;
		// 发送完成,从队列中移除
		if(sendNode.sendSize >= sendNode.pack.size()) {
			sendNode.SendFinished(mNet, conn->mConnId, SEND_SUCC);
			ATOMIC_LOCK(conn->mSendListLock);
			conn->mSendList.pop_front();
			empty = conn->mSendList.empty();
			ATOMIC_UNLOCK(conn->mSendListLock);
		}
		// 每一轮发送时间控制
		uint64_t nowTs = TimeTool::TimeUS();
		if(nowTs - conn->mActiveTs > 20000) {  // 控制发送时间: 20ms
			break;
		}
	}
	// 还有数据时继续添加可写事件(添加的可写事件没有添加persist标记,触发后会自动移除,所以如果还有数据需要重新注册)
	if(!empty) {
		AddConnWriteEvent(conn);
	}
	return ERR_NONE;
}
// 处理超时,成功返回0
int NetThread::OnTimeout(int fd, Conn *conn) {
	// 检查是否真正空闲超时(在设置时间内可能没有收到数据,但是有发送数据,不算空闲超时)
	const int IDLE_TIME = (!mDownStream ? mConf->idleTime : mConf->downIdleTime);

	uint64_t now = TimeTool::TimeUS();
	if(now - conn->mActiveTs >= IDLE_TIME * 1000000) {
		LOG_DEBUG(LOGGER, "NetThread::OnTimeout|idleTimeout="<<IDLE_TIME<<",activeTs="<<conn->mActiveTs/1000000<<".fd="<<fd<<",connId="<<conn->mConnId);
		bool keepAlive = mHandler->OnIdle(mNet, conn->mConnId);
		return (keepAlive ? ERR_NONE : ERR_TIMEOUT);
	}
	LOG_DEBUG(LOGGER, "NetThread::OnTimeout|active already.idleTimeout="<<IDLE_TIME<<",activeTs="<<conn->mActiveTs/1000000<<".fd="<<fd<<",connId="<<conn->mConnId);
	return ERR_NONE;
}
// 处理错误:关闭连接,清理数据等
void NetThread::OnClose(int fd, Conn *conn) {
	ConnId connId = conn->mConnId;
	LOG_INFO(LOGGER, "NetThread::OnClose|sendListSie="<<conn->mSendList.size()<<".fd="<<fd<<",connId="<<connId);

	// 从活跃链接集合中移除
	// 获取写锁之前,SendData中可能有1个线程正在使用conn的锁,n个线程获得读锁并且正在等待锁conn的锁
	// 获得写锁之时,SendData中所有在等待conn锁的n个线程都释放了读锁,并且至少有n-1个线程都处理完不再占有conn的锁,至多一个线程正在使用conn的锁
	// 释放写锁之后,SendData中不会有新的线程找得到该conn,并且最多只有一个线程在使用conn的锁
	mActiveConnMapRWLock.WLock();
	mActiveConnMap.erase(connId);
	mActiveConnMapRWLock.UnLock();

	// 如果这里获得conn的锁,则SendData中已经没有线程在使用conn的锁了
	ATOMIC_LOCK(conn->mSendListLock);
	bool empty = conn->mSendList.empty();
	ATOMIC_UNLOCK(conn->mSendListLock);
	while(!empty) {
		SendNode &sendNode = conn->mSendList.front();
		sendNode.SendFinished(mNet, connId, SEND_IOERROR);
		// 这里已经不需要再加锁了
		conn->mSendList.pop_front();
		empty = conn->mSendList.empty();
	}
	// 处理接收数据
	if(conn->mPackUserData != NULL) {
		mSpliter->Release(conn->mPackUserData);
		conn->mPackUserData = NULL;
	}
	// 删除事件
	DelConnReadEvent(conn);
	DelConnWriteEvent(conn);
	// 关闭链接
	conn->Close();
	// 回收链接
	PutFreeConn(conn);

	// 当是下游连接时
	DownNodeClose(connId);

	// 回调关闭接口
	mHandler->OnClosed(mNet, connId);
}

// 链接读写事件回调方法
void NetThread::Callback_Socket(evutil_socket_t fd, short events, void* arg) {
	Conn *conn = (Conn*)arg;
	assert(conn != NULL);
	int realFd = ConnIdToFd(conn->mConnId);
	assert(realFd == fd);
	NetThread *thread = conn->mThread;
	assert(thread != NULL);
	LOG_DEBUG(S_LOGGER, "NetThread::Callback_Socket|events="<<events<<".fd="<<fd<<",connId="<<conn->mConnId);

	// 处理各种事件
	if(events & EV_CLOSED) {
		thread->OnClose(fd, conn);
		return;
	}
	if(events & EV_TIMEOUT) {
		int ret = thread->OnTimeout(fd, conn);
		if(ret != 0) {
			LOG_WARN(S_LOGGER, "NetThread::Callback_Socket|timeout ret="<<ret<<"("<<ErrorMsg[ret]<<").fd="<<fd<<",connId="<<conn->mConnId);
			thread->OnClose(fd, conn);
		}
		return;
	}
	if(events & EV_READ) {
		int ret = thread->OnRead(fd, conn);
		if(ret != 0) {
			LOG_WARN(S_LOGGER, "NetThread::Callback_Socket|read ret="<<ret<<"("<<ErrorMsg[ret]<<":"<<strerror(errno)<<").fd="<<fd<<",connId="<<conn->mConnId);
			thread->OnClose(fd, conn);
			return;
		}
	}
	if(events & EV_WRITE) {
		int ret = thread->OnWrite(fd, conn);
		if(ret != 0) {
			LOG_WARN(S_LOGGER, "NetThread::Callback_Socket|write ret="<<ret<<"("<<ErrorMsg[ret]<<":"<<strerror(errno)<<").fd="<<fd<<",connId="<<conn->mConnId);
			thread->OnClose(fd, conn);
			return;
		}
	}
}

// 添加新的链接
void NetThread::AddNewConn(ConnId connId, const struct sockaddr_in &peerAddr) {
	// 分配conn实例并初始化/初始化读写事件/注册读事件
	Conn *conn = GetFreeConn();
	conn->Init(this, connId);
	InitConnEvent(conn);
	AddConnReadEvent(conn);
	// 添加到活跃链接集合
	assert(mActiveConnMap.find(connId) == mActiveConnMap.end());
	mActiveConnMapRWLock.WLock();
	mActiveConnMap[connId]= conn;
	mActiveConnMapRWLock.UnLock();
	LOG_INFO(LOGGER, "NetThread::AddNewConn|new connect.peer="<<inet_ntoa(peerAddr.sin_addr)<<":"<<ntohs(peerAddr.sin_port)<<".fd="<<ConnIdToFd(connId)<<",connId="<<connId<<".thread="<<Name());
}



/////////////////////
// 下游管理相关
bool DownNodeEquals(const DownNodeId &downNodeId0, const DownNodeId &downNodeId1) {
	if(downNodeId0.groupId != downNodeId1.groupId
		|| downNodeId0.groupIndex != downNodeId1.groupIndex
		|| downNodeId0.routeType != downNodeId1.routeType) {
		return false;
	}
	if(downNodeId0.routeType == ROUTE_HASH || downNodeId0.routeType == ROUTE_RANGE) {
		if(downNodeId0.routeType == ROUTE_HASH && downNodeId0.groupSize != downNodeId1.groupSize) {
			return false;
		}
		if(downNodeId0.rangeFrom != downNodeId1.rangeFrom || downNodeId0.rangeStop != downNodeId1.rangeStop) {
			return false;
		}
	}
	if(downNodeId0.host != downNodeId1.host || downNodeId0.port != downNodeId1.port) {
		return false;
	}
	return true;
}
int NetThread::AddDownNode(const DownNodeId &downNodeId, void *userData) {
	int ret = 0;
	DownNode *newDownNode = NULL;

	mDownGroupRWLock.WLock();
	do {
		map<uint32_t, DownGroup>::iterator it = mDownGroupMap.find(downNodeId.groupId);
		if(it == mDownGroupMap.end()) {
			if(downNodeId.routeType == ROUTE_HASH && downNodeId.groupSize == 0) {
				LOG_ERROR(LOGGER, "NetThread::AddDownNode|group size invalid(hash route).groupSize="<<downNodeId.groupSize
						<<",groupId="<<downNodeId.groupId<<",groupIndex="<<downNodeId.groupIndex<<",host="<<downNodeId.host<<",port="<<downNodeId.port);
				ret = -1;
				break;
			}
			DownGroup downGroup(downNodeId.groupId, downNodeId.groupSize, downNodeId.routeType);
			std::pair<map<uint32_t, DownGroup>::iterator, bool> insertRet = mDownGroupMap.insert(std::make_pair(downNodeId.groupId, downGroup));
			assert(insertRet.second == true);
			it = insertRet.first;
		}
		DownGroup &downGroup = it->second;
		// 检查节点数据一致性
		if(downGroup.routeType != downNodeId.routeType) {
			LOG_ERROR(LOGGER, "NetThread::AddDownNode|routeType inconsistent.curRouteType="<<downGroup.routeType<<",newRouteType="<<downNodeId.routeType
					<<",groupId="<<downNodeId.groupId<<",groupIndex="<<downNodeId.groupIndex<<",host="<<downNodeId.host<<",port="<<downNodeId.port);
			ret = -2;  // 路由方式不一致
			break;
		}
		if(downGroup.routeType == ROUTE_HASH && downGroup.groupSize != downNodeId.groupSize) {  // hash路由下groupSize不能改变(除非停服修改)
			LOG_ERROR(LOGGER, "NetThread::AddDownNode|group size inconsistent(hash route).curGroupSize="<<downGroup.groupSize<<",newGroupSize="<<downNodeId.groupSize
					<<",groupId="<<downNodeId.groupId<<",groupIndex="<<downNodeId.groupIndex<<",host="<<downNodeId.host<<",port="<<downNodeId.port);
			ret = -3;  // hash路由方式下,groupSize不一致
			break;
		}
		// 添加节点: 如果是被标记删除后又重新添加进来的节点,则恢复使用(去掉deleted标记), 否则新添加一个节点
		bool recovery = false;
		for(uint32_t i = 0; i < downGroup.downNodeArray.size(); ++i) {
			DownNode *downNode = downGroup.downNodeArray[i];
			if(downNode->nodeId.groupIndex != downNodeId.groupIndex) {
				// 不是相同index的节点:
				//    1) 如果有deleted标记,忽略不检查
				//    2) 如果没有deleted标记, 并且不是range路由方式, 忽略不检查, 否则需要检查range有没有交叉

				// 已经标记为已删除,忽略
				if(downNode->deleted == true) {
					continue;
				}
				// 不是range的路由方式,忽略
				if(downGroup.routeType != ROUTE_RANGE) {
					continue;
				}
				// 检查新节点range是否有效,以及是否跟已有节点的range是否有交叠
				if((downNodeId.rangeFrom < downNodeId.rangeStop) && (downNodeId.rangeStop <= downNode->nodeId.rangeFrom || downNodeId.rangeFrom >= downNode->nodeId.rangeStop)) {
					continue;
				}
				LOG_ERROR(LOGGER, "NetThread::AddDownNode|range invalid or crossover(range route).curGroupIndex="<<downNode->nodeId.groupIndex
						<<",curRange=["<<downNode->nodeId.rangeFrom<<","<<downNode->nodeId.rangeStop<<"),newGroupIndex="<<downNodeId.groupIndex
						<<",newRange=["<<downNodeId.rangeFrom<<","<<downNodeId.rangeStop<<"),groupId="<<downNodeId.groupId<<",host="<<downNodeId.host<<",port="<<downNodeId.port);
				ret = -4;  // range路由方式下,和其他节点的range有交叉
				break;
			} else {
				// 相同index的节点:
				//     1) 数据完全一样, 恢复使用
				//     2) 数据不一样: 如果没有deleted标记, 则有别的相同id节点,返回错误; 否则保留该节点(保证正在传输的数据不会丢失,该节点在close时会被删除掉),重新创建新的

				// 存在使用中的相同节点,恢复使用
				if(DownNodeEquals(downNodeId, downNode->nodeId)) {
					LOG_DEBUG(LOGGER, "NetThread::AddDownNode|down node is same.groupId="<<downNodeId.groupId<<",groupIndex="<<downNode->nodeId.groupIndex
							<<",curHost="<<downNode->nodeId.host<<",curPort="<<downNode->nodeId.port);
					downNode->deleted = false;
					recovery = true;
					break;
				}
				if(downNode->deleted == false) {
					LOG_ERROR(LOGGER, "NetThread::AddDownNode|down node is using.groupId="<<downNodeId.groupId<<",groupIndex="<<downNode->nodeId.groupIndex
							<<",curRouteType="<<downNode->nodeId.routeType<<",curGroupSize="<<downNode->nodeId.groupSize
							<<",curRangeFrom="<<downNode->nodeId.rangeFrom<<",curRangeStop="<<downNode->nodeId.rangeStop
							<<",curHost="<<downNode->nodeId.host<<",curPort="<<downNode->nodeId.port
							<<",newRouteType="<<downNodeId.routeType<<",newGroupSize="<<downNodeId.groupSize
							<<",newRangeFrom="<<downNodeId.rangeFrom<<",newRangeStop="<<downNodeId.rangeStop
							<<",newHost="<<downNodeId.host<<",newPort="<<downNodeId.port);
					ret = -5;  // 有相同节点id,但数值不一样的节点正在使用中
					break;
				}
			}
		}
		if(ret != 0) {
			break;
		}
		// 添加新的下游节点
		if(recovery == false) {
			LOG_INFO(LOGGER, "NetThread::AddDownNode|add new down node.groupId="<<downNodeId.groupId<<",groupIndex="<<downNodeId.groupIndex<<",groupSize="<<downNodeId.groupSize
					<<",routeType="<<downNodeId.routeType<<",range=["<<downNodeId.rangeFrom<<","<<downNodeId.rangeStop<<"),host="<<downNodeId.host<<",port="<<downNodeId.port);
			newDownNode = new DownNode(downNodeId, userData);
			downGroup.downNodeArray.push_back(newDownNode);
		}
	} while(false);
	mDownGroupRWLock.UnLock();
	// 通知线程进行连接
	if(ret == 0 && newDownNode != NULL) {
		DownNodeConnect(newDownNode, true);
		return 1;
	}
	return ret;
}
void NetThread::DelDownNode(uint32_t groupId, uint16_t groupIndex) {
	ConnId connId = 0;
	mDownGroupRWLock.WLock();
	do {
		map<uint32_t, DownGroup>::iterator it = mDownGroupMap.find(groupId);
		if(it == mDownGroupMap.end()) {
			LOG_DEBUG(LOGGER, "NetThread::DelDownNode|down group not exist.groupId="<<groupId);
			break;
		}
		DownGroup &downGroup = it->second;
		bool find = false;
		for(uint32_t i = 0; i < downGroup.downNodeArray.size(); ++i) {
			DownNode *downNode = downGroup.downNodeArray[i];
			if(downNode->nodeId.groupIndex == groupIndex) {
				LOG_INFO(LOGGER, "NetThread::DelDownNode|set down node deleted.groupId="<<groupId<<",groupIndex="<<groupIndex);
				downNode->deleted = true;
				find = true;
				break;
			}
		}
		if(find == false) {
			LOG_DEBUG(LOGGER, "NetThread::DelDownNode|down node not exist.groupId="<<groupId<<",groupIndex="<<groupIndex);
		}
	} while(false);
	mDownGroupRWLock.UnLock();
}
bool NetThread::DownNodeTryDelete(DownNode *downNode) {
	mDownGroupRWLock.WLock();
	bool hasDeleted = downNode->deleted;
	if(downNode->deleted == true) {
		DownNodeDeleteNoLock(downNode);
	}
	mDownGroupRWLock.UnLock();
	return hasDeleted;
}
void NetThread::DownNodeDeleteNoLock(DownNode *downNode) {
	assert(downNode->deleted == true);
	map<uint32_t, DownGroup>::iterator it = mDownGroupMap.find(downNode->nodeId.groupId);
	if(it != mDownGroupMap.end()) {
		DownGroup &downGroup = it->second;
		uint32_t size = downGroup.downNodeArray.size();
		for(uint32_t i = 0; i < size; ++i) {
			if(downGroup.downNodeArray[i] != downNode) {
				continue;
			}
			if(i < size -1) {
				downGroup.downNodeArray[i] = downGroup.downNodeArray[size -1];
			}
			downGroup.downNodeArray.pop_back();
			break;
		}
		// 该集群没有节点时,删除该集群
		if(downGroup.downNodeArray.empty()) {
			mDownGroupMap.erase(it);
		}
	}
	delete downNode;
}
void NetThread::SendReq(uint32_t groupId, uint64_t key, const string &pack, SendCallback cb, void *userData) {
	SendCode sendCode = SEND_SUCC;
	ConnId connId = 0;
	uint16_t groupIndex = 0;
	string host;
	uint32_t port;

	mDownGroupRWLock.RLock();
	do {
		map<uint32_t, DownGroup>::iterator it = mDownGroupMap.find(groupId);
		if(it == mDownGroupMap.end()) {
			LOG_DEBUG(LOGGER, "NetThread::SendReq|down group not exist.groupId="<<groupId);
			sendCode = SEND_DOWNINVALID;
			break;
		}
		DownGroup &downGroup = it->second;
		if(downGroup.downNodeArray.empty()) {
			LOG_DEBUG(LOGGER, "NetThread::SendReq|down group empty.groupId="<<groupId);
			sendCode = SEND_DOWNINVALID;
			break;
		}
		if(downGroup.routeType == ROUTE_RR) {
			int count = downGroup.downNodeArray.size();
			while(--count >= 0) {
				uint32_t index = downGroup.nextIndex++ % downGroup.downNodeArray.size();
				DownNode *downNode = downGroup.downNodeArray[index];
				if(downNode->deleted == false && downNode->connId > 0) {
					connId = downNode->connId;
					groupIndex = downNode->nodeId.groupIndex;
					host = downNode->nodeId.host;
					port = downNode->nodeId.port;
					break;
				}
			}
		} else if(downGroup.routeType == ROUTE_HASH) {
			uint32_t index = key % downGroup.groupSize;
			for(uint32_t i = 0; i < downGroup.downNodeArray.size(); ++i) {
				DownNode *downNode = downGroup.downNodeArray[i];
				if(downNode->deleted == false && downNode->connId > 0
					&& downNode->nodeId.groupIndex == index) {
					connId = downNode->connId;
					groupIndex = downNode->nodeId.groupIndex;
					host = downNode->nodeId.host;
					port = downNode->nodeId.port;
					break;
				}
			}
		} else if(downGroup.routeType == ROUTE_RANGE) {
			for(uint32_t i = 0; i < downGroup.downNodeArray.size(); ++i) {
				DownNode *downNode = downGroup.downNodeArray[i];
				if(downNode->deleted == false && downNode->connId > 0 && downNode->nodeId.rangeFrom <= key && key < downNode->nodeId.rangeStop) {
					connId = downNode->connId;
					groupIndex = downNode->nodeId.groupIndex;
					host = downNode->nodeId.host;
					port = downNode->nodeId.port;
					break;
				}
			}
		}
		if(connId == 0) {
			LOG_DEBUG(LOGGER, "NetThread::SendReq|no find active down node.groupId="<<groupId<<",routeType="<<downGroup.routeType<<",key="<<key);
			sendCode = SEND_DOWNINVALID;
			break;
		}
	} while(false);
	mDownGroupRWLock.UnLock();

	if(connId > 0) {
		SendData(connId, pack, cb, userData);
	} else {
		if(cb != NULL) {
			cb(mNet, connId, sendCode, pack, 0, userData);
		}
	}
}


/////////////////////
// 连接下游节点
void NetThread::DownNodeConnect(DownNode *downNode, bool needNotify) {
	LOG_DEBUG(LOGGER, "NetThread::DownNodeConnect|groupId="<<downNode->nodeId.groupId<<",groupIndex="<<downNode->nodeId.groupIndex);
	// 放到待连接集合
	downNode->tryTimes = 0;
	downNode->nextTime = 0;
	mDownNodeConnectSetLock.Lock();
	mDownNodeConnectSet.insert(downNode);
	mDownNodeConnectSetLock.UnLock();

	if(needNotify == true) {
		// 通知有新的下游节点需要进行连接
		mNotifyNewConnect.Notify();
	}
}
void NetThread::DownNodeClose(ConnId connId) {
	// 判断是不是下游节点的连接
	if(mConnDownNodeMap.find(connId) == mConnDownNodeMap.end()) {
		return ;
	}
	DownNode *downNode = mConnDownNodeMap[connId];
	// 删除connId->downNode的关系
	mConnDownNodeMap.erase(connId);
	// 清除connId
	downNode->connId = 0;
	// 确定是重新连接还是删除节点信息: 如果没有deleted标记重新连接,否则删除节点
	bool reconnect = false;
	mDownGroupRWLock.WLock();
	if(downNode->deleted == false) {  // 需要重新连接
		if(mStopConnect == false) {
			reconnect = true;
			DownNodeConnect(downNode);
		}
	} else {  // 需要删除节点
		DownNodeDeleteNoLock(downNode);
	}
	mDownGroupRWLock.UnLock();
	// 需要重新连接时,触发重连定时器马上执行
	if(reconnect == true) {
		ActiveConnectTimer(0);
	}
}


/////////////////////
// 连接定时器
void NetThread::ActiveConnectTimer(uint32_t ms) {
	if(ms == 0) {
		event_active(&mConnectTimer, EV_TIMEOUT, 0);
	} else {
		struct timeval tv;
		tv.tv_sec = ms / 1000;
		tv.tv_usec = (ms % 1000) * 1000;
		int ret = event_add(&mConnectTimer, &tv);
		assert(ret == 0);
	}
}
void NetThread::OnConnectTimer() {
	// 获取已经到时需要进行连接的下游节点列表
	set<DownNode*> connectSet;
	uint64_t nowTs = TimeTool::TimeMS();
	uint64_t nextTs = 0;
	mDownNodeConnectSetLock.Lock();
	for(set<DownNode*>::iterator it = mDownNodeConnectSet.begin(); it != mDownNodeConnectSet.end(); ) {
		if((*it)->nextTime <= nowTs) {
			connectSet.insert(*it);
			mDownNodeConnectSet.erase(it++);
			continue;
		}
		if(nextTs == 0 || (*it)->nextTime < nextTs) {
			nextTs = (*it)->nextTime;
		}
		++it;
	}
	mDownNodeConnectSetLock.UnLock();
	// 重新连接待连接下游节点集合
	for(set<DownNode*>::iterator it = connectSet.begin(); it != connectSet.end(); ++it) {
		DownNode *downNode = *it;
		// 如果标记为deleted了,就不需要重连了
		bool hasDeleted = DownNodeTryDelete(downNode);
		if(hasDeleted == true) {
			continue;
		}
		// 重新连接
		int fd = TCPSocket::Connect(downNode->nodeId.host.c_str(), downNode->nodeId.port);
		if(fd <= 0) {  // 连接失败
			downNode->tryTimes++;
			downNode->nextTime = nowTs + 1000;
			if(downNode->tryTimes <= 10) {
				downNode->nextTime = nowTs + downNode->tryTimes * 100;
			}
			if(nextTs == 0 || downNode->nextTime < nextTs) {
				nextTs = downNode->nextTime;
			}
			mDownNodeConnectSetLock.Lock();
			mDownNodeConnectSet.insert(downNode);
			mDownNodeConnectSetLock.UnLock();
			LOG_ERROR(LOGGER, "NetThread::OnConnectTimer|connect down node fail and wait to retry.groupId="<<downNode->nodeId.groupId<<",groupIndex="<<downNode->nodeId.groupIndex
					<<",retryTimes="<<downNode->tryTimes<<",host="<<downNode->nodeId.host<<",port="<<downNode->nodeId.port);
			continue;
		} else {  // 连接成功
			ConnId connId = GenConnId(fd);
			if(errno == EINPROGRESS) {
				mWaitRealConnectSet.insert(connId);
			}
			LOG_INFO(LOGGER, "NetThread::OnConnectTimer|connect down node succ.groupId="<<downNode->nodeId.groupId<<",groupIndex="<<downNode->nodeId.groupIndex
					<<",retryTimes="<<downNode->tryTimes<<",host="<<downNode->nodeId.host<<",port="<<downNode->nodeId.port
					<<",fd="<<fd<<",connId="<<connId);
			downNode->connId = connId;
			downNode->tryTimes = 0;
			downNode->nextTime = 0;
			mConnDownNodeMap[connId] = downNode;
			// 添加新的连接
			struct sockaddr_in peerAddr = TCPSocket::GetSocketAddr(fd);
			AddNewConn(connId, peerAddr);
			// 调用连接成功回调方法
			mHandler->OnConnected(mNet, connId, downNode->nodeId, downNode->userData);
		}
	}
	// 还有需要重连的,添加连接定时器
	if(nextTs != 0) {
		ActiveConnectTimer(nextTs - nowTs);
	}
}
void NetThread::Callback_ConnectTimer(evutil_socket_t fd, short events, void *arg) {
	((NetThread*)arg)->OnConnectTimer();
}


// 普通定时器
void NetThread::Callback_Timer(evutil_socket_t fd, short events, void *arg) {
	((NetHandler*)arg)->OnTimer();
}
