/*
 * NetImp.cpp
 *
 *  Created on: Nov 24, 2020
 *      Author: bright
 */
#include "NetImp.h"

#include "NetThread.h"
using namespace enet;

XNet::XNet() {
	mActive = false;
	// 下游线程
	mDownStreamThread = new NetThread();
	mDownStreamThread->Init(-1, "DownThread");
}

XNet::~XNet() {
	delete mDownStreamThread;
}

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
void XNet::Start() {
	LOG_INFO(UP_LOGGER, "Net::Start|begin==========");

	assert(mConf != NULL);
	assert(mActive == false);
	mActive = true;
	signal(SIGPIPE, SIG_IGN);  // 忽略SIGPIPE信号,防止往已经关闭的socket写数据时导致程序停止

	bool emptyRun = true;
	// 工作者线程池
	if(mConf->workerThreadNum > 0) {
		LOG_INFO(UP_LOGGER, "Net::Start|start worker thread pool.workerThreadNum="<<mConf->workerThreadNum<<",queueSize="<<mConf->queueSize);
		assert(mConf->queueSize > 0);
		assert(mUpStreamHandler != NULL || mDownStreamHandler != NULL);
		// 代理上游处理器
		if(mUpStreamHandler != NULL) {
			mUpStreamHandler = mWorkers.ProxyUpStreamHandler(mUpStreamHandler);
		}
		// 代理下游处理器
		if(mDownStreamHandler != NULL) {
			mDownStreamHandler = mWorkers.ProxyDownStreamHandler(mDownStreamHandler);
		}
		mWorkers.Start(mConf->workerThreadNum, mConf->queueSize);
	}
	// 下游请求管理线程
	if(mDownStreamSpliter != NULL && mDownStreamHandler != NULL) {
		LOG_INFO(UP_LOGGER, "Net::Start|start downstream manager");
		emptyRun = false;
		mDownStreamThread->SetNet(this, mDownStreamSpliter, mDownStreamHandler, true);
		mDownStreamThread->SetTimer(mDownStreamTimerMs);
		mDownStreamThread->Start();
		// 确定线程运行中
		int checkCount = 30;
		while(!mDownStreamThread->IsRunning() && checkCount-- > 0) {
			usleep(100);
		}
		assert(mDownStreamThread->IsRunning());
	}
	// 上游请求线程池
	if(mConf->netThreadNum > 0) {
		LOG_INFO(UP_LOGGER, "Net::Start|start upstream net thread pool.netThreadNum="<<mConf->netThreadNum);
		emptyRun = false;
		assert(mUpStreamSpliter != NULL && mUpStreamHandler != NULL);
		mNetThreadPool.Prepare(mConf->netThreadNum);
		// 监听端口
		((NetThread*)mNetThreadPool.mThreads[0])->ListenAddr(mConf->listenIP, mConf->listenPort);
		((NetThread*)mNetThreadPool.mThreads[mConf->netThreadNum -1 ])->SetTimer(mUpStreamTimerMs);
		// 设置线程数据
		for(int i = 0; i < mNetThreadPool.mThreads.size(); ++i) {
			((NetThread*)mNetThreadPool.mThreads[i])->SetNet(this, mUpStreamSpliter, mUpStreamHandler, false);
		}
		// 启动所有线程
		mNetThreadPool.Start(1);
	}
	assert(emptyRun == false);
	// 初始化服务注册
	LOG_INFO(UP_LOGGER, "Net::Start|init service register");
	mRegister.Init(this, mConf);

	LOG_INFO(UP_LOGGER, "Net::Start|end==========");
}

void XNet::Stop() {
	LOG_INFO(UP_LOGGER, "Net::Stop|begin##########");
	mActive = false;

	LOG_INFO(UP_LOGGER, "Net::Stop|stop upstream net thread pool");
	mNetThreadPool.Stop();

	LOG_INFO(UP_LOGGER, "Net::Stop|stop downstream net thread pool");
	mDownStreamThread->Stop();
	mDownStreamThread->Wait();

	LOG_INFO(UP_LOGGER, "Net::Stop|stop workers thread pool");
	mWorkers.Stop();

	LOG_INFO(UP_LOGGER, "Net::Stop|end##########");
}

void XNet::StopListen() {
	return ((NetThread*)mNetThreadPool.mThreads[0])->StopListen();
}

void XNet::CloseConn(ConnId connId) {
	assert(mActive);
	int index = ConnIdToFd(connId) % mNetThreadPool.mThreads.size();
	return ((NetThread*)mNetThreadPool.mThreads[index])->CloseConn(connId);
}

int XNet::AddDownNode(const DownNodeId &downNodeId, void *userData) {
	assert(mActive);
	return mDownStreamThread->AddDownNode(downNodeId, userData);
}

void XNet::DelDownNode(uint32_t groupId, uint16_t groupIndex) {
	assert(mActive);
	mDownStreamThread->DelDownNode(groupId, groupIndex);
}

void XNet::SendRsp(ConnId connId, const string &pack, SendCallback cb, void *userData) {
	assert(mActive);
	int index = ConnIdToFd(connId) % mNetThreadPool.mThreads.size();
	((NetThread*)mNetThreadPool.mThreads[index])->SendData(connId, pack, cb, userData);
}

void XNet::SendReq(uint32_t groupId, uint64_t key, const string &pack, SendCallback cb, void *userData) {
	assert(mActive);
	mDownStreamThread->SendReq(groupId, key, pack, cb, userData);
}

void XNet::SendReq(ConnId connId, const string &pack, SendCallback cb, void *userData) {
	assert(mActive);
	mDownStreamThread->SendData(connId, pack, cb, userData);
}

void XNet::KeepService(uint32_t waitMS) {
	mRegister.KeepConnect(waitMS);
}

void XNet::StopService() {
	// 下游线程禁止断线重连
	mDownStreamThread->StopConnect();
	// 断开连接,取消注册服务
	mRegister.CloseConnect();
}
