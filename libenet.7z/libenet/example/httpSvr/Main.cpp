/*
 * Main.cpp
 *
 *  Created on: Nov 7, 2020
 *      Author: bright
 */
#include <stdio.h>
#include <unistd.h>

#include "Net.h"
#include "Spliter.h"

#include "tools/Base64Tool.h"
#include "tools/HttpTool.h"
#include "tools/LogTool.h"
using namespace enet;

IMPL_LOGGER_NAME(logger, "server");

class HttpHandler: public NetHandler {
public:
	static void SendRspCallback(Net *net, ConnId connId, SendCode sendCode, const string &pack, uint32_t sendSize, void *userData) {
		if(sendCode == SEND_SUCC) {
			LOG_DEBUG(logger, "HttpHandler::SendRspCallback|sendSucc,data="<<pack<<",size="<<pack.size()<<",sendSize="<<sendSize<<".connId="<<connId);
		} else {
			LOG_ERROR(logger, "HttpHandler::SendRspCallback|sendError,data="<<pack<<",size="<<pack.size()<<",sendSize="<<sendSize<<".connId="<<connId);
		}
	}

public:
	bool OnPack(Net *net, ConnId connId, const string &pack, uint64_t readTime) {
		// 解析请求
		HttpReq httpReq;
		bool parseRet = httpReq.Parse(pack.data(), pack.size());
		if(httpReq.Parse(pack.data(), pack.size()) == false) {
			LOG_ERROR(logger, "HttpHandler::OnPack|parse http req failed.req="<<pack);
			return false;
		}

		string head;
		string content = "<b>hello,world</b>";

		// 获取请求值
		string value = httpReq["req"];
		string key = "req";
		value = httpReq[key];

		// url encode
		string urlEncode0;
		string urlEncode1;
		if(!value.empty()) {
			HttpTool::UrlEncode(value.data(), value.size(), urlEncode0);
			HttpTool::UrlEncode(value.data(), value.size(), urlEncode1, true);
			content = content + "<br>req=" + value + ", urlEncode0=" + urlEncode0 + ", urlEncode1=" + urlEncode1 + "<br>";
		}

		// base64
		{
			string base64Temp;
			string temp = "MTEx";
			base64Temp = Base64Tool::Decode(temp.data(), temp.size(), base64Temp);  // true, 111
			temp = "MTE=";
			base64Temp = Base64Tool::Decode(temp.data(), temp.size());  // true, 11
			temp = "MQ==";
			base64Temp = Base64Tool::Decode(temp.data(), temp.size());  // true, 1
			temp = "MT";

			bool ret = Base64Tool::Decode(temp.data(), temp.size(), base64Temp);  // false
			temp = "M=";
			ret = Base64Tool::Decode(temp.data(), temp.size(), base64Temp);  // false
			temp = "M";
			ret = Base64Tool::Decode(temp.data(), temp.size(), base64Temp);  // false
		}

		string base64 = "hello,world";
		string base64Encode = Base64Tool::Encode(base64.data(), base64.size());
		content += base64 + ", base64Encode=" + base64Encode;


		HttpRsp httpRsp;
		httpRsp.SetHead("Access-Control-Allow-Origin", "*");
		httpRsp.SetHead("Connection", "Keep-Alive");
		httpRsp.SetHead("Content-Type", "text/html;charset=UTF-8");
		httpRsp.SetHead("Content-Length", content.size());
		httpRsp.Output(head);
		// int sendRet = net->SendData(connId, head + content);  // 不设置发送结果回调
		net->SendRsp(connId, head + content, SendRspCallback, this);
		return true;
	}

	bool OnIdle(Net *net, ConnId connId) {
		LOG_DEBUG(logger, "HttpHandler::OnIdle|go to stop connect.connId="<<connId);
		return false;
	}

	void OnClosed(Net *net, ConnId connId) {
		LOG_DEBUG(logger, "HttpHandler::OnClosed|connId="<<connId);
		return ;
	}
};

int main() {
	INIT_LOGGER("../conf/log4cplus.conf");

	HttpSpliter spliter;
	HttpHandler handler;
	Net *net = Net::New("../conf/net.conf");
	net->SetUpSteamHandler(&spliter, &handler);
	net->Start();

	while(true) {
		sleep(120);
		break;
	}
	LOG_INFO(logger, "main|begin stop");
	net->Stop();
	LOG_INFO(logger, "main|end stop");
	return 0;
}


