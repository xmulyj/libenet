/*
 * Session.cpp
 *
 *  Created on: Nov 20, 2020
 *      Author: bright
 */
#include "Session.h"

#include "Lock.h"
#include "tools/StrTool.h"
using namespace enet;

#include "Business/CmdSet.h"

#include "Common/ErrCode.h"
#include "Common/AppPack.h"


static int gMaxSessionNum;               // 会话数上限
static int gUsingSessinNum;              // 当前使用中的会话数
static Mutex gSessionMutex;              // 保护锁
static list<Session*> gFreeSessionList;  // 空闲会话链表
static CmdSet gCmdSet;                   // 命令集合

void Session::Init(int maxSessionNum) {
	gMaxSessionNum = maxSessionNum;
	gUsingSessinNum = 0;
	// 加载命令字
	gCmdSet.LoadCmd();
}

Session::Result Session::ParseReq(const char *data, uint32_t size) {
	Result result;
	do {
		// 分包
		int ret = AppPack::Parse(data, size, result.appHead);
		if(ret != 0) {
			result.type = TYPE_NULL;
			result.errCode = ERR_PARSE_PACK;
			snprintf(result.errStr, sizeof(result.errStr),  "parse pack fail.ret=%d", ret);
			break;
		}
		// ping包特殊处理
		if(result.appHead.cmd == "ping") {
			result.appHead.cmd = "pong";
			result.type = TYPE_STR;
			result.errCode = ERR_NONE;
			result.str = AppPack::MakeRsp(ERR_NONE, result.appHead.tid, result.appHead.rid, result.appHead.cmd);
			snprintf(result.errStr, sizeof(result.errStr), "ping");
			break;
		}
		// 查找命令字处理器
		Processor *processor = gCmdSet[result.appHead.cmd];
		if(processor == NULL) {
			result.type = TYPE_NULL;
			result.errCode = ERR_CMD_INVALID;
			snprintf(result.errStr, sizeof(result.errStr), "cmd=%s invalid", result.appHead.cmd.c_str());
			break;
		}
		// 获取空闲session
		Session *session = NULL;
		gSessionMutex.Lock();
		if(!processor->ReadOnly() || (gMaxSessionNum <= 0 || gUsingSessinNum < gMaxSessionNum)) {
			if(gFreeSessionList.empty()) {
				session = new Session();
			} else {
				session = gFreeSessionList.front();
				gFreeSessionList.pop_front();
			}
			++gUsingSessinNum;
		}
		gSessionMutex.UnLock();
		if(session == NULL) {
			result.type = TYPE_STR;
			result.errCode = ERR_SESSION_LIMITED;
			result.str = AppPack::MakeRsp(ERR_SESSION_LIMITED, result.appHead.tid, result.appHead.rid, result.appHead.cmd);
			snprintf(result.errStr, sizeof(result.errStr), "session limited");
			break;
		}
		// 设置返回值
		result.type = TYPE_SESSION;
		result.errCode = ERR_NONE;
		result.session = session;
		// 解析数据包
		if(session->ParseReqData(result.appHead) == false) {
			session->errCode = ERR_PARSE_DATA;
			break;
		}
		// 生成调用堆栈
		processor->GenCallStack(session);
	} while(false);
	return result;
}

void Session::Free(Session *session) {
	if(session == 0) {
		return ;
	}
	while(!session->Empty()) {
		IInvoker *invoker = session->Pop();
		delete invoker;
	}
	gSessionMutex.Lock();
	--gUsingSessinNum;
	assert(gUsingSessinNum >= 0);
	if(gFreeSessionList.size() <= 1024) {
		gFreeSessionList.push_back(session);
	} else {
		delete session;
	}
	gSessionMutex.UnLock();
}

int Session::UsingSessionNum() {
	return gUsingSessinNum;
}

////////////////////////////////////////////////
////////////////////////////////////////////////
bool Session::ParseReqData(AppHead &appHead) {
	NeedInterrupt(false);
	// 通用字段
	net = NULL;
	connId = 0;

	// 上游请求相关
	cmd = appHead.cmd;
	req.assign(appHead.data, appHead.dataSize);
	tid = appHead.tid;
	rid = appHead.rid;
	errCode = ERR_NONE;
	rsp.clear();

	// 下游请求相关
	reqSeq = 0;
	finishNum = 0;
	reqVec.clear();

	// 定制字段
	objReq.clear();
	objRsp.clear();

	// 解析数据
	bool ret = true;
	if(appHead.data != NULL && appHead.dataSize > 0) {
		ret = JsonTool::ParseFromStr(objReq, appHead.data, appHead.dataSize);
	}
	return ret;
}

void Session::MakeRsp() {
	string rspData;
	if(errCode == ERR_NONE) {
		bool ret = JsonTool::WriteToStr(objRsp, rspData);
		assert(ret == true);
	}
	rsp = AppPack::MakeRsp(errCode, tid, rid, cmd, rspData);
}

void Session::SetConnInfo(Net *net, ConnId connId) {
	this->net = net;
	this->connId = connId;
}

void Session::PrepareInvoke() {
	NeedInterrupt(false);
	errCode = ERR_NONE;
	threadId = pthread_self();
	// 不要在这里清理reqVec: 有可能多个处理过程压入了请求,然后再一起发送出去; 在完成的时候再清理
}

//////////////////////////////////////////////
//////////////////////////////////////////////
void Session::AddReq(const Req &req) {
	reqVec.push_back(req);
}

string Session::MakeReq(uint32_t reqIndex, const Req &req) {
	AppHead appHead;
	uint32_t rid = Rid(reqSeq, reqIndex);
	return AppPack::MakeReq(tid, rid, req.cmd, req.req);
}

#define _ATOMIC_
#ifdef _ATOMIC_
#include <atomic>
using std::atomic;
static atomic<uint32_t> gReqSeq(1000);
#else
static Mutex gReqSeqLock;
static uint32_t gReqSeq = 10000;
#endif


static RWLock gPendingSessionMapRWLock;
static map<uint32_t, Session*> gPendingSessionMap;

void Session::SendReq(Session *session) {
	session->finishNum = 0;
	if(session->reqVec.size() == 0) {
		return ;
	}
	session->NeedInterrupt(true);

#ifdef _ATOMIC_
	session->reqSeq = gReqSeq++;
#else
	gReqSeqLock.Lock();
	session->reqSeq = gReqSeq++;
	gReqSeqLock.UnLock();
#endif

	gPendingSessionMapRWLock.WLock();
	gPendingSessionMap[session->reqSeq] = session;
	gPendingSessionMapRWLock.UnLock();
	for(uint32_t i = 0; i < session->reqVec.size(); ++i) {
		string reqStr = session->MakeReq(i, session->reqVec[i]);
		session->net->SendReq(session->reqVec[i].groupId, session->reqVec[i].key, reqStr, Session::SendReqCallback);
	}
}

void Session::SendReqCallback(Net *net, ConnId connId, SendCode sendCode, const string &pack, uint32_t sendSize, void *userData) {
	AppHead appHead;
	int ret = AppPack::Parse(pack.data(), pack.size(), appHead);
	assert(ret == 0);
	uint32_t tid = appHead.tid;
	uint32_t reqSeq = ReqSeq(appHead.rid);
	uint16_t reqIndex = ReqIndex(appHead.rid);
	if(sendCode != SEND_SUCC) {
		appHead.retCode = ERR_SEND_REQ;
		LOG_ERROR(DO_LOGGER, "Session::SendReqCallback|send failed.cmd="<<appHead.cmd<<",tid="<<tid<<",reqSeq="<<reqSeq<<",reqIndex="<<reqIndex
				<<".sendCode="<<sendCode<<"("<<SendCodeStr(sendCode)<<")");
	} else {
		LOG_DEBUG(DO_LOGGER, "Session::SendReqCallback|send succ.cmd="<<appHead.cmd<<",tid="<<tid<<",reqSeq="<<reqSeq<<",reqIndex="<<reqIndex);
	}
	// 请求都完成时返回session,否则返回NULL
	Session *session = ProcessPendingSession(appHead, false);
	if(session == NULL) {
		return ;
	}
	if(session->threadId == pthread_self()) {
		// 在调用堆栈线程中完成整个请求,不用中断堆栈, 继续处理堆栈中剩下的调用
		session->NeedInterrupt(false);
	} else {
		// 在非调用堆栈中完成整个请求, 调用处理方法继续处理调用堆栈
		// 通过invokeLock保证正在执行调用堆栈的线程先中断退出,然后再然本线程进入调用堆栈执行
		session->net->DownStreamHandler()->OnTask(session);
	}
}

void Session::OnRsp(AppHead &appHead, uint64_t readTime) {
	uint32_t tid = appHead.tid;
	uint32_t reqSeq = ReqSeq(appHead.rid);
	uint16_t reqIndex = ReqIndex(appHead.rid);
	if(appHead.retCode != ERR_NONE) {
		LOG_ERROR(DO_LOGGER, "Session::OnRsp|rspPack.cmd="<<appHead.cmd<<",tid="<<tid<<",reqSeq="<<reqSeq<<",reqIndex="<<reqIndex<<",retCode="<<appHead.retCode);
	} else {
		LOG_DEBUG(DO_LOGGER, "Session::OnRsp|rspPack.cmd="<<appHead.cmd<<",tid="<<tid<<",reqSeq="<<reqSeq<<",reqIndex="<<reqIndex);
	}
	// 请求都完成时返回session,否则返回NULL
	Session *session = ProcessPendingSession(appHead, true);
	if(session == NULL) {
		return ;
	}
	// 在非调用堆栈中完成整个请求, 调用处理方法继续处理调用堆栈
	// 通过invokeLock保证正在执行调用堆栈的线程先中断退出,然后再然本线程进入调用堆栈执行
	session->net->DownStreamHandler()->OnTask(session);
}


Session* Session::ProcessPendingSession(AppHead &appHead, bool isRsp) {
	uint32_t tid = appHead.tid;
	uint32_t reqSeq = ReqSeq(appHead.rid);
	uint16_t reqIndex = ReqIndex(appHead.rid);

	Session *session = NULL;
	bool finished = false;
	gPendingSessionMapRWLock.WLock();
	do {
		map<uint32_t, Session*>::iterator it = gPendingSessionMap.find(reqSeq);
		if(it == gPendingSessionMap.end()) {
			break;
		}
		session = it->second;
		// 设置req的状态
		assert(reqIndex < session->reqVec.size());
		// 设置子请求本身的错误码
		session->reqVec[reqIndex].retCode = appHead.retCode;
		// 是回包时并且没有错误并且需要回包, 解析回包数据
		if(isRsp == true && appHead.retCode == ERR_NONE && session->reqVec[reqIndex].needRsp == true) {
			session->reqVec[reqIndex].retCode = session->reqVec[reqIndex].rspHandler->OnPsp(appHead);
		}
		// 不需要回包或者是回包或者发送错误, 该子请求已经完成
		if(session->reqVec[reqIndex].needRsp == false || isRsp == true || session->reqVec[reqIndex].retCode != ERR_NONE) {
			session->reqVec[reqIndex].finished = true;
			++session->finishNum;
			// 需要回包并且该子请求产生错误, 设置整个会话的错误码为该错误码, 并且整个请求设置为已完成(只要有一个需要回包的请求发生错误,整个请求当作失败处理了,如果是写数据的话就要谨慎设计了)
			if(session->reqVec[reqIndex].needRsp == true && appHead.retCode) {
				session->errCode = session->reqVec[reqIndex].retCode;
				session->finishNum = session->reqVec.size();
			}
		}
		if(session->finishNum >= session->reqVec.size()) {
			finished = true;
			session->reqVec.clear();
			gPendingSessionMap.erase(it);
		}
	}while(false);
	gPendingSessionMapRWLock.UnLock();
	if(session == NULL) {
		// 1)发送时间太长导致session超时被删除了; 2)不需要回包却收到下游回包
		LOG_WARN(DO_LOGGER, "Session::ProcessPendingSession|not find pending session for update req.cmd="<<appHead.cmd<<",tid="<<tid<<",reqSeq="<<reqSeq<<",reqIndex="<<reqIndex);
	}
	// 所有子请求都完成时返回该session
	return (session == NULL || finished == false ? NULL : session);
}
