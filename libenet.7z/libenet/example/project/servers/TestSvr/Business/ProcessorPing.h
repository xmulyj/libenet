/*
 * ProcessorPing.h
 *
 *  Created on: Nov 19, 2020
 *      Author: bright
 */

#ifndef EXAMPLE_PROJECT_SERVERS_TESTSVR_BUSINESS_PROCESSORPING_H_
#define EXAMPLE_PROJECT_SERVERS_TESTSVR_BUSINESS_PROCESSORPING_H_

#include "../Processor.h"
#include "../Session.h"


class ProcessorPing: public Processor {
private:
	friend class Processor;

public:
	bool ReadOnly() { return true; }
	void GenCallStack(Session *session);

public:
	void Process(Session *session);
};

#endif /* EXAMPLE_PROJECT_SERVERS_TESTSVR_BUSINESS_PROCESSORPING_H_ */
