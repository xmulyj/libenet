/*
 * ProcessorTest.cpp
 *
 *  Created on: Nov 19, 2020
 *      Author: bright
 */
#include "ProcessorTest.h"

///////////////////////
void ProcessorTest::GenCallStack(Session *session) {
	PUSH_CLASS(session, ProcessorTest, Process);
	PUSH_CLASS(session, ProcessorTest, ProcessRsp);
	COMMIT(session);
}

void ProcessorTest::Process(Session *session) {
	Req req;
	session->mTestSvr.GenReqTest1(req, 0);
	session->AddReq(req);
	session->mTestSvr.GenReqTest2(req, 1);
	session->AddReq(req);
	PUSH_COMMIT_FUNC(session, Session::SendReq);
}

void ProcessorTest::ProcessRsp(Session *session) {
	session->objRsp["tabl1"] = session->mTestSvr.rsp1;
	session->objRsp["tabl2"] = session->mTestSvr.rsp2;
}


///////////////////////
void ProcessorTest1::GenCallStack(Session *session) {
	PUSH_COMMIT_CLASS(session, ProcessorTest1, Process);
}

void ProcessorTest1::Process(Session *session) {
	session->objRsp = Json::Value(Json::objectValue);
	session->objRsp["tabl1"] = Json::Value(Json::objectValue);
	Json::Value &tbl = session->objRsp["tabl1"];
	tbl["key"] = "value";
	tbl["status"] = 0;
}


///////////////////////
void ProcessorTest2::GenCallStack(Session *session) {
	PUSH_COMMIT_CLASS(session, ProcessorTest2, Process);
}

void ProcessorTest2::Process(Session *session) {
	session->objRsp = Json::Value(Json::objectValue);
	session->objRsp["tabl2"] = Json::Value(Json::objectValue);
	Json::Value &tbl = session->objRsp["tabl2"];
	tbl["key"] = "value";
	tbl["status"] = 0;
}
