/*
 * ProcessorTest.h
 *
 *  Created on: Nov 19, 2020
 *      Author: bright
 */

#ifndef PROJECT_SERVERS_TESTSVR_BUSINESS_PROCESSORTEST_H_
#define PROJECT_SERVERS_TESTSVR_BUSINESS_PROCESSORTEST_H_

#include "../Processor.h"
#include "../Session.h"


class ProcessorTest: public Processor {
private:
	friend class Processor;

public:
	bool ReadOnly() { return true; }
	void GenCallStack(Session *session);

public:
	void Process(Session *session);
	void ProcessRsp(Session *session);
};

class ProcessorTest1: public Processor {
private:
	friend class Processor;

public:
	bool ReadOnly() { return true; }
	void GenCallStack(Session *session);

public:
	void Process(Session *session);
};

class ProcessorTest2: public Processor {
private:
	friend class Processor;

public:
	bool ReadOnly() { return true; }
	void GenCallStack(Session *session);

public:
	void Process(Session *session);
};


#endif /* PROJECT_SERVERS_TESTSVR_BUSINESS_PROCESSORTEST_H_ */
