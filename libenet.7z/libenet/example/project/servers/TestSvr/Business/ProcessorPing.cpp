/*
 * ProcessPing.cpp
 *
 *  Created on: Nov 30, 2020
 *      Author: bright
 */

#include "ProcessorPing.h"

void ProcessorPing::GenCallStack(Session *session) {
	PUSH_COMMIT_CLASS(session, ProcessorPing, Process);
}

void ProcessorPing::Process(Session *session) {
	session->objRsp = Json::Value(Json::objectValue);
	session->objRsp["status"] = 0;
}
