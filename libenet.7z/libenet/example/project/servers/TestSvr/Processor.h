/*
 * Processor.h
 *
 *  Created on: Nov 19, 2020
 *      Author: bright
 */

#ifndef EXAMPLE_PROJECT_SERVERS_TESTSVR_PROCESSOR_H_
#define EXAMPLE_PROJECT_SERVERS_TESTSVR_PROCESSOR_H_

#include "Session.h"

class Processor {
public:
	virtual ~Processor(){}
	virtual bool ReadOnly() = 0;  // 是否只读操作
	virtual void GenCallStack(Session *session) = 0;

	template<typename T>
	static Processor* NewInstance() {
		return new T;
	}
};

#define PUSH_CLASS(c, t, p) c->Push(new Invoker<t>(this, &t::p))
#define PUSH_VOID(c, t, p) c->Push(new Invoker<void>(&t::p))
#define PUSH_FUNC(c, p) c->Push(new Invoker<void>(&p))

#define PUSH_COMMIT_CLASS(c, t, p) c->PushCommit(new Invoker<t>(this, &t::p))
#define PUSH_COMMIT_FUNC(c, p) c->PushCommit(new Invoker<void>(&p))

#define COMMIT(c) c->Commit()

#endif /* EXAMPLE_PROJECT_SERVERS_TESTSVR_PROCESSOR_H_ */
