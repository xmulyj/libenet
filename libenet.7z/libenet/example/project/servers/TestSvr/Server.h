/*
 * Server.h
 *
 *  Created on: Nov 17, 2020
 *      Author: bright
 */

#ifndef EXAMPLE_PROJECT_SERVERS_TESTSVR_SERVER_H_
#define EXAMPLE_PROJECT_SERVERS_TESTSVR_SERVER_H_

#include "Net.h"
using namespace enet;

#include "Session.h"

class Server: public TaskHandler {
public:
	bool OnTask(void *task);

public:
	Server(Net *net);
	~Server();

	NetHandler *mUpStreamHandler;
	NetHandler *mDownStreamHandler;

	int TaskNum();

public:
	Net *mNet;
};




#endif /* EXAMPLE_PROJECT_SERVERS_TESTSVR_SERVER_H_ */
