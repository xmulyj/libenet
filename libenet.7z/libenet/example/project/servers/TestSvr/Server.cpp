/*
 * Server.cpp
 *
 *  Created on: Nov 17, 2020
 *      Author: bright
 */
#include "Server.h"
#include "Common/ErrCode.h"

#include "tools/TimeTool.h"
using namespace enet;

#include <iomanip>
using namespace std;

IMPL_LOGGER_NAME(REQ_LOGGER, "req");

class Server;
///////////////////////////////
// 上游处理器
class UpStreamHandler: public NetHandler {
public:
	UpStreamHandler(Server *server) {
		mServer = server;
	}

public:
	// 发送回包回调方法
	static void SendRspCallback(Net *net, ConnId connId, SendCode sendCode, const string &pack, uint32_t sendSize, void *userData) {
		AppHead appHead;
		int ret = AppPack::Parse(pack.data(), pack.size(), appHead);
		assert(ret == 0);
		uint32_t tid = appHead.tid;
		uint32_t reqSeq = ReqSeq(appHead.rid);
		uint32_t reqIndex = ReqIndex(appHead.rid);
		const char *packData = pack.c_str() + AppPack::HeadSize;
		if(sendCode == SEND_SUCC) {
			LOG_DEBUG(UP_LOGGER, "UpStreamHandler::SendRspCallback|sendSucc.sendCode="<<sendCode<<"("<<SendCodeStr(sendCode)<<")"
					<<",cmd="<<appHead.cmd
					<<",tid="<<tid
					<<",reqSed="<<reqSeq
					<<",reqIndex="<<reqIndex
					<<",data="<<string(appHead.data, appHead.dataSize)
					<<",rspSize="<<appHead.dataSize
					<<",sendSize="<<sendSize
					<<",retCode="<<appHead.retCode
					<<".connId="<<connId);
		} else {
			LOG_ERROR(UP_LOGGER, "UpStreamHandler::SendRspCallback|sendError.sendCode="<<sendCode<<"("<<SendCodeStr(sendCode)<<")"
					<<",cmd="<<appHead.cmd
					<<",tid="<<tid
					<<",reqSed="<<reqSeq
					<<",reqIndex="<<reqIndex
					<<",rspSize="<<appHead.dataSize
					<<",sendSize="<<sendSize
					<<",retCode="<<appHead.retCode
					<<".connId="<<connId);
		}
		if(appHead.cmd == "pong") {
			return ;
		}
		uint64_t nowUs = TimeTool::TimeUS();
		if(userData == NULL) {
			LOG_INFO(REQ_LOGGER, "cmd="<<appHead.cmd
					<<",tid="<<tid
					<<",reqSed="<<reqSeq
					<<",reqIndex="<<reqIndex
					<<",req="
					<<",rspSize="<<appHead.dataSize
					<<",sendSize="<<sendSize
					<<",retCode="<<appHead.retCode
					<<",timeCost="<<setiosflags(ios::fixed)<<setprecision(2)<<0.0);
		} else {
			Session *session = (Session*)userData;
			LOG_INFO(REQ_LOGGER, "cmd="<<appHead.cmd
					<<",tid="<<tid
					<<",reqSed="<<reqSeq
					<<",reqIndex="<<reqIndex
					<<",req="<<session->req
					<<",rspSize="<<appHead.dataSize
					<<",sendSize="<<sendSize
					<<",retCode="<<appHead.retCode
					<<",timeCost="<<setiosflags(ios::fixed)<<setprecision(2)<<(nowUs-session->readTime)/1000.0);
			Session::Free(session);
		}
	}

public:
	bool OnPack(Net *net, ConnId connId, const string &pack, uint64_t readTime) {
		Session::Result result = Session::ParseReq(pack.data(), pack.size());
		switch(result.type) {
			case Session::TYPE_NULL: {
				LOG_ERROR(UP_LOGGER, "UpStreamHandler::OnPack|get session return null[errCode="<<result.errCode<<"("<<result.errStr<<")].connId="<<connId);
				return false;
			}
			case Session::TYPE_STR: {
				net->SendRsp(connId, result.str, UpStreamHandler::SendRspCallback, NULL);
				if(result.errCode != 0) {
					LOG_ERROR(UP_LOGGER, "UpStreamHandler::OnPack|get session return rsp[errCode="<<result.errCode<<"("<<result.errStr<<")].connId="<<connId);
				} else {
					LOG_DEBUG(UP_LOGGER, "UpStreamHandler::OnPack|get session return rsp[errCode="<<result.errCode<<"("<<result.errStr<<")].connId="<<connId);
				}
				return true;
			}
			case Session::TYPE_SESSION: {
				AppHead &appHead = result.appHead;
				uint32_t tid = appHead.tid;
				uint32_t reqSeq = ReqSeq(appHead.rid);
				uint32_t reqIndex = ReqIndex(appHead.rid);
				LOG_DEBUG(UP_LOGGER, "UpStreamHandler::OnPack|cmd="<<appHead.cmd
						<<",tid="<<tid
						<<",reqSed="<<reqSeq
						<<",reqIndex="<<reqIndex
						<<",data="<<string(appHead.data, appHead.dataSize)
						<<".connId="<<connId);
				result.session->SetConnInfo(net, connId);
				result.session->readTime = readTime;
				return mServer->OnTask(result.session);
			}
			default: {
				assert(0);
			}
		}
		return true;
	}

	bool OnIdle(Net *net, ConnId connId) {
		LOG_DEBUG(UP_LOGGER, "UpStreamHandler::OnIdle|go to close connection.connId="<<connId);
		return false;  // 上游链接空闲超时,关闭链接
	}

	void OnClosed(Net *net, ConnId connId) {
		LOG_DEBUG(UP_LOGGER, "UpStreamHandler::OnClosed|connId="<<connId);
		return ;
	}

public:
	Server *mServer;
};

///////////////////////////////
// 下游处理器
class DownStreamHandler: public NetHandler {
public:
	DownStreamHandler(Server *server) {
		mServer = server;
	}

public:
	// 发送请求回调方法
	static void SendReqCallback(Net *net, ConnId connId, SendCode sendCode, const string &pack, uint32_t sendSize, void *userData) {
		AppHead appHead;
		int ret = AppPack::Parse(pack.data(), pack.size(), appHead);
		assert(ret == 0);
		uint32_t tid = appHead.tid;
		uint32_t reqSeq = ReqSeq(appHead.rid);
		uint32_t reqIndex = ReqIndex(appHead.rid);
		if(sendCode == SEND_SUCC) {
			LOG_DEBUG(DO_LOGGER, "DownStreamHandler::SendReqCallback|sendSucc.sendCode="<<sendCode<<"("<<SendCodeStr(sendCode)<<")"
					<<",cmd="<<appHead.cmd
					<<",tid="<<tid
					<<",reqSed="<<reqSeq
					<<",reqIndex="<<reqIndex
					<<",data="<<string(appHead.data, appHead.dataSize)
					<<",sendSize="<<sendSize
					<<".connId="<<connId);
		} else {
			LOG_ERROR(DO_LOGGER, "DownStreamHandler::SendReqCallback|sendError.sendCode="<<sendCode<<"("<<SendCodeStr(sendCode)<<")"
					<<",cmd="<<appHead.cmd
					<<",tid="<<tid
					<<",reqSed="<<reqSeq
					<<",reqIndex="<<reqIndex
					<<",data="<<string(appHead.data, appHead.dataSize)
					<<",sendSize="<<sendSize
					<<".connId="<<connId);
		}
	}

public:
	bool OnPack(Net *net, ConnId connId, const string &pack, uint64_t readTime) {
		AppHead appHead;
		int ret = AppPack::Parse(pack.data(), pack.size(), appHead);
		if(ret != 0) {
			LOG_ERROR(DO_LOGGER, "DownStreamHandler::OnPack|parse pack failed.connId="<<connId<<",ret="<<ret<<",pack="<<pack);
			return false;
		}
		uint32_t tid = appHead.tid;
		uint32_t reqSeq = ReqSeq(appHead.rid);
		uint32_t reqIndex = ReqIndex(appHead.rid);
		LOG_DEBUG(DO_LOGGER, "DownStreamHandler::OnPack|cmd="<<appHead.cmd
				<<",tid="<<tid
				<<",reqSed="<<reqSeq
				<<",reqIndex="<<reqIndex
				<<",data="<<string(appHead.data, appHead.dataSize)
				<<".connId="<<connId);
		if(appHead.cmd == "pong") {
			return true;
		}
		Session::OnRsp(appHead, readTime);
		return true;
	}

	bool OnTask(void *task) {
		return mServer->OnTask(task);
	}

	bool OnIdle(Net *net, ConnId connId) {
		// 下游链接空闲超时,发送ping包维持链接存活
		static string cmd = "ping";
		string pingReq = AppPack::MakeReq(0, 0, cmd);
		net->SendReq(connId, pingReq, DownStreamHandler::SendReqCallback, NULL);
		return true;
	}

	void OnTimer() {
		LOG_DEBUG(DO_LOGGER, "DownStreamHandler::OnTimer|timer trigger");
	}

	void OnClosed(Net *net, ConnId connId) {
		LOG_DEBUG(DO_LOGGER, "DownStreamHandler::OnClosed|connId="<<connId);
		return ;
	}

public:
	Server *mServer;
};



///////////////////////////////
// 服务器
Server::Server(Net *net) {
	mNet = net;
	Session::Init(mNet->GetConf()->maxSessionNum);
	mUpStreamHandler = new UpStreamHandler(this);
	mDownStreamHandler = new DownStreamHandler(this);
}

Server::~Server() {
	delete mUpStreamHandler;
	delete mDownStreamHandler;
}
bool Server::OnTask(void *task) {
	Session *session = (Session*)task;
	// 调用堆栈
	bool isInterrupt = false;
	session->LockCallStack();
	while(session->errCode == ERR_NONE && !session->Empty()) {
		session->PrepareInvoke();
		IInvoker *invoker = session->Pop();
		invoker->Invoke(session);
		delete invoker;
		// 先判断是否有错误再判断是否有等待回包
		if(session->errCode != ERR_NONE) {
			break;
		}
		isInterrupt = session->NeedInterrupt();
		if(isInterrupt == true) {
			break;
		}
	}
	session->UnLockCallStack();
	if(isInterrupt == true) {
		return true;
	}
	// session堆栈已经执行完毕或者产生了错误
	uint32_t reqSeq = ReqSeq(session->rid);
	uint16_t reqIndex = ReqIndex(session->rid);
	LOG_DEBUG(SVR_LOGGER, "Server::OnProcess|process finished.cmd="<<session->cmd
			<<",tid="<<session->tid
			<<",reqSeq="<<reqSeq
			<<",reqIndex="<<reqIndex
			<<",errCode="<<session->errCode
			<<".connId="<<session->connId);
	// 生成回包
	session->MakeRsp();
	if(!session->rsp.empty()) {
		session->net->SendRsp(session->connId, session->rsp, UpStreamHandler::SendRspCallback, session);
	} else {
		Session::Free(session);
	}
	return true;
}

int Server::TaskNum() {
	return Session::UsingSessionNum();
}
