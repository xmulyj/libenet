/*
 * ProtocolTest.h
 *
 *  Created on: Dec 7, 2020
 *      Author: bright
 */

#ifndef EXAMPLE_PROJECT_SERVERS_PROTOCOL_PROTOCOLTEST_H_
#define EXAMPLE_PROJECT_SERVERS_PROTOCOL_PROTOCOLTEST_H_

#include "Req.h"
#include "tools/JsonCppTool.h"
using namespace enet;

class ProtocolTest: RspHandler {
public:
	ErrCode OnPsp(AppHead &appHead);

public:
	void GenReqTest1(Req &req, uint64_t key);
	void GenReqTest2(Req &req, uint64_t key);

public:
	Json::Value rsp1;
	Json::Value rsp2;
};

#endif /* EXAMPLE_PROJECT_SERVERS_PROTOCOL_PROTOCOLTEST_H_ */
