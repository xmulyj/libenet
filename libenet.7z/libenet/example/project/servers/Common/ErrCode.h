/*
 * ErrCode.h
 *
 *  Created on: Nov 17, 2020
 *      Author: bright
 */

#ifndef EXAMPLE_PROJECT_SERVERS_COMMON_ERRCODE_H_
#define EXAMPLE_PROJECT_SERVERS_COMMON_ERRCODE_H_

typedef enum {
	ERR_NONE = 0,
	ERR_PARSE_PACK = 1,        // 解析数据包错误
	ERR_PARSE_DATA = 2,        // 解析应用数据错误
	ERR_SEND_RSP = 3,          // 发送回包错误
	ERR_SEND_REQ = 4,          // 发送下游错误
	ERR_SESSION_LIMITED = 5,   // 没有空闲session
	ERR_CMD_INVALID = 6,       // 无效的命令字
	ERR_TIMEOUT = 7,           // 处理超时
}ErrCode;



#endif /* EXAMPLE_PROJECT_SERVERS_COMMON_ERRCODE_H_ */
