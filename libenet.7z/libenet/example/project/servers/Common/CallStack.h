/*
 * CallStack.h
 *
 *  Created on: Nov 20, 2020
 *      Author: bright
 */

#ifndef EXAMPLE_PROJECT_SERVERS_COMMON_CALLSTACK_H_
#define EXAMPLE_PROJECT_SERVERS_COMMON_CALLSTACK_H_

#include <assert.h>
#include <stddef.h>
#include <list>
using std::list;

#include "Invoker.h"

class CallStack {
public:
	void Push(IInvoker *invoker) {
		assert(invoker != NULL);
		mTempStack.push_front(invoker);
	}

	void Commit() {
		while(!mTempStack.empty()) {
			IInvoker *invoker = mTempStack.front();
			mTempStack.pop_front();
			mStack.push_front(invoker);
		}
	}

	void PushCommit(IInvoker *invoker) {
		Push(invoker);
		Commit();
	}

	bool Empty() {
		return mStack.empty();
	}

	IInvoker* Pop() {
		IInvoker* invoker = mStack.front();
		mStack.pop_front();
		return invoker;
	}

	void NeedInterrupt(bool needInterrupt) {
		mNeedInterrupt = needInterrupt;
	}
	bool NeedInterrupt() {
		return mNeedInterrupt;
	}

	void LockCallStack() {
		mLock.Lock();
	}
	void UnLockCallStack() {
		mLock.UnLock();
	}

private:
	list<IInvoker*> mStack;
	list<IInvoker*> mTempStack;
	bool mNeedInterrupt;  // 堆栈调用过程中是切换了线程或者异步操作,是的话需要中断调用堆栈
	Mutex mLock;
};



#endif /* EXAMPLE_PROJECT_SERVERS_COMMON_CALLSTACK_H_ */
