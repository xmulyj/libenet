/*
 * AppPack.h
 *
 *  Created on: Nov 19, 2020
 *      Author: bright
 */

#ifndef PROJECT_SERVERS_COMMON_APPPACK_H_
#define PROJECT_SERVERS_COMMON_APPPACK_H_

#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <netinet/in.h>

#include <string>
using std::string;

#define Rid(reqSeq, reqIndex) ((reqSeq) << 8 | (reqIndex))
#define ReqSeq(rid) ((rid) >> 8)
#define ReqIndex(rid) ((rid) & 0xFF)

class AppHead {
public:
	uint32_t tid;        // 事务id(客户端的请求id)
	uint32_t rid;        // 请求id(服务器内部定义的id)
	string cmd;          // 命令字
	int32_t retCode;     // 回包错误码
	const char *data;    // 数据
	uint32_t dataSize;   // 数据长度

	AppHead() {
		tid = 0;
		rid = 0;
		cmd.clear();
		retCode = 0;
		data = NULL;
		dataSize = 0;
	}
};

class AppPack {
public:
	static const unsigned SizeOffset = 4;           // 包长偏移
	static const unsigned SizeBytes = 4;            // 包长字节数
	static const unsigned HeadSize = 20;            // 头部长度 char[4]+int+int+int+int
	static const unsigned IncludeHeadSize = false;  // 包长是否包含头部长度

public:
	// 解析数据包.成功返回0, appHead有效
	static int Parse(const char *frame, unsigned int size, AppHead &appHead);

	// 构建数据包
	static string MakeReq(uint32_t tid, uint32_t rid, const string &cmd, const string &data);
	static string MakeReq(uint32_t tid, uint32_t rid, const string &cmd);
	static string MakeRsp(int32_t retCode, uint32_t tid, uint32_t rid, const string &cmd, const string &data);
	static string MakeRsp(int32_t retCode, uint32_t tid, uint32_t rid, const string &cmd);
};

inline
int AppPack::Parse(const char *frame, unsigned int size, AppHead &appHead) {
	if(frame == NULL) {
		return -1;
	}
	const char *data = frame;
	if(data[0] != 'P' || data[1] != 'A' || data[2] != 'K') {
		return -2;
	}
	data += 3;
	// cmdSize
	uint8_t cmdSize = *(uint8_t*)data;
	data += 1;
	// bodySize
	uint32_t bodySize = *(uint32_t*)(data);
	bodySize = ntohl(bodySize);
	if(HeadSize + bodySize > size) {
		return -3;
	}
	data += 4;
	// tid
	appHead.tid = *(uint32_t*)(data);
	appHead.tid = ntohl(appHead.tid);
	data += 4;
	// rid
	appHead.rid = *(uint32_t*)(data);
	appHead.rid = ntohl(appHead.rid);
	data += 4;
	// retCode
	appHead.retCode = *(int32_t*)(data);
	appHead.retCode = (int32_t)ntohl(appHead.retCode);
	data += 4;
	// cmd
	appHead.cmd.assign(data, cmdSize);
	data += cmdSize;
	// data
	appHead.data = data;
	appHead.dataSize = bodySize - cmdSize;
	data += appHead.dataSize;
	// 检验最后的数据长度
	if(data - frame != HeadSize + bodySize) {
		return -4;
	}
	return 0;
}

inline
string AppPack::MakeReq(uint32_t tid, uint32_t reqId, const string &cmd, const string &data) {
	return MakeRsp(0, tid, reqId, cmd, data);
}

inline
string AppPack::MakeReq(uint32_t tid, uint32_t reqId, const string &cmd) {
	static string emptyStr;
	return MakeRsp(0, tid, reqId, cmd, emptyStr);
}

inline
string AppPack::MakeRsp(int32_t retCode, uint32_t tid, uint32_t rid, const string &cmd, const string &data) {
	assert(0 < cmd.size() && cmd.size() <= 255);
	string frame;
	frame.reserve(HeadSize + cmd.size() + data.size());
	// 头部标识
	frame.append("PAK");
	// cmdSize
	uint8_t cmdSize = (uint8_t)cmd.size();
	frame.append((char*)&cmdSize, 1);
	// bodySize
	uint32_t bodySize = htonl(cmd.size() + data.size());
	frame.append((char*)&bodySize, 4);
	// tid
	tid = htonl(tid);
	frame.append((char*)&tid, 4);
	// rid
	rid = htonl(rid);
	frame.append((char*)&rid, 4);
	// retCode
	retCode = htonl(retCode);
	frame.append((char*)&retCode, 4);
	// cmd
	frame.append(cmd);
	// data
	if(!data.empty()) {
		frame += data;
	}
	return frame;
}

inline
string AppPack::MakeRsp(int32_t retCode, uint32_t tid, uint32_t rid, const string &cmd) {
	static string emptyStr;
	return MakeRsp(retCode, tid, rid, cmd, emptyStr);
}


#endif /* PROJECT_SERVERS_COMMON_APPPACK_H_ */
