/*
 * NetConf.cpp
 *
 *  Created on: Nov 18, 2020
 *      Author: bright
 */
#include "NetConf.h"
#include "Net.h"
#include "TCPSocket.h"
using namespace enet;

#include <assert.h>
#include <string.h>

#include<iostream>
#include<fstream>
using namespace std;

IMPL_LOGGER_CLASS_NAME(NetConf, downLogger, "down");
IMPL_LOGGER_CLASS_NAME(NetConf, netLogger, "net");
IMPL_LOGGER_CLASS_NAME(NetConf, regLogger, "reg");
IMPL_LOGGER_CLASS_NAME(NetConf, svrLogger, "svr");

NetConf::NetConf() {
	listenIP = "";
	listenPort = 0;
	netThreadNum = 1;
	idleTime = 30;
	readTime = 3;
	writeTime = 3;
	maxPackLen = 4 * 1024;

	workerThreadNum = 1;
	queueSize = 128;
	maxSessionNum = 128;
	downIdleTime = 10;

	groupId = -1;
	routeType = ROUTE_NONE;
	groupSize = -1;
	groupIndex = -1;
	rangeFrom = -1;
	rangeStop = -1;
	regSessionExpire = 2;
	regPath = "";
	downNodeMap.clear();
}


// 从文件解析参数
void NetConf::ParseFromFile(const char *file) {
	ifstream f(file);
	char line[1024];
	assert(f.good());

	map<string, string> mKeyValMap;
	while(f.getline(line, sizeof(line), '\n')) {
		if(strchr(line, '#') != NULL || strchr(line, '[') != NULL) {
			continue;
		}
		char *key = line;
		char *split = strchr(line, '=');
		if(split == NULL) {
			continue;
		}
		*split = '\0';
		char *value = split + 1;
		// 去掉key左右两边的空白符
		while(*key == ' ' || *key == '\t') {
			++key;
		}
		if(key >= split) {
			continue;
		}
		split--;
		while(*split == ' ' || *split == '\t') {
			*split-- = '\0';
		}
		if(key >= split) {
			continue;
		}
		// 去掉value两边的空白符
		while(*value == ' ' || *value == '\t') {
			++value;
		}
		for(int i = strlen(value) - 1; i >= 0; --i) {
			if(value[i] == ' ' || value[i] == '\t' || value[i] == '\r' || value[i] == '\n') {
				value[i] = '\0';
			}
		}
		if(strlen(value) == 0) {
			continue;
		}
		// 保留key-value
		mKeyValMap[key] = value;
	}
	f.close();
	// 解析配置项
	for(map<string, string>::iterator it = mKeyValMap.begin(); it != mKeyValMap.end(); ++it) {
		if(it->first == "listenIP") {
			listenIP = it->second;
		} else if(it->first == "listenPort") {
			listenPort = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "netThreadNum") {
			netThreadNum = strtol(it->second.c_str(), NULL, 10);
			if(netThreadNum <= 0) {
				netThreadNum = 1;
			}
		} else if(it->first == "idleTime") {
			idleTime = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "readTime") {
			readTime = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "writeTime") {
			writeTime = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "maxPackLen") {
			maxPackLen = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "workerThreadNum") {
			workerThreadNum = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "queueSize") {
			queueSize = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "maxSessionNum") {
			maxSessionNum = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "downIdleTime") {
			downIdleTime = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "groupId") {
			groupId = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "groupSize") {
			groupSize = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "groupIndex") {
			groupIndex = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "routeType") {
			if(strcmp(it->second.c_str(), "rr") == 0) {
				routeType = ROUTE_RR;
			} else if(strcmp(it->second.c_str(), "hash") == 0) {
				routeType = ROUTE_HASH;
			} else if(strcmp(it->second.c_str(), "range") == 0) {
				routeType = ROUTE_RANGE;
			}
		} else if(it->first == "rangeFrom") {
			rangeFrom = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "rangeStop") {
			rangeStop = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "regSessionExpire") {
			regSessionExpire = strtol(it->second.c_str(), NULL, 10);
			if(regSessionExpire <= 0) {
				regSessionExpire = 2;
			}
		} else if(it->first == "regHost") {
			regHost = it->second;
		} else if(it->first == "regPath") {
			regPath = it->second;
		}
	}
	if(mKeyValMap.find("downConfNum") != mKeyValMap.end()) {
		int downConfNum = strtol(mKeyValMap["downConfNum"].c_str(), NULL, 10);
		for(uint32_t i = 0; i < downConfNum; ++i) {
			char downPathKey[128];
			char downGroupIdKey[128];
			sprintf(downPathKey, "downPath_%d", i);
			sprintf(downGroupIdKey, "downGroupId_%d", i);
			if(mKeyValMap.find(downPathKey) == mKeyValMap.end() || mKeyValMap.find(downGroupIdKey) == mKeyValMap.end()) {
				assert(false);
			}
			string downPathValue = mKeyValMap[downPathKey];
			string downGroupIdValue = mKeyValMap[downGroupIdKey];
			if(downPathValue.empty() || downPathValue.at(0) != '/' || downPathValue.at(downPathValue.size() - 1) == '/') {
				assert(false);
			}
			map<string, set<uint32_t>>::iterator it = downNodeMap.find(downPathValue);
			if(it == downNodeMap.end()) {
				downNodeMap[downPathValue] = set<uint32_t>();
				it = downNodeMap.find(downPathValue);
			}
			set<uint32_t> &downGroupIdSet = it->second;
			const char *groupIdPtr = downGroupIdValue.c_str();
			while(groupIdPtr[0] != '\0') {
				int32_t groupId = strtol(groupIdPtr, NULL, 10);
				downGroupIdSet.insert(groupId);
				groupIdPtr = strchr(groupIdPtr, ',');
				if(groupIdPtr == NULL) {
					break;
				}
				groupIdPtr++;
			}
		}
	}
}

