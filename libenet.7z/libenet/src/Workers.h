/*
 * Workers.h
 *
 *  Created on: Nov 9, 2020
 *      Author: bright
 */

#ifndef INCLUDE_WORKERS_H_
#define INCLUDE_WORKERS_H_

#include "Net.h"
#include "BlockQueue.h"
#include "Thread.h"
namespace enet {

class Workers: public ThreadPool {
	friend class WorkerThread;
	friend class HandlerProxy;

private:  // 实现ThreadPool接口
	// 创建线程实例
	Thread* CreateThread(int index);

	// 销毁线程实例
	void DestroyThread(Thread* thread);

public:
	Workers();

	// 代理上游处理器,返回代理处理器
	NetHandler* ProxyUpStreamHandler(NetHandler *handler);

	// 代理下游处理器,返回代理处理器
	NetHandler* ProxyDownStreamHandler(NetHandler *handler);

	// 开始工作者线程池
	void Start(unsigned threadNum, unsigned queueSize);

private:
	NetHandler *mUpStreamHandler;
	NetHandler *mDownStreamHandler;

	NetHandler *mUpStreamProxy;
	NetHandler *mDownStreamProxy;

	typedef struct {
		Net *net;
		ConnId connId;
		string pack;
		void *task;
	}NetPack;

	typedef enum {
		TYPE_NULL,
		TYPE_REQ,
		TYPE_RSP,
		TYPE_TASK
	}PackType;

	typedef struct  {
		PackType type;
		NetPack netPack;
		uint64_t readTime;
	}WorkerPack;
	BlockQueue<WorkerPack> mBlockQueue;
};


}
#endif /* INCLUDE_WORKERS_H_ */
