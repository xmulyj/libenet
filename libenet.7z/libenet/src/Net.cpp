/*
 * Net.cpp
 *
 *  Created on: Nov 1, 2020
 *      Author: bright
 */
#include "NetImp.h"
using namespace enet;


Net* Net::New(NetConf *conf) {
	Net* net = new XNet;
	net->mConf = conf;
	net->mConfOwn = false;
	return net;
}

Net* Net::New(const char *confPath) {
	assert(confPath != NULL);
	Net* net = new XNet;
	net->mConf = new NetConf;
	net->mConf->ParseFromFile(confPath);
	net->mConfOwn = true;
	return net;
}

void Net::Free(Net *net) {
	if(net == NULL) {
		return ;
	}
	if(net->mConfOwn) {
		delete net->mConf;
	}
	delete net;
}

Net::Net() {
	mConf = NULL;
	mConfOwn = false;
	mUpStreamSpliter = NULL;
	mUpStreamHandler = NULL;

	mDownStreamSpliter = NULL;
	mDownStreamHandler = NULL;

	mUpStreamTimerMs = 0;
	mDownStreamTimerMs = 0;
}

NetConf* Net::GetConf() {
	return mConf;
}

void Net::SetUpSteamHandler(PackSpliter *spliter, NetHandler *handler, uint32_t timerMs) {
	assert(spliter != NULL && handler != NULL);
	assert(mUpStreamSpliter == NULL && mUpStreamHandler == NULL);
	mUpStreamSpliter = spliter;
	mUpStreamHandler = handler;
	mUpStreamTimerMs = timerMs;
}

void Net::SetDownSteamHandler(PackSpliter *spliter, NetHandler *handler, uint32_t timerMs) {
	assert(spliter != NULL && handler != NULL);
	assert(mDownStreamSpliter == NULL && mDownStreamHandler == NULL);
	mDownStreamSpliter = spliter;
	mDownStreamHandler = handler;
	mDownStreamTimerMs = timerMs;
}

NetHandler* Net::UpStreamHandler() {
	return mUpStreamHandler;
}

NetHandler* Net::DownStreamHandler() {
	return mDownStreamHandler;
}

const char* enet::SendCodeStr(SendCode sendCode) {
	switch(sendCode) {
	case SEND_SUCC: return "SendSucc";
	case SEND_NETNOACTIVE: return "NetNoActive";
	case SEND_DOWNINVALID: return "DownNodeInvalid";
	case SEND_CONNIDINVALID: return "ConnIdInvalid";
	case SEND_IOERROR: return "IOError";
	}
	return "UnknowSendCode";
}
