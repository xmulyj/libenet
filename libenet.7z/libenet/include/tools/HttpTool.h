/*
 * HttpTool.h
 *
 *  Created on: Nov 11, 2020
 *      Author: bright
 */

#ifndef INCLUDE_TOOLS_HTTPTOOL_H_
#define INCLUDE_TOOLS_HTTPTOOL_H_

#include <assert.h>
#include <stdio.h>
#include <string.h>


#include <algorithm>
#include <map>
#include <string>
#include <sstream>
using namespace std;

namespace enet {

class HttpTool {
public:
	// 解析k=v&k=v格式(已做UrlDecode)
	static void ParseQuery(const char *data, int size, map<string, string> &m);

	// 对字符串进行URL编码
	// 参数:
	//     src: 待编码的字符串
	//     size: 待编码字符串的长度
	//     dst: 编码后字符串
	//     spacePlus: true时空格使用+号
	static void UrlEncode(const char *src, int size, string &dst, bool spacePlus = false);


	// 对字符串进行URL解码
	// 参数:
	//     src: 待解码的字符串
	//     size: 待解码字符串的长度
	//     dst: 解码后字符串
	// 失败返回false, dst只返回解码正确的部分
	static bool UrlDecode(const char *src, int size, string &dst);

	// 字符转16进制数值,成功返回true
	static bool Char2HexNum(char &ch);
};

class HttpReq {
public:
	HttpReq();
	void Reset();

	// 解析http请求
	bool Parse(const char *data, int size);

	// 获取请求值, hasValue返回false时表示key不存在,返回空字符串
	const string& Value(string key, bool *hasValue = NULL);
	const string& operator[](string key);

	// 获取请求头的值. hasValue返回false时表示key不存在,返回空字符串
	const string& HeaderValue(string key, bool *hasValue = NULL);

public:
	string method;      // http请求方法
	string url;         // url不包含请求参数
	string query;       // 请求串
	int mainVer;        // 主版本
	int subVer;         // 次版本
	map<string, string> param;  // 请求参数key-value
	map<string, string> head;   // 请求头key-value
};

class HttpRsp {
public:
	HttpRsp();

	void Reset();

	// 设置响应行
	void SetStatus(int code, string &status, int mainVer=1, int subVer=1);

	// 设置响应头
	void SetHead(const char *key, const char *value);
	void SetHead(const char *key, unsigned long long value);

	// 输出响应头
	void Output(string &s);

private:
	int code;
	string status;
	int mainVer;
	int subVer;
	map<string, string> head;
};



inline
bool HttpTool::Char2HexNum(char &ch) {
	if(ch>='0' && ch<='9') {
		ch = (char)(ch - '0');
		return true;
	} else if(ch>='a' && ch<='f') {
		ch = (char)(ch - 'a' + 10);
		return true;
	} else if(ch>='A' && ch<='F') {
		ch = (char)(ch - 'A' + 10);
		return true;
	}
	return false;
}

inline
void HttpTool::UrlEncode(const char *src, int size, string &dst, bool spacePlus) {
	dst = "";
	if(src == NULL || size <= 0) {
		return ;
	}
	dst.reserve(size * 3 + 10);
	for (int i = 0; i < size; i++) {
		char c = src[i];
		if ((c >= 'A' && c <= 'Z')
			|| (c >= 'a' && c <= 'z')
			|| (c >= '0' && c <= '9')) {
			dst += c;
		} else if(c == ' ' && spacePlus == true) {
			dst += '+';
		} else {
			char t[10];
			sprintf(t, "%%%02X", (unsigned char)c);
			dst += t;
		}
	}
}

inline
bool HttpTool::UrlDecode(const char* src, int size, string &dst) {
	dst = "";
	if(src == NULL || size <= 0) {
		return true;
	}
	dst.reserve(size + 10);
	for (int i = 0; i < size; i++) {
		char c = src[i];
		if(c == '+') {
			dst += ' ';
			continue;
		} else if(c == '%') {
			if (i + 2 >= size) {
				return false;
			}
			char c1 = src[i + 1];
			char c2 = src[i + 2];
			if (!Char2HexNum(c1) || !Char2HexNum(c2)) {
				return false;
			}
			dst += (char)((c1<<4) | c2);
			i += 2;
		} else {
			dst += c;
		}
	}
	return true;
}


inline
HttpReq::HttpReq() {
	Reset();
}

inline
void HttpReq::Reset() {
	method = "";
	url = "";
	query = "";
	mainVer = -1;
	subVer = -1;
	param.clear();
	head.clear();
}


const string& HttpReq::Value(string key, bool *hasValue) {
	static const string emptyStr;

    transform(key.begin(),key.end(),key.begin(), ::tolower);
	map<string, string>::iterator it = param.find(key);
	if(hasValue != NULL) {
		*hasValue = (it != param.end());
	}
	return it == param.end() ? emptyStr : it->second;
}

inline
const string& HttpReq::operator[](string key) {
	return Value(key, NULL);
}

// 获取请求头的值. hasValue返回false时表示key不存在,返回空字符串
const string& HttpReq::HeaderValue(string key, bool *hasValue) {
	static const string emptyStr;

	transform(key.begin(),key.end(),key.begin(), ::tolower);
	map<string, string>::iterator it = head.find(key);
	if(hasValue != NULL) {
		*hasValue = (it != head.end());
	}
	return it == head.end() ? emptyStr : it->second;
}


#define SKIP_CHAR(p0, end, c) for(; p0 < end && *p0 == c; ++p0) {} if(p0 >= end) return false
#define SKIP_CRLF(p) if(*p != '\r' || *(p+1) != '\n') { return false; } p += 2
#define FIND_CHAR(p0, p1, end, c) for(p1 = p0; p1 < end && *p1 != c; ++p1) {} if(p1 >= end) return false
#define FIND_CHAR_STOP(p0, p1, end , c) for(p1 = p0; p1 < end && *p1 != c; ++p1) {}

inline
void HttpTool::ParseQuery(const char *data, int size, map<string, string> &m) {
	if(data == NULL) {
		return ;
	}
	const char *k = data;
	const char *e = k + size;
	while(k < e) {
		const char *v = NULL;
		const char *s = NULL;
		FIND_CHAR_STOP(k, s, e, '&');
		FIND_CHAR_STOP(k, v, s, '=');
		if(k < v && v < s) {
			++v;
			string key;
			string value;
			if(UrlDecode(k, v - k - 1, key) == true && UrlDecode(v, s - v, value) == true) {
				m[key] = value;
			}
		}
		k = s + 1;
	}
}

inline
bool HttpReq::Parse(const char *data, int size) {
	const char* const ptrEnd = data + size;
	const char* pos0 = data;
	const char* pos1 = NULL;
	const char* posTemp = NULL;
	int ret = 0;

	// 解析请求行
	// 1.解析请求方法
	FIND_CHAR(pos0, pos1, ptrEnd, ' ');
	method.assign(pos0, pos1 - pos0);
	pos0 = pos1;
	// 2.解析url和param
	SKIP_CHAR(pos0, ptrEnd, ' ');
	FIND_CHAR(pos0, pos1, ptrEnd, ' ');
	FIND_CHAR_STOP(pos0, posTemp, pos1, '?');
	url.assign(pos0, posTemp - pos0);
	if(posTemp >= pos1) {
		query = "";
	} else {
		++posTemp;
		query.assign(posTemp, pos1 - posTemp);
	}
	pos0 = pos1;
	// 3.解析版本号
	SKIP_CHAR(pos0, ptrEnd, ' ');
	if(strncmp(pos0, "HTTP/", 5) != 0) {
		return false;
	}
	pos0 += 5;
	FIND_CHAR(pos0, pos1, ptrEnd, '\r');
	ret = sscanf(pos0, "%d.%d", &mainVer, &subVer);
	if(ret != 2) {
		return false;
	}
	pos0 = pos1;
	SKIP_CRLF(pos0);  // 跳过\r\n

	// 解析请求头
	const char* ptrLineEnd = NULL;
	while(true) {
		FIND_CHAR(pos0, ptrLineEnd, ptrEnd, '\r');
		if(ptrLineEnd == pos0) {
			break;
		}
		// key
		FIND_CHAR(pos0, pos1, ptrLineEnd, ':');
		string key(pos0, pos1 - pos0);
		// value
		pos0 = pos1 + 1;
		SKIP_CHAR(pos0, ptrLineEnd, ' ');
		string value(pos0, ptrLineEnd - pos0);

		transform(key.begin(),key.end(),key.begin(), ::tolower);
		head[key] = value;
		// 跳到下一行
		pos0 = ptrLineEnd;
		SKIP_CRLF(pos0);
	}
	SKIP_CRLF(pos0);
	if(pos0 > ptrEnd) {
		return false;
	}

	// 设置请求串
	if(method == "POST") {
		const char* str = "Content-Length";
		if(head.find(str) == head.end()) {
			return false;
		}
		int contentLength = -1;
		if(sscanf(head[str].c_str(), "%d", &contentLength) != 1 || contentLength < 0) {
			return false;
		}
		if(pos0 + contentLength > ptrEnd) {
			return false;
		}
		query.assign(pos0, contentLength);
		pos0 += contentLength;
	}
	map<string, string>::iterator it = head.find("Content-Type");
	if(method == "GET" || (it != head.end() && it->second.find("x-www-form-urlencoded") != string::npos)) {
		HttpTool::ParseQuery(query.c_str(), query.size(), param);
	}
	return true;
}

#undef SKIP_CHAR
#undef SKIP_LINE
#undef FIND_CHAR
#undef FIND_CHAR_STOP

inline
HttpRsp::HttpRsp() {
	Reset();
}

inline
void HttpRsp::Reset() {
	code = 200;
	status = "OK";
	mainVer = 1;
	subVer = 1;
}

inline
void HttpRsp::SetStatus(int code, string &status, int mainVer, int subVer) {
	this->code = code;
	this->status = status;
	this->mainVer = mainVer;
	this->subVer = subVer;
}

inline
void HttpRsp::SetHead(const char *key, const char *value) {
	assert(key != NULL && value != NULL);
	head[key] = value;
}

inline
void HttpRsp::SetHead(const char *key, unsigned long long value) {
	assert(key != NULL);
	ostringstream os;
	os.str("");
	os << value;
	head[key] = os.str();
}

inline
void HttpRsp::Output(string &s) {
	ostringstream os;
	os.str("");
	os << "HTTP/"<<mainVer<<"."<<subVer<<" "<<code<<" "<<status<<"\r\n";
	for(map<string, string>::iterator it = head.begin(); it != head.end(); ++it) {
		os<<it->first<<": "<<it->second<<"\r\n";
	}
	os<<"\r\n";
	s = os.str();
}

}
#endif /* INCLUDE_TOOLS_HTTPTOOL_H_ */
