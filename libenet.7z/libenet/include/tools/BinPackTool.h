/*
 * BinPackTool.h
 *
 *  Created on: Nov 14, 2020
 *      Author: bright
 */

#ifndef INCLUDE_TOOLS_BINPACKTOOL_H_
#define INCLUDE_TOOLS_BINPACKTOOL_H_

#include <assert.h>
#include <netinet/in.h>
#include <stddef.h>

#include <string>
using std::string;

namespace enet {

class BinPack {
public:
	static const unsigned SizeOffset = 4;           // 包长偏移
	static const unsigned SizeBytes = 4;            // 包长字节数
	static const unsigned HeadSize = 8;             // 头部长度
	static const unsigned IncludeHeadSize = false;  // 包长是否包含头部长度

public:
	BinPack();
	void Reset();

	// 解析二进制帧.成功返回0. 除了Reset之外,其他方法必须Parse返回0之后才可用
	int Parse(const char *frame, unsigned int size);

	// 是否最后一帧
	bool IsFinFrame();

	// 数据
	const char* Data();

	// 数据长度
	unsigned int DataSize();

	// 构建二进制包头
	static string MakeFrameHeader(unsigned int dataSize, bool fin = true);

	// 构建二进制数据包
	static string MakeFrame(const string &data, bool fin = true);

private:
	bool mValid;    // 数据是否有效
	char mFin;      // 0分组包第1帧或者中间帧, 1分组包最后一帧
	const char *mBody;       // 数据指针
	unsigned int mBodySize;  // 包长
};

inline
BinPack::BinPack() {
	Reset();
}

inline
void BinPack::Reset() {
	mValid = false;
	mFin = 0;
	mBodySize = 0;
	mBody = NULL;
}

inline
int BinPack::Parse(const char *frame, unsigned int size) {
	mValid = false;
	if(frame == NULL || size < HeadSize) {
		return -1;
	}
	if(frame[0] != 'B' || frame[1] != 'I' || frame[2] != 'N') {
		return -2;
	}
	mFin = frame[3];
	unsigned int temp = *(unsigned int*)(frame + 4);
	mBodySize = ntohl(temp);
	if(HeadSize + mBodySize > size) {
		return -3;
	}
	mBody = frame + HeadSize;

	mValid = true;
	return 0;
}

inline
bool BinPack::IsFinFrame() {
	return mFin;
}

inline
const char* BinPack::Data() {
	return mBody;
}

inline
unsigned int BinPack::DataSize() {
	return mBodySize;
}

inline
string BinPack::MakeFrameHeader(unsigned int dataSize, bool fin) {
	string frame = "BIN";
	char c = (fin ? 1 : 0);
	frame += c;
	unsigned int bodySize = htonl(dataSize);
	frame.append((char*)&bodySize, 4);
	return frame;
}

inline
string BinPack::MakeFrame(const string &data, bool fin) {
	string frame = MakeFrameHeader(data.size(), fin);
	frame += data;
	return frame;
}

}
#endif /* INCLUDE_TOOLS_BINPACKTOOL_H_ */
