/*
 * JsonTool.h
 *
 *  Created on: Jan 15, 2018
 *      Author: bright
 */

#ifndef LIBENET_TOOLS_JSONTOOL_H_
#define LIBENET_TOOLS_JSONTOOL_H_

#include <string>
using std::string;
#include <fstream>
using std::ifstream;
#include <ostream>
using std::ostream;

#include <json/json.h>

namespace enet {

class JsonTool {
public:
	static bool ParseFromFile(Json::Value& jsonObj, const char* fileName);
	static bool ParseFromStr(Json::Value& jsonObj, const string& str);
	static bool ParseFromStr(Json::Value& jsonObj, const char* str, unsigned int size);
	static bool WriteToFile(Json::Value& jsonObj, const char* fileName, bool styled = false);
	static bool WriteToStr(Json::Value& jsonObj, string& str, bool styled = false);
	static bool WriteToStream(Json::Value& jsonObj, ostream* os, bool styled = false);
};

inline
bool JsonTool::ParseFromFile(Json::Value& jsonObj, const char* fileName) {
	ifstream ifs;
	ifs.open(fileName, std::ios::in);
	if(ifs.fail()) {
		return false;
	}
#ifdef JSON_VERSION_OLD
	Json::Reader reader;
	bool ret = reader.parse(ifs, jsonObj);
#else
	Json::CharReaderBuilder builder;
	bool ret = parseFromStream(builder, ifs, &jsonObj, NULL);
#endif
	ifs.close();
	return ret;
}

inline
bool JsonTool::ParseFromStr(Json::Value& jsonObj, const string& str) {
#ifdef JSON_VERSION_OLD
	Json::Reader reader;
	return reader.parse(str, jsonObj);
#else
	Json::CharReaderBuilder builder;
	Json::CharReader* reader = builder.newCharReader();
	bool ret = reader->parse(str.c_str(), str.c_str() + str.size(), &jsonObj, NULL);
	delete reader;
	return ret;
#endif
}

inline
bool JsonTool::ParseFromStr(Json::Value& jsonObj, const char* str, unsigned int size) {
#ifdef JSON_VERSION_OLD
	Json::Reader reader;
	return reader.parse(str, str + size, jsonObj);
#else
	Json::CharReaderBuilder builder;
	Json::CharReader* reader = builder.newCharReader();
	bool ret = reader->parse(str, str + size, &jsonObj, NULL);
	delete reader;
	return ret;
#endif
}

inline
bool JsonTool::WriteToFile(Json::Value& jsonObj, const char* fileName, bool styled/* = false*/) {
	std::ofstream ofs;
	ofs.open(fileName, std::ios::out);
	if(ofs.fail()) {
		return false;
	}
#ifdef JSON_VERSION_OLD
	Json::StyledStreamWriter writer;
	writer.write(ofs, jsonObj);
#else
	Json::StreamWriterBuilder builder;
	builder.settings_["emitUTF8"] = true;  // 中文输出为utf编码(默认unicode编码)
	if(styled == false) {
		builder.settings_["indentation"] = "";
	}
	Json::StreamWriter* writer = builder.newStreamWriter();
	writer->write(jsonObj, &ofs);
	delete writer;
#endif
	ofs.close();

	return true;
}

inline
bool JsonTool::WriteToStr(Json::Value& jsonObj, string& str, bool styled/* = false*/) {
#ifdef JSON_VERSION_OLD
	if(styled) {
		str = jsonObj.toStyledString();
	} else {
		Json::FastWriter writer;
		str = writer.write(jsonObj);
	}
#else
	Json::StreamWriterBuilder builder;
	builder.settings_["emitUTF8"] = true;  // 中文输出为utf编码(默认unicode编码)
	if(styled == false) {
		builder.settings_["indentation"] = "";
	}
	str = Json::writeString(builder, jsonObj);
#endif
	return true;
}

inline
bool JsonTool::WriteToStream(Json::Value& jsonObj, ostream* os, bool styled/* = false*/) {
#ifdef JSON_VERSION_OLD
	Json::StyledStreamWriter writer;
	writer.write(ofs, jsonObj);
#else
	Json::StreamWriterBuilder builder;
	builder.settings_["emitUTF8"] = true;  // 中文输出为utf编码(默认unicode编码)
	if(styled == false) {
		builder.settings_["indentation"] = "";
	}
	Json::StreamWriter* writer = builder.newStreamWriter();
	writer->write(jsonObj, os);
	delete writer;
#endif
	return true;
}


}
#endif /* LIBENET_TOOLS_JSONTOOL_H_ */
