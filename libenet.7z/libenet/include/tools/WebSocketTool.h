/*
 * WebSocketTool.h
 *
 *  Created on: Nov 13, 2020
 *      Author: bright
 */

#ifndef INCLUDE_TOOLS_WEBSOCKETTOOL_H_
#define INCLUDE_TOOLS_WEBSOCKETTOOL_H_

#include "openssl/sha.h"

#include "Base64Tool.h"
#include "HttpTool.h"
#include "NetTool.h"

namespace enet {



class WebSocketFrame {
public:
	typedef enum {
		TYPE_APPEND = 0,      // 后续帧
		TYPE_TXT = 1,         // 文本帧
		TYPE_BIN = 2,         // 二进制帧
		TYPE_RESV = 3,        // 保留
		TYPE_CLOSE = 8,       // 关闭链接
		TYPE_PING = 9,        // ping
		TYPE_PONG = 10,       // pong
	}Type;

public:
	WebSocketFrame();

	void Reset();

	// 解析websocket的数据帧.成功返回true. 除了Reset之外,其他方法必须Parse返回true之后才可用
	bool Parse(char *frame, int size);

	// 是否握手请求(http协议,请求转换为websocket协议)
	bool IsHandShakeFrame();

	// 是否是WebSocket帧
	bool IsWebSocketFrame();

	// 是否最后一帧
	bool IsFinFrame();

	// 帧类型
	Type FrameType();

	// 是否有掩码
	bool HasMask();

	// 帧头长度
	int HeadSize();

	// 帧数据
	char* Data();

	// 帧数据长度
	unsigned long long DataSize();

	// close帧信息
	int CloseCode();
	char* CloseReason();
	int CloseReasonSize();

	// 生成握手请求的回包.
	// 参数:
	//     httpReq: 握手请求包
	// 返回值: 空字符串表示数据帧无效.非空字符串表示数据帧有效,生成握手回包(http响应包)
	static string MakeHandShakeRsp(HttpReq &httpReq);

	// 掩码操作
	static void Mask(char *data, unsigned int size, const char *maskKey);

	// 生成帧头
	// 参数:
	//     type: 帧类型
	//     dataSize: 数据长度
	//     maskKey: 掩码key,NULL时不做掩码
	//     fin: 是否最后一帧
	static string MakeFrameHeader(Type type, unsigned int dataSize, const char *maskKey = NULL, bool fin = true);

	// 生存数据帧
	// 参数:
	//     type: 帧类型
	//     data: 数据
	//     maskKey: 掩码key,NULL时不做掩码
	//     fin: 是否最后一帧
	static string MakeFrame(Type type, const string &data, const char *maskKey = NULL, bool fin = true);

	static string MakePingFrame(const string &data);
	static string MakePongFrame(const string &data);
	static string MakeCloseFrame(short code, const string &data);
	// 浏览器给服务端发送一个close帧, 服务端回复一个close帧后关闭链接. 浏览器正常转为closed状态
	// 如果服务端没有回close帧,浏览器不会转为closed状态,如果服务端这个时候关闭,浏览器会弹undefined

	static const string& PingFrame();
	static const string& PongFrame();
	static const string& CloseFrame();

private:
	int mStatus;  // 0-未解析; 1-http握手请求; 2-websocket数据帧
	short mFin;
	Type mType;
	short mMask;

	int mHeadSize;
	unsigned long long mBodySize;
	char *mBody;

	unsigned short mCloseCode;
	char *mCloseReason;
	int mCloseReasonSize;

	Type GetFrameType(short opCode);
};

inline
WebSocketFrame::WebSocketFrame() {
	Reset();
}

inline
void WebSocketFrame::Reset() {
	mStatus = 0;
	mFin = 0;
	mType = TYPE_RESV;
	mMask = 0;

	mHeadSize = 0;
	mBodySize = 0;
	mBody = NULL;

	mCloseCode = 1005;  // no status set
	mCloseReason = NULL;
	mCloseReasonSize = 0;
}

inline
bool WebSocketFrame::Parse(char *frame, int size) {
	mStatus = 0;
	if(frame == NULL || size < 2) {
		return false;
	}

	bool isHandShake = (size >= 4) && (frame[0]=='G' && frame[1]=='E' && frame[2]=='T' && frame[3]==' ');
	if(!isHandShake) {
		mHeadSize = 2;
		mBodySize = 0;

		mType = GetFrameType(frame[0] & 0x0F);
		mFin = (frame[0] >> 7) & 0x01;
		mMask = (frame[1] >> 7) & 0x01;
		if(mType == TYPE_RESV) {
			return false;
		}
		//带有掩码,4个字节的key
		if(mMask != 0) {
			mHeadSize += 4;
		}
		//包体长度
		unsigned int lengthField = frame[1]&0x7F;
		if(lengthField <= 125) {
			mBodySize = lengthField;
		} else if(lengthField == 126) {
			mHeadSize += 2;
			unsigned short temp = *(unsigned short*)(frame + 2);
			mBodySize = ntohs(temp);
		} else if(lengthField == 127) {
			mHeadSize += 8;
			unsigned long long temp = *(unsigned long long*)(frame + 2);
			mBodySize = NetTool::ntohll(temp);
		}
		if(mHeadSize + mBodySize > size) {
			return false;
		}
		// 掩码处理
		mBody = frame + mHeadSize;
		if(mMask != 0) {
			char* maskKey = frame + mHeadSize - 4;
			if(mBodySize > 0) {
				Mask(mBody, mBodySize, maskKey);
			}
		}
		mCloseReason = mBody;
		if(mType == TYPE_CLOSE && mBodySize >= 2) {
			unsigned short temp = *(unsigned short*)(mBody + 2);
			mCloseCode = ntohs(temp);
			mCloseReason = mBody + 2;
			mCloseReasonSize = mBodySize -2;
		}
	}
	mStatus = (isHandShake ? 1: 2);
	return true;
}

inline
bool WebSocketFrame::IsHandShakeFrame() {
	return mStatus == 1;
}

inline
bool WebSocketFrame::IsWebSocketFrame() {
	return mStatus == 2;
}

inline
bool WebSocketFrame::IsFinFrame() {
	return mFin != 0;
}

inline
WebSocketFrame::Type WebSocketFrame::FrameType() {
	return mType;
}

inline
bool WebSocketFrame::HasMask() {
	return mMask != 0;
}

inline
int WebSocketFrame::HeadSize() {
	return mHeadSize;
}

inline
char* WebSocketFrame::Data() {
	return mBody;
}

inline
unsigned long long WebSocketFrame::DataSize() {
	return mBodySize;
}

inline
int WebSocketFrame::CloseCode() {
	return mCloseCode;
}

inline
char* WebSocketFrame::CloseReason() {
	return mCloseReason;
}

inline
int WebSocketFrame::CloseReasonSize() {
	return mCloseReasonSize;
}

inline
WebSocketFrame::Type WebSocketFrame::GetFrameType(short opCode){
	static Type typeMap[16] = {
		TYPE_APPEND, TYPE_TXT, TYPE_BIN,
		TYPE_RESV, TYPE_RESV, TYPE_RESV, TYPE_RESV, TYPE_RESV,
		TYPE_CLOSE, TYPE_PING, TYPE_PONG,
		TYPE_RESV, TYPE_RESV, TYPE_RESV, TYPE_RESV, TYPE_RESV
	};
	return typeMap[opCode];
}


inline
string WebSocketFrame::MakeHandShakeRsp(HttpReq &httpReq) {
	string answer;

	string acceptKey = httpReq.HeaderValue("Sec-WebSocket-Key");
	if(!acceptKey.empty()) {
		acceptKey += "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"; //RFC6544_MAGIC_KEY
		unsigned char digest[SHA_DIGEST_LENGTH];
		SHA1((const unsigned char*)acceptKey.c_str(), (size_t)acceptKey.size(), digest);
		acceptKey = Base64Tool::Encode((const char*)digest, SHA_DIGEST_LENGTH);

		answer += "HTTP/1.1 101 Switching Protocols\r\n";
		answer += "Upgrade: WebSocket\r\n";
		answer += "Connection: Upgrade\r\n";
		answer += "Sec-WebSocket-Accept: " + acceptKey + "\r\n";
		string protocol = httpReq["Sec-WebSocket-Protocol"];
		if(!protocol.empty()) {
			answer += "Sec-WebSocket-Protocol: " + protocol + "\r\n";
		}
		answer += "\r\n";
	}
	return answer;
}

inline
void WebSocketFrame::Mask(char* data, unsigned int size, const char *maskKey) {
	if(data == NULL || maskKey == NULL) {
		return ;
	}
	for(unsigned int i = 0; i < size; ++i) {
		data[i] = data[i]^maskKey[i%4];
	}
}

inline
string WebSocketFrame::MakeFrameHeader(Type type, unsigned int dataSize, const char *maskKey, bool fin) {
	string frame;
	frame.reserve(32);

	assert(type != TYPE_RESV);
	if(type == TYPE_PING || type == TYPE_PONG || type == TYPE_CLOSE) {
		assert(dataSize <= 125);
		frame += (unsigned char)((1 << 7) | type);
		frame += (unsigned char)dataSize;
		return frame;
	}
	unsigned char _fin = (fin ? 1: 0);
	unsigned char _mask = (maskKey != NULL ? 1 : 0);
	unsigned char c = ((_fin << 7) | type);
	frame += c;
	if(dataSize <= 125) {
		c = ((_mask << 7) | dataSize);
		frame += c;
	} else if(dataSize <= 65535) {
		c = ((_mask << 7) | 126);
		frame += c;
		unsigned short len = htons((unsigned short)dataSize);  //长度字段2字节
		frame.append((const char*)&len, 2);
	} else {
		c = ((_mask << 7) | 127);
		frame += c;
		uint64_t len = NetTool::htonll((uint64_t)dataSize);  //长度字段8字节
		frame.append((const char*)&len, sizeof(uint64_t));
	}
	if(maskKey != NULL) {
		frame.append(maskKey, 4);
	}
	return frame;
}

inline
string WebSocketFrame::MakeFrame(Type type, const string &data, const char *maskKey, bool fin) {
	string frameStr = MakeFrameHeader(type, data.size(), maskKey, fin);
	unsigned int headSize = frameStr.size();
	frameStr += data;
	if(maskKey != NULL) {
		char *dataPtr = (char*)frameStr.data() + headSize;
		Mask(dataPtr, frameStr.size() - headSize, maskKey);
	}
	return frameStr;
}

inline
string WebSocketFrame::MakePingFrame(const string &data) {
	string frameStr = MakeFrameHeader(TYPE_PING, data.size(), NULL);
	frameStr += data;
	return frameStr;
}

inline
string WebSocketFrame::MakePongFrame(const string &data) {
	string frameStr = MakeFrameHeader(TYPE_PONG, data.size(), NULL);
	frameStr += data;
	return frameStr;
}

inline
string WebSocketFrame::MakeCloseFrame(short code, const string &reason) {
	string closeFrame = MakeFrameHeader(TYPE_CLOSE, 2 + reason.size(), NULL);
	unsigned short closeCode = htons(code);
	closeFrame.append((char*)&closeCode, 2);
	closeFrame += reason;
	return closeFrame;
}

inline
const string& WebSocketFrame::PingFrame() {
	static string frameStr;
	if(frameStr.size() == 0) {
		frameStr = MakePingFrame("");
	}
	return frameStr;
}

inline
const string& WebSocketFrame::PongFrame() {
	static string frameStr;
	if(frameStr.size() == 0) {
		frameStr = MakePongFrame("");
	}
	return frameStr;
}

inline
const string& WebSocketFrame::CloseFrame() {
	static string frameStr;
	if(frameStr.size() == 0) {
		frameStr = MakeCloseFrame(1000, "close normal");
	}
	return frameStr;
}

}
#endif /* INCLUDE_TOOLS_WEBSOCKETTOOL_H_ */
