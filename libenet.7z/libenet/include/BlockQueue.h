/*
 * BlockQueue.h
 *
 *  Created on: Dec 28, 2019
 *      Author: bright
 */

#ifndef LIBENET_BLOCKQUEUE_H_
#define LIBENET_BLOCKQUEUE_H_

#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdint.h>

#include <list>
using std::list;

namespace enet {

template<typename T>
class BlockQueue {
public:
	BlockQueue();
	~BlockQueue();
	// 初始化(返回0成功,其他失败)
	int Init(uint32_t capacity);

	// 一直等待直到操作成功或者失败(返回0成功,其他失败)
	int Push(const T& element);
	int Pop(T& element);
	// 一直等待直到操作成功或者失败,或者超时(单位微秒)(返回0成功,小于0失败,1超时)
	int Push(const T& element, uint32_t timeUS);
	int Pop(T& element, uint32_t timeUS);

	// 返回队列元素个数
	uint32_t Size();
	// 返回队列容量大小
	uint32_t Capacity();
private:
	list<T> mList;
	sem_t mEmptySem;
	sem_t mExistSem;
	uint32_t mCapacity;
	pthread_mutex_t mLock;
};

template<typename T>
BlockQueue<T>::BlockQueue() {
	mCapacity = 0;
	pthread_mutex_init(&mLock, NULL);
}
template<typename T>
BlockQueue<T>::~BlockQueue() {
	pthread_mutex_destroy(&mLock);
}
template<typename T>
int BlockQueue<T>::Init(uint32_t capacity) {
	assert(mCapacity == 0 && capacity > 0);  // 不能多次初始化
	mCapacity = capacity;
	if(sem_init(&mEmptySem, 0, mCapacity) != 0) {
		return -1;
	}
	if(sem_init(&mExistSem, 0, 0) != 0) {
		return -2;
	}
	return 0;
}
template<typename T>
int BlockQueue<T>::Push(const T& element) {
	assert(mCapacity > 0);
	while(true) {
		if(sem_wait(&mEmptySem) == 0) {
			break;
		} else if(errno == EINTR) {
			continue;
		}
		return -1;
	}
	int ret = pthread_mutex_lock(&mLock);
	if(ret != 0) {
		pthread_mutex_unlock(&mLock);
		return -2;
	}
	mList.push_back(element);
	sem_post(&mExistSem);
	pthread_mutex_unlock(&mLock);
	return 0;
}
template<typename T>
int BlockQueue<T>::Pop(T& element) {
	assert(mCapacity > 0);
	while(true) {
		if(sem_wait(&mExistSem) == 0) {
			break;
		} else if(errno == EINTR) {
			continue;
		}
		return -1;
	}
	int ret = pthread_mutex_lock(&mLock);
	if(ret != 0) {
		pthread_mutex_unlock(&mLock);
		return -2;
	}
	element = mList.front();
	mList.pop_front();
	sem_post(&mEmptySem);
	pthread_mutex_unlock(&mLock);
	return 0;
}
template<typename T>
int BlockQueue<T>::Push(const T& element, uint32_t timeUS) {
	assert(mCapacity > 0);
	struct timespec ts;
	ts.tv_sec = time(NULL);
	ts.tv_nsec = 0;
	if(timeUS >= 1000000) {
		ts.tv_sec += timeUS / 1000000;
		ts.tv_nsec = (timeUS % 1000000) * 1000;
	} else {
		ts.tv_nsec = timeUS * 1000;
	}
	while(true) {
		if(sem_timedwait(&mEmptySem, &ts) == 0) {
			break;
		} else if(errno == EINTR) {
			continue;
		} else if(errno == ETIMEDOUT) {
			return 1;
		}
		return -1;
	}
	int ret = pthread_mutex_lock(&mLock);
	if(ret != 0) {
		pthread_mutex_unlock(&mLock);
		return -2;
	}
	mList.push_back(element);
	sem_post(&mExistSem);
	pthread_mutex_unlock(&mLock);
	return 0;
}
template<typename T>
int BlockQueue<T>::Pop(T& element, uint32_t timeUS) {
	assert(mCapacity > 0);
	struct timespec ts;
	ts.tv_sec = time(NULL);
	ts.tv_nsec = 0;
	if(timeUS >= 1000000) {
		ts.tv_sec += timeUS / 1000000;
		ts.tv_nsec = (timeUS % 1000000) * 1000;
	} else {
		ts.tv_nsec = timeUS * 1000;
	}
	while(true) {
		if(sem_timedwait(&mExistSem, &ts) == 0) {
			break;
		} else if(errno == EINTR) {
			continue;
		} else if(errno == ETIMEDOUT) {
			return 1;
		}
		return -1;
	}
	int ret = pthread_mutex_lock(&mLock);
	if(ret != 0) {
		pthread_mutex_unlock(&mLock);
		return -2;
	}
	element = mList.front();
	mList.pop_front();
	sem_post(&mEmptySem);
	pthread_mutex_unlock(&mLock);
	return 0;
}
template<typename T>
uint32_t BlockQueue<T>::Size() {
	int size = 0;
	sem_getvalue(&mExistSem, &size);
	return size >= 0 ? size : 0;
}
template<typename T>
uint32_t BlockQueue<T>::Capacity() {
	return mCapacity;
}

}
#endif /* LIBENET_BLOCKQUEUE_H_ */
