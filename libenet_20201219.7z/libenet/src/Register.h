/*
 * Register.h
 *
 *  Created on: Dec 2, 2020
 *      Author: bright
 */

#ifndef SRC_REGISTER_H_
#define SRC_REGISTER_H_

#include "NetConf.h"

#define DISCOVERY
#ifdef DISCOVERY

#include <zookeeper/zookeeper.h>

namespace enet {

class Net;
class Register {
public:
	Register();
	void Init(Net *net, NetConf *netConf);
	void KeepConnect(uint32_t waitMS);
	void CloseConnect();

private:
	Net *mNet;
	NetConf *mNetConf;
	zhandle_t *mHandler;

	bool needClear;  // 重启后连接没有超时的情况下恢复会话,但是临时节点还在,就一直无法注册,所以需要关闭会话重新连接
	clientid_t mClientId;
	void SaveClientId();
	void LoadClientId();

	void Connect();
	void OnConnected();
	void OnChildrenChange(const char *path);

	int GetDownNodeList();  // 获取下游路径的节点列表,返回还未获取的下游路径数量
	int GetDownNodeData();  // 获取下游节点的节点数据,返回还未获取数据的下游节点数量
	void RegService();      // 注册自己提供服务

private:
	typedef enum {
		STATUS_WAIT,        // 待执行
		STATUS_PENDING,     // 执行中
		STATUS_FINISHED     // 已完成
	}RegStatus;

	// zk节点信息
	class RegInfo {
	public:
		Register *mRegister;
		string path;
		string value;
		RegStatus status;   // 0待创建, 1创建中, 2创建完成
		uint32_t tryCount;  // 重试次数
		uint64_t nextTs;    // 下次创建时间,0表示立即创建

		RegInfo(Register * regInst, const string &p) {
			mRegister = regInst;
			path = p;
			status = STATUS_WAIT;
			tryCount = 0;
			nextTs = 0;
		}

		RegInfo(Register * regInst, const string &p, const string &v) {
			mRegister = regInst;
			path = p;
			value = v;
			status = STATUS_WAIT;
			tryCount = 0;
			nextTs = 0;
		}

		void Reset() {
			status = STATUS_WAIT;
			tryCount = 0;
			nextTs = 0;
		}
	};

	// 注册节点集合
	map<string , RegInfo*> mRegPathValue;       // 需要注册的节点路径集合
	void GenRegPath();

	// 获取下游服务节点
	map<string, RegInfo*> mDownNodePathMap;     // 下游路径(不包含节点名称)的集合. 用来获取下游节点列表
	map<string, RegInfo*> mDownNodeDataMap;     // 下游节点(包含节点名称)的集合. 用来获取下游节点数据
	map<string, set<string>> mDownNodeNameMap;  // key:下游节点父路径, set元素: 下游节点名称. 用来处理当子节点变化时,删除下游节点
	void GenDownNodePath();

private:
	void CreateNode(RegInfo *regInfo);          // 创建节点
	void GetChildren(RegInfo *regInfo);         // 获取子节点列表
	void OnGetChildren(RegInfo *regInfo, const struct String_vector *strings);

	void GetChildrenData(RegInfo *regInfo);     // 获取所有子节点的数据
	void GetChildData(RegInfo *regInfo);        // 获取子节点数据
	void OnGetChildData(RegInfo *regInfo);

	// zk回调函数
	static void WatchFunc(zhandle_t *zh, int type, int state, const char *path,void *watcherCtx);
	static void CreateCompletion(int rc, const char *value, const void *data);
	static void GetChildrenCompletion(int rc, const struct String_vector *strings, const void *data);
	static void GetDataCompletion(int rc, const char *value, int value_len, const struct Stat *stat, const void *data);

};

}

#else
namespace enet {

class Net;
class Register {
public:
	Register() {}
	void Init(Net *net, NetConf *netConf) {}
	void KeepConnect() {}
	void CloseConnect() {}
};

}
#endif

#endif /* SRC_REGISTER_H_ */
