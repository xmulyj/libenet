/*
 * Logger.h
 *
 *  Created on: 2014-7-4
 *      Author: bright
 */

#ifndef LIBENET_TOOLS_LOGTOOL_H_
#define LIBENET_TOOLS_LOGTOOL_H_


#include <log4cplus/log4cplus.h>
using namespace log4cplus;

namespace enet {

#define INIT_LOGGER(conf_path)  log4cplus::initialize(); PropertyConfigurator::doConfigure(conf_path)
#define UNINIT_LOGGER()  log4cplus::Logger::shutdown()

#define DECL_LOGGER(logger) static Logger logger
#define IMPL_LOGGER_CLASS(classname, logger) Logger classname::logger = Logger::getInstance(#classname)
#define IMPL_LOGGER_CLASS_NAME(classname, logger, name) Logger classname::logger = Logger::getInstance(name)
#define IMPL_LOGGER_NAME(logger, name) static Logger logger = Logger::getInstance(name)

#define IMPL_LOGGER_TEMPLATE(classname, logger, temp_type) template<typename temp_type> Logger classname<temp_type>::logger = Logger::getInstance(#classname#temp_type)


#define LOG_TRACE(logger, log) LOG4CPLUS_TRACE(logger, log)
#define LOG_DEBUG(logger, log) LOG4CPLUS_DEBUG(logger, log)
#define LOG_INFO(logger, log) LOG4CPLUS_INFO(logger, log)
#define LOG_WARN(logger, log) LOG4CPLUS_WARN(logger, log)
#define LOG_ERROR(logger, log) LOG4CPLUS_ERROR(logger, log)
#define LOG_FATAL(logger, log) LOG4CPLUS_FATAL(logger, log)

}
#endif /* LIBENET_TOOLS_LOGTOOL_H_ */
