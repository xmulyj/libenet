/*
 * Base64Tool.h
 *
 *  Created on: 2015年12月16日
 *      Author: bright
 */

#ifndef LIBENET_TOOLS_BASE64TOOL_H_
#define LIBENET_TOOLS_BASE64TOOL_H_

#include <string>
using std::string;

namespace enet {

class Base64Tool {
public:
	// 将长度size的数据src进行base64编码到dst
	static string Encode(const char *src, int size);

	// 将长度size的数据src进行base64解码. 如果数据不完整或者错误,只返回解码正确的部分
	static string Decode(const char *src, int size);

	// 将长度size的数据src进行base64解码到dst. 如果数据不完整或者错误返回false, dst只包含解码正确的部分
	static bool Decode(const char *src, int size, string &dst);

	// 判断字符是否时base64编码的字符
    static bool IsBase64(unsigned char c);
};

inline
bool Base64Tool::IsBase64(unsigned char c) {
	return (isalnum(c) || (c == '+') || (c == '/'));
}

inline
string Base64Tool::Encode(const char *src, int size) {
	const string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

	string dst;
	if(src == NULL || size <= 0) {
		return dst;
	}
	dst.reserve(size * 2 + 10);

	int i = 0;
	unsigned char char_array_3[3] = {0};
	unsigned char char_array_4[4] = {0};
	while (size--) {
		char_array_3[i++] = *(src++);
		if (i == 3) {
			char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
			char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
			char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
			char_array_4[3] = char_array_3[2] & 0x3f;
			for(i = 0; i < 4; i++) {
				dst += base64_chars[char_array_4[i]];
			}
			i = 0;
		}
	}
	if (i > 0) {
		for(int j = i; j < 3; j++) {
			char_array_3[j] = 0;
		}
		char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
		char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
		char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
		char_array_4[3] = char_array_3[2] & 0x3f;
		for (int j = 0; j < i + 1; j++) {
			dst += base64_chars[char_array_4[j]];
		}
		while(i++ < 3) {
			dst += '=';
		}
	}
	return dst;
}

inline
string Base64Tool::Decode(const char *src, int size) {
	string dst;
	Decode(src, size, dst);
	return dst;
}

inline
bool Base64Tool::Decode(const char *src, int size, string &dst) {
	const string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

	dst.clear();
	if(src == NULL || size <= 0) {
		return true;
	}
	dst.reserve(size + 10);

	int in = 0;
	int i = 0;
	unsigned char char_array_3[3] = {0};
	unsigned char char_array_4[4] = {0};
	for(in = 0;  in < size && src[in] != '='; ++in) {
		if(!IsBase64(src[in])) {
			return false;
		}
		char_array_4[i++] = src[in];
		if (i == 4) {
			for (i = 0; i < 4; i++) {
				char_array_4[i] = (unsigned char)base64_chars.find(char_array_4[i]);
			}
			char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
			char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
			char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];
			for (i=0; i < 3; i++) {
				dst += char_array_3[i];
			}
			i = 0;
		}
	}
	if(i == 0) {
		return true;
	}
	if(i == 1) {  // 剩余1个字符, 没有数据或者跟着等号
		return false;
	}
	if(in >= size) {  // 剩余2个或3个字符, 后面没有数据了
		return false;
	}
	// 剩余2个或者3个字符,后面跟着等号
	for (int j = 0; j < i; j++) {
		char_array_4[j] = (unsigned char)base64_chars.find(char_array_4[j]);
	}
	for (int j = i; j < 4; j++) {
		char_array_4[j] = 0;
	}
	char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
	char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
	char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];
	for (int j = 0; j < i - 1; j++) {
		dst += char_array_3[j];
	}
	return true;
}


}
#endif /* LIBENET_TOOLS_BASE64TOOL_H_ */
