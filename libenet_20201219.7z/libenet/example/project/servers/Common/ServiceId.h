/*
 * ServiceId.h
 *
 *  Created on: Dec 7, 2020
 *      Author: bright
 */

#ifndef PROJECT_SERVERS_PROTOCOL_SERVICEID_H_
#define PROJECT_SERVERS_PROTOCOL_SERVICEID_H_


#define SVR_ID_TEST   1


#endif /* PROJECT_SERVERS_PROTOCOL_SERVICEID_H_ */
