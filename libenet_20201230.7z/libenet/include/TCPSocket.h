/*
 * TCPSocket.h
 *
 *  Created on: 2014-6-26
 *      Author: bright
 */

#ifndef LIBENET_TCPSOCKET_H_
#define LIBENET_TCPSOCKET_H_

#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#if defined(linux) || defined(__linux__)
    #include <unistd.h>
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <netdb.h>
    #include <errno.h>
    #include <fcntl.h>
 
    #define SOCKET int
    #define INVALID_SOCKET -1

    #ifndef sscanf_s
    #define sscanf_s sscanf
    #endif

    #ifndef _errno_
    #define _errno_ errno
    #endif

#elif defined(WIN32) || defined(WIN64)
    #include "WinSock2.h"
    #include "WS2tcpip.h"
    #include "io.h"

    #define EINTR                    WSAEINTR
    #define EWOULDBLOCK              WSAEWOULDBLOCK
    #define EINPROGRESS              WSAEINPROGRESS
    #define EAGAIN                   WSAEWOULDBLOCK

    #ifndef _errno_
    #define _errno_ h_errno
    #endif
#endif

namespace enet {

// 支持跨平台: linux, windows
#define SOCKET_WOULDBLOCK (_errno_ == EINTR || _errno_ == EAGAIN || _errno_ == EWOULDBLOCK)

class TCPSocket {
public:
    //监听端口,ip表示监听哪个网卡接口的ip,NULL时监听所有网卡;reuse:端口在已监听情况下,是否允许再次监听该端口
    static int Listen(int port, bool block=false, int backlog=128, bool reuse=true);
    static int Listen(const char* ip, int port, bool block=false, int backlog=128, bool reuse=true);
    //接收链接
    static int Accept(int fd);
    //接收链接
    static int Accept(int fd, struct sockaddr_in& peer_addr);


    //连接到指定的ip和端口,wait_ms在block=false时有效,表示等待连接的毫秒数,在这个时间内还未连接上的话返回失败.
    //连接成功返回fd,失败返回负数(具体值表示哪一步失败)
    static int Connect(const char* ip, int port, bool block=false, unsigned int wait_ms=0);


    //接收最多size个字节数,成功返回实际接收的字节数.0表示对方断开连接;负数表示失败(如果是非阻塞模式,看具体的errno)
    static int Recv(int fd, char* buffer, int size);
    //接收指定的size字节数.成功返回值大小为size;0表示对方断开连接;负数表示失败(如果是非阻塞模式,看具体的errno)
    static int RecvAll(int fd, char* buffer, int size);


    //发送最多size字节,成功返回实际发送的字节数
    static int Send(int fd, const char* buffer, int size);
    //发送全部指定的size字节,成功返回实际发送的字节数
    static int SendAll(int fd, const char* buffer, int size);


    //创建socket,返回值大于0表示fd, 小于0表示失败(具体值表示哪一步失败)
    static int CreateSocket(bool block=true, bool close_exec=false);
    static int CloseSocket(int fd);


    //判断addr是否是点分的ip地址
    static bool IsIp(const char* addr);
    //是否阻塞模式:0非阻塞;1阻塞;-1错误
    static bool IsBlock(int fd);
    //设置socket为阻塞状态
    static int SetBlock(int fd);
    //设置socket为非阻塞状态
    static int SetNoBlock(int fd);
    //设置close_exec
    static int SetCloseExec(int fd);

    //等待可读/写事件(wait_ms<0时一直阻塞直到fd上有事件发生;wait_ms>=0表示等待事件的时间)
    static int WaitRead(int fd, int wait_ms=1000);
    static int WaitWrite(int fd, int wait_ms=1000);

    //获取fd对应的ip/port信息
    static struct sockaddr_in GetSocketAddr(int fd);
};


}
#endif /* LIBENET_TCPSOCKET_H_ */
