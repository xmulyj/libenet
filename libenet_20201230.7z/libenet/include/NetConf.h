/*
 * Conf.h
 *
 *  Created on: Nov 18, 2020
 *      Author: bright
 */

#ifndef INCLUDE_NETCONF_H_
#define INCLUDE_NETCONF_H_


#include <map>
#include <set>
#include <string>
using std::map;
using std::set;
using std::string;

#include "tools/LogTool.h"
namespace enet {


// 网络模块参数
class NetConf {
public:
	NetConf();

	// 从文件解析参数.后加载的配置项覆盖先加载的配置项
	void ParseFromFile(const char *file);

public:
	// 所有配置项
	map<string, string> mKeyValMap;
	// 网络模块参数
	string listenIP;       // 监听ip
	int listenPort;        // 监听端口
	int netThreadNum;      // 网络IO线程数(默认1)
	int idleTime;          // 链接空闲时间(默认30s)
	int readTime;          // 数据包读取最长时间(默认3s)
	int writeTime;         // 数据包发送最长时间(默认3s)
	int maxPackLen;        // 数据包最大长度(默认4K)

	int workerThreadNum;   // 工作线程数据(默认1)
	int queueSize;         // 工作线程阻塞队列(默认128)

	int maxSessionNum;     // 最大session数(默认128)
	int downIdleTime;      // 下游链接空闲时间(默认10s)

	// 服务发现模块参数
	int groupId;           // 集群id(默认-1, 大等于0时有效, 开启注册服务)
	int routeType;         // 路由方式(默认-1, 大等于0时有效)
	int groupSize;         // 集群大小(默认-1, 大于0时有效, hash路由方式时必填)
	int groupIndex;        // 服务器在集群中的index(默认-1, 大等于0时有效)
	int rangeFrom;         // 路由范围(默认-1, 大等于0时有效)
	int rangeStop;         // 路由范围(默认-1, 大等于0时有效)
	int regSessionExpire;  // 注册过期时间(默认2s)
	string regHost;        // 注册中心zk的地址[列表]
	set<uint32_t> downGroupIdSet;  // 下游节点的groupId集合

public:
	DECL_LOGGER(downLogger);  // 下游log
	DECL_LOGGER(netLogger);   // 网络log
	DECL_LOGGER(regLogger);   // 注册服务log
	DECL_LOGGER(svrLogger);   // 服务器log
};

#define UP_LOGGER NetConf::netLogger
#define DO_LOGGER NetConf::downLogger
#define REG_LOGGER NetConf::regLogger
#define SVR_LOGGER NetConf::svrLogger

}
#endif /* INCLUDE_NETCONF_H_ */
