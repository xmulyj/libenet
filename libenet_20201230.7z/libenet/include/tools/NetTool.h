/*
 * htonll.h
 *
 *  Created on: Feb 13, 2018
 *      Author: bright
 */

#ifndef LIBENET_TOOLS_NETTOOL_H_
#define LIBENET_TOOLS_NETTOOL_H_


#include <netinet/in.h>
#include <stdint.h>


namespace enet {

class NetTool {
public:
	static uint64_t ntohll(uint64_t val);
	static uint64_t htonll(uint64_t val);

};

inline
uint64_t NetTool::ntohll(uint64_t val) {
	if(__BYTE_ORDER == __LITTLE_ENDIAN) {
		return (((uint64_t)ntohl((uint32_t)((val << 32) >> 32))) << 32) | ntohl((uint32_t)(val >> 32));
	}
	return val;
}

inline
uint64_t NetTool::htonll(uint64_t val) {
	if(__BYTE_ORDER == __LITTLE_ENDIAN) {
		return (((uint64_t)htonl((uint32_t)((val << 32) >> 32))) << 32) | htonl((uint32_t)(val >> 32));
	}
	return val;
}


}
#endif /* LIBENET_TOOLS_NETTOOL_H_ */
