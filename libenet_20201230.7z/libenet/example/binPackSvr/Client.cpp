/*
 * Client.cpp
 *
 *  Created on: Nov 15, 2020
 *      Author: bright
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <string>
using std::string;

#include "tools/BinPackTool.h"
#include "TCPSocket.h"
using namespace enet;

int main(int argc, char **argv) {
	if(argc < 5) {
		printf("usage: client ip port repeatTimes sendString\n");
		return 0;
	}
	char *ip = argv[1];
	int port = atoi(argv[2]);
	int repeatTimes = atoi(argv[3]);
	char *data = argv[4];
	int size = strlen(data);
	BinPack binReq;
	string binReqStr = BinPack::MakeFrame(string(data, size));

	int fd = TCPSocket::Connect(argv[1], port, true, -1);
	if(fd < 0) {
		printf("connect to %s:%d failed(%s)\n", ip, port, strerror(errno));
		return 0;
	}

	for(int i = 0; i < repeatTimes; ++i) {
		int sendSize = TCPSocket::SendAll(fd, binReqStr.data(), binReqStr.size());
		printf("i=%d,sendSize=%d,size=%ld,msg=%s\n", i, sendSize, binReqStr.size(), data);
		char msg[129];
		int recvSize = TCPSocket::Recv(fd, msg, sizeof(msg) - 1);
		if(recvSize > 0) {
			BinPack binRsp;
			int ret = binRsp.Parse(msg, recvSize);
			if(ret != 0) {
				printf("parse fail.ret=%d,recvSize=%d\n", ret, recvSize);
			} else {
				string msg(binRsp.Data(), binRsp.DataSize());
				printf("parse succ.ret=%d,recvSize=%d,msg=%s\n", ret, recvSize, msg.c_str());
			}
		} else {
			printf("recv failed.errMsg=%s\n", strerror(errno));
		}
		sleep(1);
	}
	TCPSocket::CloseSocket(fd);
	return 0;
}



