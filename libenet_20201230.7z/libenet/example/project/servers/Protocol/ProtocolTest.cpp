/*
 * ProtocolTest.cpp
 *
 *  Created on: Dec 7, 2020
 *      Author: bright
 */

#include "ProtocolTest.h"
#include "Common/ErrCode.h"

void ProtocolTest::GenReqTest1(Req &req, uint64_t key) {
	req.Reset(SVR_ID_TEST, key, "test1", true, this);
	Json::Value reqObj;
	reqObj["key0"] = 0;
	reqObj["key1"] = 1;
	JsonTool::WriteToStr(reqObj, req.req);
}

void ProtocolTest::GenReqTest2(Req &req, uint64_t key) {
	req.Reset(SVR_ID_TEST, key, "test2", true, this);
	Json::Value reqObj;
	reqObj["key0"] = 0;
	reqObj["key1"] = 1;
	JsonTool::WriteToStr(reqObj, req.req);
}

ErrCode ProtocolTest::OnPsp(AppHead &appHead) {
	bool parseResult = true;
	if(appHead.cmd == "test1") {
		rsp1.clear();
		parseResult = JsonTool::ParseFromStr(rsp1, appHead.data, appHead.dataSize);
	} else if(appHead.cmd == "test2") {
		rsp2.clear();
		parseResult = JsonTool::ParseFromStr(rsp2, appHead.data, appHead.dataSize);
	}
	return parseResult ? ERR_NONE : ERR_PARSE_DATA;
}
