/*
 * SessionImp.h
 *
 *  Created on: Nov 20, 2020
 *      Author: bright
 */

#ifndef PROJECT_SERVERS_TESTSVR_SESSION_H_
#define PROJECT_SERVERS_TESTSVR_SESSION_H_

#include "Lock.h"
#include "Net.h"
#include "tools/JsonCppTool.h"
using namespace enet;

#include "Common/AppPack.h"
#include "Common/CallStack.h"
#include "Common/ErrCode.h"

#include "Protocol/ProtocolTest.h"

#include <atomic>
#include <vector>
using std::vector;

#define REQ_TIMEOUT_MIN 1   // 请求超最小时间(单位秒)

class Session: public CallStack {
public:
public:
	typedef enum {
		TYPE_NULL,
		TYPE_SESSION,
		TYPE_STR
	}Type;

	typedef struct {
		Type type;
		int errCode;
		char errStr[64];
		AppHead appHead;

		Session *session;
		string str;
	}Result;

	static void Init(int maxSessionNum);
	static void UnInit();

	static Result ParseReq(const char *data, uint32_t size);
	static void Free(Session *sesssion);
	static int UsingSessionNum();

public:
	void MakeRsp();
	bool ParseReqData(AppHead &appHead);
	void SetConnInfo(Net *net, ConnId connId);
	void PrepareInvoke();

public:
	void AddReq(const Req &req);
	string MakeReq(uint32_t reqIndex, const Req &req);

	static void SendReq(Session *session);
	static void SendReqCallback(Net *net, ConnId connId, SendCode sendCode, const string &pack, uint32_t sendSize, void *userData);
	static void OnRsp(AppHead &appHead, uint64_t readTime);
	static Session* ProcessPendingSession(AppHead &appHead, bool isRsp);
	static void ProcessTimeoutReq();

public:
	// 通用字段
	Net *net;               // 网络实例
	ConnId connId;          // 链接Id
	pthread_t threadId;     // session所在线程id

	// 上游请求相关
	uint64_t readTime;      // 收到请求的时间
	string cmd;             // 请求命令字
	string req;             // 请求内容
	uint32_t tid;           // 事务id
	uint32_t rid;           // 请求id
	int32_t errCode;        // 发往上游的错误码
	string rsp;             // 发往上游的回包

	// 下游请求相关
	uint32_t reqSeq;
	bool needInterrupt;     // 是否需要中断调用堆栈
	vector<Req> reqVec;     // 发往下游的请求
	uint32_t finishNum;     // 完成个数
	uint64_t waitRspTime;   // 请求超时时间点(0时表示没有需要回包)

	// 定制字段
	Json::Value objReq;     // 请求对象
	Json::Value objRsp;     // 回包对象

public:  // 各个下游的请求协议
	ProtocolTest mTestSvr;  // 测试协议
};


#endif /* PROJECT_SERVERS_TESTSVR_SESSION_H_ */
