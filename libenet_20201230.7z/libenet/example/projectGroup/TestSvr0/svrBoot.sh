#/bin/bash

if [ $# -lt 1 ];then
	echo "usage $0 check|stop|start"
	exit
fi
cmd=$1
echo "cmd=$cmd"
grep 'listenIP' conf/svr.conf
grep 'listenPort' conf/svr.conf
grep 'regPath' conf/reg.conf
echo 



PID_FILE="bin/svr.pid"
QUIT_FILE="bin/quit.flag"

case $cmd in
"check")
	if [ ! -f "${PID_FILE}" ];then
		echo -e "\033[40;32m[OK] - svr is stopped\033[0m"
		exit
	fi
	pid=`cat ${PID_FILE}`
	echo "pid=$pid"
	ps axu|awk '{if($2==pid){print $0}}' pid=$pid
	netstat -nlp 2>/dev/null | grep $pid
	exist=`ps axu|awk '{if($2==pid){print $0}}' pid=$pid|wc -l`
	if [ $exist -eq 0 ];then
		echo -e "\033[40;31m[ERROR] - svr no exist.pid=$pid\033[0m"
		exit
	fi
	echo -e "\033[40;32m[OK] - svr is running.pid=$pid\033[0m"
	;;

"stop")
	pid=0
	if [ -f "${PID_FILE}" ];then
		pid=`cat ${PID_FILE}`
	else
		echo -e "\033[40;33m[WARN] - no find pid file: ${PID_FILE}\033[0m"
	fi

	touch ${QUIT_FILE}
	count=0
	while true; do
		if [ -f "${QUIT_FILE}" ];then
			sleep 1
			let count=count+1
			if [ $count -gt 3 ];then
				if [ $pid -gt 0 ];then
					echo -e "\033[40;31m[ERROR] - timeout and svr still running.pid=$pid\033[0m"
				else
					echo -e "\033[40;33m[WARN] - timeout and ${QUIT_FILE} file still exists.pid=$pid\033[0m"
				fi
				break
			fi
		else
			echo -e "\033[40;32m[OK] - svr is stopped.pid=$pid\033[0m"
			ps axu|awk '{if($2==pid){print $0}}' pid=$pid
			break
		fi
	done
	;;

"start")
	svrPath=`pwd`
	svrPath=${svrPath##*/}
	svrName=${svrPath%/*}
	if [ ! -f "bin/${svrName}" ];then
		echo -e "\033[40;31m[ERROR] - svr file no exists.file=bin/${svrName}\033[0m"
		exit
	fi

	if [ -f "${PID_FILE}" ];then
		pid=`cat ${PID_FILE}`
		echo "pid=$pid"
		ps axu|awk '{if($2==pid){print $0}}' pid=$pid
		netstat -nlp 2>/dev/null | grep $pid
		exist=`ps axu|awk '{if($2==pid){print $0}}' pid=$pid|wc -l`
		if [ $exist -gt 0 ];then
			echo -e "\033[40;32m[OK] - svr is running already.pid=$pid\033[0m"
			exit
		fi
	fi

	cd bin
	nohup ./${svrName} 2>/dev/null &
	cd - 1>/dev/null

	count=0
	while true; do
		if [ ! -f "${PID_FILE}" ];then
			sleep 1
			let count=count+1
			if [ $count -gt 3 ];then
				echo -e "\033[40;31m[ERROR] - no find pid file: ${PID_FILE}\033[0m"
				exit
			fi
		fi

		pid=`cat ${PID_FILE}`
		echo "pid=$pid"
		ps axu|awk '{if($2==pid){print $0}}' pid=$pid
		netstat -nlp 2>/dev/null | grep $pid
		exist=`ps axu|awk '{if($2==pid){print $0}}' pid=$pid|wc -l`
		if [ $exist -eq 0 ];then
			echo -e "\033[40;33m[WARN] - svr start failed.pid=$pid\033[0m"
			exit
		fi
		echo -e "\033[40;32m[OK] - svr is running.pid=$pid\033[0m"
		break
	done
	;;

esac