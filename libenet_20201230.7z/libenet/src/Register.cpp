/*
 * Register.cpp
 *
 *  Created on: Dec 3, 2020
 *      Author: bright
 */

#include "Register.h"
#ifdef DISCOVERY

#include <arpa/inet.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

#include "Net.h"
#include "tools/TimeTool.h"
using namespace enet;

#define CLIENT_ID_FILE ".ZookeeperClientId.txt"

Register::Register() {
	mNetConf = NULL;
	mHandler = NULL;

	memset(&mClientId, 0, sizeof(mClientId));
	LoadClientId();
	needClear = (mClientId.client_id != 0);
}

void Register::Init(Net *net, NetConf *netConf) {
	mNet = net;
	mNetConf = netConf;

	// 注册路径
	if(mNetConf->groupId >= 0) {
		char regPathKey[1024];
		sprintf(regPathKey, "regPath_%d", mNetConf->groupId);
		if(mNetConf->mKeyValMap.find(regPathKey) != mNetConf->mKeyValMap.end()) {
			mRegPath = mNetConf->mKeyValMap[regPathKey];
		}
	}
	// 生成本节点的注册信息
	if(!mRegPath.empty()) {
		// 注册信息
		if(mNetConf->routeType == ROUTE_RR) {
			// nothing
		} else if(mNetConf->routeType == ROUTE_HASH) {
			if(mNetConf->groupSize <= 0) {
				LOG_ERROR(REG_LOGGER, "Register::Init|groupSize invalid(hash route)");
				assert(false);
			}
			if(mNetConf->groupIndex < 0 || mNetConf->groupIndex >= mNetConf->groupSize) {
				LOG_ERROR(REG_LOGGER, "Register::Init|groupIndex invalid(hash route)");
				assert(false);
			}
			if(mNetConf->rangeFrom < 0 && mNetConf->rangeStop < 0) {
				mNetConf->rangeFrom = mNetConf->groupIndex;
				mNetConf->rangeStop = mNetConf->groupIndex + 1;
			}
			if(mNetConf->rangeFrom < 0 || mNetConf->rangeFrom >= mNetConf->rangeStop || mNetConf->rangeStop > mNetConf->groupSize) {
				LOG_ERROR(REG_LOGGER, "Register::Init|range invalid(hash route)");
				assert(false);
			}
		} else if(mNetConf->routeType == ROUTE_RANGE) {
			if(mNetConf->rangeFrom < 0 || mNetConf->rangeFrom >= mNetConf->rangeStop) {
				LOG_ERROR(REG_LOGGER, "Register::Init|range invalid(range route)");
				assert(false);
			}
		} else {
			LOG_ERROR(REG_LOGGER, "Register::Init|route type invalid.routeType="<<mNetConf->routeType);
			assert(false);
		}
		// 生成本节点的注册信息
		GenRegPath();
	}
	// 生成下游路径信息
	GenDownNodePath();
}

void Register::KeepConnect(uint32_t waitMS) {
	static int failCount = 0;
	// 没有注册地址或者注册路径
	if(mNetConf->regHost.empty() || mRegPath.empty()) {
		usleep(waitMS * 1000);
		return ;
	}
	if(mDownNodePathMap.empty() && mRegPathValue.empty()) {
		usleep(waitMS * 1000);
		return ;
	}
	if(mHandler == NULL) {
		Connect();
		return;
	}
	if(zoo_state(mHandler) == ZOO_CONNECTED_STATE) {
		OnConnected();
	}

	// 处理事件
	fd_set rfds, wfds;
    FD_ZERO(&rfds);
    FD_ZERO(&wfds);

	int fd;
	int interest;
	struct timeval tv;
	zookeeper_interest(mHandler, &fd, &interest, &tv);
	if (fd != -1) {
		if (interest & ZOOKEEPER_READ) {
			FD_SET(fd, &rfds);
		} else {
			FD_CLR(fd, &rfds);
		}
		if (interest & ZOOKEEPER_WRITE) {
			FD_SET(fd, &wfds);
		} else {
			FD_CLR(fd, &wfds);
		}
	}
	tv.tv_sec = 0;
	tv.tv_usec = waitMS * 1000;
	int ret = select(fd+1, &rfds, &wfds, NULL, &tv);
	int events = 0;
	if (ret > 0) {
		if (FD_ISSET(fd, &rfds)) {
			events |= ZOOKEEPER_READ;
		}
		if (FD_ISSET(fd, &wfds)) {
			events |= ZOOKEEPER_WRITE;
		}
	}
	ret = zookeeper_process(mHandler, events);
	if(ret != ZOK) {
		LOG_ERROR(REG_LOGGER, "Register::KeepConnect|process event ret="<<ret<<"("<<zerror(ret)<<"),failCount="<<failCount);
		usleep((++failCount < 10 ? failCount * 100000 : 1000000));
	} else {
		failCount = 0;
	}
}

void Register::CloseConnect() {
	// 关闭已有链接
	if(mHandler != NULL) {
		zookeeper_close(mHandler);
		mHandler = NULL;
		memset(&mClientId, 0, sizeof(mClientId));
		remove(CLIENT_ID_FILE);
	}
	// 重置节点的创建状态
	map<string , RegInfo*>::iterator it;
	for(it = mRegPathValue.begin(); it != mRegPathValue.end(); ++it) {
		it->second->Reset();
	}
	LOG_DEBUG(REG_LOGGER, "Register::CloseConnect|close connect");
}

void Register::SaveClientId() {
	const clientid_t *clientId = zoo_client_id(mHandler);
	if(mClientId.client_id == clientId->client_id) {
		return ;
	}
	mClientId = *clientId;

	bool saveSucc = false;
	FILE *fp = fopen(CLIENT_ID_FILE, "w");
	if(fp != NULL) {
		saveSucc = (fwrite(&mClientId, 1, sizeof(mClientId), fp) == sizeof(mClientId));
		fclose(fp);
	}
	if(saveSucc == false) {
		remove(CLIENT_ID_FILE);
		LOG_DEBUG(REG_LOGGER, "Register::SaveClientId|save clientId failed("<<strerror(errno)<<").remove clienId file="<<CLIENT_ID_FILE);
	}
}

void Register::LoadClientId() {
	bool loadSucc = false;
	FILE *fp = fopen(CLIENT_ID_FILE, "r");
    if (fp != NULL) {
    	loadSucc = (fread(&mClientId, 1, sizeof(mClientId), fp) == sizeof(mClientId));
        fclose(fp);
    }
    if(loadSucc == false) {
    	memset(&mClientId, 0, sizeof(mClientId));
		remove(CLIENT_ID_FILE);
		LOG_DEBUG(REG_LOGGER, "Register::LoadClientId|load clientId failed("<<strerror(errno)<<").remove clienId file="<<CLIENT_ID_FILE);
    }

}

static void GenNodeValue(NetConf *netConf, string &value) {
	char buff[1024];
	char *ptr = buff;
	*(uint32_t*)ptr = netConf->groupId; ptr += sizeof(uint32_t);
	*(uint32_t*)ptr = netConf->groupIndex; ptr += sizeof(uint32_t);
	*(uint32_t*)ptr = netConf->groupSize; ptr += sizeof(uint32_t);
	*(uint32_t*)ptr = netConf->routeType; ptr += sizeof(uint32_t);
	*(uint32_t*)ptr = netConf->rangeFrom; ptr += sizeof(uint32_t);
	*(uint32_t*)ptr = netConf->rangeStop; ptr += sizeof(uint32_t);
	*(uint32_t*)ptr = netConf->listenPort; ptr += sizeof(uint32_t);
	struct in_addr s;
	int ret = inet_pton(AF_INET, netConf->listenIP.c_str(), (void*)&s);
	assert(ret == 1);
	*(uint32_t*)ptr = s.s_addr; ptr += sizeof(uint32_t);

	value.assign(buff, ptr - buff);
}
static int ParseNodeValue(const char *buff, uint32_t size, DownNodeId &downNodeId) {
	const char *ptr = buff;
	int groupId = *(int*)ptr; ptr += sizeof(int);
	int groupIndex = *(int*)ptr; ptr += sizeof(int);
	int groupSize = *(int*)ptr; ptr += sizeof(int);
	int routeType = *(int*)ptr; ptr += sizeof(int);
	int rangeFrom = *(int*)ptr; ptr += sizeof(int);
	int rangeStop = *(int*)ptr; ptr += sizeof(int);
	int listenPort = *(int*)ptr; ptr += sizeof(int);
	char ip[32];
	struct in_addr s;
	s.s_addr = *(in_addr_t*)ptr; ptr += sizeof(in_addr_t);
	const char *ipPtr = inet_ntop(AF_INET, &s, ip, sizeof(ip));

	// 检查数据
	if(groupId < 0 || groupIndex < 0) {
		return -1;
	}
	if(routeType != ROUTE_RR && routeType != ROUTE_HASH && routeType != ROUTE_RANGE) {
		return -2;
	}
	if(routeType == ROUTE_HASH) {
		if(groupSize <= 0) {
			return -3;
		}
		if(rangeFrom < 0 || rangeFrom >= rangeStop || rangeStop > groupSize) {
			return -4;
		}
	}
	if(routeType == ROUTE_RANGE) {
		if(rangeFrom < 0 || rangeFrom >= rangeStop) {
			return -5;
		}
	}
	if(ipPtr == NULL || listenPort <= 0) {
		return -6;
	}
	if(ptr - buff > size) {
		return -7;
	}
	downNodeId.groupId = groupId;
	downNodeId.groupIndex = groupIndex;
	downNodeId.groupSize = groupSize;
	downNodeId.routeType = (RouteType)routeType;
	downNodeId.rangeFrom = rangeFrom;
	downNodeId.rangeStop = rangeStop;
	downNodeId.port = listenPort;
	downNodeId.host = ipPtr;
	return 0;
}

void Register::GenRegPath() {
	mRegPathValue.clear();
	char buff[1024];
	if(mNetConf->routeType == ROUTE_RR || mNetConf->routeType == ROUTE_RANGE) {
		snprintf(buff, 1024, "/%d_%d", mNetConf->groupId, mNetConf->groupIndex);
		string path = mRegPath;
		path.append(buff);

		string value;
		GenNodeValue(mNetConf, value);
		mRegPathValue[path] = new RegInfo(this, path, value);
	} else if(mNetConf->routeType == ROUTE_HASH) {
		// hash路由方式: 一个物理节点可以代理多个逻辑节点
		// 用作数据层时,开始时可以评估足够容量的逻辑节点,让较少的物理节点代理;当负载增加时可以扩展物理节点,而不用修改集群大小
		for(uint32_t groupIndex = mNetConf->rangeFrom; groupIndex < mNetConf->rangeStop; ++groupIndex) {
			snprintf(buff, 1024, "/%d_%d", mNetConf->groupId, groupIndex);
			string path = mRegPath;
			path.append(buff);

			char *ptr = buff;
			*(uint32_t*)ptr = mNetConf->groupId; ptr += sizeof(uint32_t);
			*(uint32_t*)ptr = groupIndex; ptr += sizeof(uint32_t);
			*(uint32_t*)ptr = mNetConf->groupSize; ptr += sizeof(uint32_t);
			*(uint32_t*)ptr = mNetConf->routeType; ptr += sizeof(uint32_t);
			*(uint32_t*)ptr = mNetConf->rangeFrom; ptr += sizeof(uint32_t);
			*(uint32_t*)ptr = mNetConf->rangeStop; ptr += sizeof(uint32_t);
			struct in_addr s;
			int ret = inet_pton(AF_INET, mNetConf->listenIP.c_str(), (void*)&s);
			assert(ret == 1);
			*(uint32_t*)ptr = s.s_addr; ptr += sizeof(uint32_t);
			*(uint32_t*)ptr = mNetConf->listenPort; ptr += sizeof(uint32_t);

			string value(buff, ptr - buff);
			mRegPathValue[path] = new RegInfo(this, path, value);
		}
	}
}

void Register::GenDownNodePath() {
	char regPathKey[128];
	for(set<uint32_t>::iterator it = mNetConf->downGroupIdSet.begin(); it != mNetConf->downGroupIdSet.end(); ++it) {
		sprintf(regPathKey, "regPath_%d", *it);
		if(mNetConf->mKeyValMap.find(regPathKey) == mNetConf->mKeyValMap.end()) {  // 该集群id没有配置注册路径
			LOG_ERROR(REG_LOGGER, "Register::GenDownNodePath|not find reg path conf item for ["<<regPathKey<<"]");
			assert(false);
		}
		string regPath = mNetConf->mKeyValMap[regPathKey];
		if(mDownNodePathMap.find(regPath) != mDownNodePathMap.end()) {
			continue;
		}
		mDownNodePathMap[regPath] = new RegInfo(this, regPath);
	}
}

void Register::Connect() {
	assert(mNetConf != NULL);
	// 创建zk handler
	mHandler = zookeeper_init(mNetConf->regHost.c_str(), WatchFunc, mNetConf->regSessionExpire * 1000, &mClientId, (void*)this, 0);
	if(mHandler == NULL) {
		LOG_ERROR(REG_LOGGER, "Register::Connect|create zookeeper handler failed.errMsg="<<strerror(errno));
		assert(false);
	}
}

void Register::OnConnected() {
	// 获取下游节点列表
	int count0 = GetDownNodeList();
	// 获取下游节点数据
	int count1 = GetDownNodeData();
	if(count0 != 0 || count1 != 0) {
		return ;
	}
	// 注册自己提供服务
	RegService();
}

void Register::OnChildrenChange(const char *path) {
	map<string , RegInfo*>::iterator it = mDownNodePathMap.find(path);
	if(it == mDownNodePathMap.end()) {
		LOG_WARN(REG_LOGGER, "Register::OnChildrenChange|not find down service path.path="<<path);
		return ;
	}
	GetChildren(it->second);
}

int Register::GetDownNodeList() {
	assert(mNetConf != NULL);
	assert(mHandler != NULL);

	int count = 0;  // 未完成个数
	uint64_t nowTs = TimeTool::TimeMS();
	for(map<string, RegInfo*>::iterator it = mDownNodePathMap.begin(); it != mDownNodePathMap.end(); ++it) {
		RegInfo *regInfo = it->second;
		if(regInfo->status != STATUS_FINISHED) {
			++count;
		}
		if(regInfo->status != STATUS_WAIT) {
			continue;
		}
		if(nowTs < regInfo->nextTs) {
			continue;
		}
		GetChildren(regInfo);
	}
	return count;
}

int Register::GetDownNodeData() {
	assert(mNetConf != NULL);
	assert(mHandler != NULL);

	int count = 0;  // 未完成个数
	uint64_t nowTs = TimeTool::TimeMS();
	for(map<string, RegInfo*>::iterator it = mDownNodeDataMap.begin(); it != mDownNodeDataMap.end(); ++it) {
		RegInfo *regInfo = it->second;
		if(regInfo->status != STATUS_FINISHED) {
			++count;
		}
		if(regInfo->status != STATUS_WAIT) {
			continue;
		}
		if(nowTs < regInfo->nextTs) {
			continue;
		}
		GetChildData(regInfo);
	}
	return count;
}

void Register::RegService() {
	assert(mNetConf != NULL);
	assert(mHandler != NULL);

	uint64_t nowTs = TimeTool::TimeMS();
	for(map<string , RegInfo*>::iterator it = mRegPathValue.begin(); it != mRegPathValue.end(); ++it) {
		RegInfo *regInfo = it->second;
		if(regInfo->status != STATUS_WAIT) {
			continue;
		}
		if(nowTs < regInfo->nextTs) {
			continue;
		}
		CreateNode(regInfo);
	}
}



void Register::OnGetChildren(RegInfo *regInfo, const struct String_vector *strings) {
	LOG_DEBUG(REG_LOGGER, "Register::OnGetChildren|path="<<regInfo->path<<",child node size="<<strings->count);
	regInfo->status = STATUS_FINISHED;
	// 更新子结点集合,消失的删除掉,新出现的添加新节点
	set<string> newChildrenNameSet;
	for(uint32_t i = 0; i < strings->count; ++i) {
		int groupId = -1, groupIndex = -1;
		int ret = sscanf(strings->data[i], "%d_%d", &groupId, &groupIndex);
		if(ret != 2 || groupId < 0 || groupIndex < 0) {
			continue ;
		}
		// 过滤下游结合,有配置的gourpId才处理
		if(mNetConf->downGroupIdSet.find(groupId) == mNetConf->downGroupIdSet.end()) {
			continue;
		}
		newChildrenNameSet.insert(strings->data[i]);
	}
	if(mDownNodeNameMap.find(regInfo->path) != mDownNodeNameMap.end()) {
		// 当前节点名字集合
		set<string> &curChildrenNameSet = mDownNodeNameMap[regInfo->path];
		for(set<string>::iterator it = curChildrenNameSet.begin(); it != curChildrenNameSet.end(); ++it) {
			string childName = *it;
			if(newChildrenNameSet.find(childName) == newChildrenNameSet.end()) {
				// 节点不存在,从下游服务中删除掉
				int groupId = -1, groupIndex = -1;
				sscanf(childName.c_str(), "%d_%d", &groupId, &groupIndex);
				LOG_DEBUG(REG_LOGGER, "Register::OnGetChildren|child node deleted.path="<<regInfo->path<<",childName="<<childName<<",groupId="<<groupId<<",groupIndex="<<groupIndex);
				// 删除节点服务信息
				mNet->DelDownNode(groupId, groupIndex);
				// 删除节点数据
				string childPath = regInfo->path + "/" + childName;
				delete mDownNodeDataMap[childPath];
				mDownNodeDataMap.erase(childPath);
			}
		}
	}
	mDownNodeNameMap[regInfo->path] = newChildrenNameSet;
	// 获取所有子结点数据
	GetChildrenData(regInfo);
}

void Register::GetChildrenData(RegInfo *regInfo) {
	set<string> &curChildrenNameSet = mDownNodeNameMap[regInfo->path];
	for(set<string>::iterator it = curChildrenNameSet.begin(); it != curChildrenNameSet.end(); ++it) {
		string childName = *it;
		string childPath = regInfo->path + "/" + childName;
		// 已有的节点不处理
		if(mDownNodeDataMap.find(childPath) != mDownNodeDataMap.end()) {
			continue;
		}
		// 添加新的节点
		RegInfo *childRegInfo = new RegInfo(this, childPath);
		mDownNodeDataMap[childPath] = childRegInfo;
		GetChildData(childRegInfo);
	}
}

void Register::OnGetChildData(RegInfo *regInfo) {
	DownNodeId downNodeId;
	int ret = ParseNodeValue(regInfo->value.c_str(), regInfo->value.size(), downNodeId);
	if(ret != 0) {
		LOG_ERROR(REG_LOGGER, "Register::OnGetChildData|parse node value failed.ret="<<ret<<",path="<<regInfo->path);
		return ;
	}
	ret = mNet->AddDownNode(downNodeId, NULL);
	if(ret < 0) {
		LOG_ERROR(REG_LOGGER, "Register::GetDataCompletion|add down node service failed.path="<<regInfo->path
					<<",groupId="<<downNodeId.groupId<<",groupIndex="<<downNodeId.groupIndex
					<<",groupSize="<<downNodeId.groupSize<<",routeType="<<downNodeId.routeType
					<<",rangeFrom="<<downNodeId.rangeFrom<<",rangeStop="<<downNodeId.rangeStop
					<<",host="<<downNodeId.host<<",port="<<downNodeId.port);
	} else if (ret == 0) {
		LOG_DEBUG(REG_LOGGER, "Register::GetDataCompletion|down node service already active.path="<<regInfo->path
					<<",groupId="<<downNodeId.groupId<<",groupIndex="<<downNodeId.groupIndex
					<<",groupSize="<<downNodeId.groupSize<<",routeType="<<downNodeId.routeType
					<<",rangeFrom="<<downNodeId.rangeFrom<<",rangeStop="<<downNodeId.rangeStop
					<<",host="<<downNodeId.host<<",port="<<downNodeId.port);
	} else {
		LOG_INFO(REG_LOGGER, "Register::GetDataCompletion|down node service add succ.path="<<regInfo->path
					<<",groupId="<<downNodeId.groupId<<",groupIndex="<<downNodeId.groupIndex
					<<",groupSize="<<downNodeId.groupSize<<",routeType="<<downNodeId.routeType
					<<",rangeFrom="<<downNodeId.rangeFrom<<",rangeStop="<<downNodeId.rangeStop
					<<",host="<<downNodeId.host<<",port="<<downNodeId.port);
	}
}

/////////////////////////////////////////////////
// 回调方法
static const char* TypeToStr(int type) {
	  if (type == ZOO_CREATED_EVENT)
	    return "CreateEvent";
	  if (type == ZOO_DELETED_EVENT)
	    return "DeleteEvent";
	  if (type == ZOO_CHANGED_EVENT)
	    return "ChangeEvent";
	  if (type == ZOO_CHILD_EVENT)
	    return "ChildEvent";
	  if (type == ZOO_SESSION_EVENT)
	    return "SessionEvent";
	  if (type == ZOO_NOTWATCHING_EVENT)
	    return "NotWatchinigEvent";

	  return "UnknownEvent";
}
static const char* StateToStr(int state) {
	  if (state == 0)
	    return "ClosedState";
	  if (state == ZOO_CONNECTING_STATE)
	    return "ConnectingState";
	  if (state == ZOO_ASSOCIATING_STATE)
	    return "AssociatingState";
	  if (state == ZOO_CONNECTED_STATE)
	    return "ConnectedStatus";
	  if (state == ZOO_READONLY_STATE)
	    return "ReadonlyState";
	  if (state == ZOO_EXPIRED_SESSION_STATE)
	    return "SessionExpiredState";
	  if (state == ZOO_AUTH_FAILED_STATE)
	    return "AuthFailedState";

	  return "InvalidState";
}

void Register::WatchFunc(zhandle_t *zh, int type, int state, const char *path, void *watcherCtx) {
	Register *regInst = (Register*)watcherCtx;

	LOG_DEBUG(REG_LOGGER, "Register::WatchFunc|type="<<type<<"("<<TypeToStr(type)<<"),state="<<state<<"("<<StateToStr(state)<<"),path="<<string(path?path:""));
	if (type == ZOO_SESSION_EVENT) {
		if (state == ZOO_CONNECTED_STATE) {
			if(regInst->needClear) {
				LOG_DEBUG(REG_LOGGER, "Register::WatchFunc|need clear session state");
				regInst->CloseConnect();
				regInst->Connect();
				regInst->needClear = false;
			} else {
				// 保存client id
				regInst->SaveClientId();
				regInst->OnConnected();
			}
		} else if (state == ZOO_EXPIRED_SESSION_STATE) {
			LOG_ERROR(REG_LOGGER, "Register::WatchFunc|session expired and go to reconnect");
			regInst->CloseConnect();
			regInst->Connect();
		} else if (state == ZOO_AUTH_FAILED_STATE) {
			LOG_ERROR(REG_LOGGER, "Register::WatchFunc|authentication failure");
			assert(false);
		}
	} else if(type == ZOO_CHILD_EVENT) {
		regInst->OnChildrenChange(path);
	}
}

void Register::CreateNode(RegInfo *regInfo) {
	int ret = zoo_acreate(mHandler, regInfo->path.c_str(), regInfo->value.data(), regInfo->value.size(), &ZOO_OPEN_ACL_UNSAFE, ZOO_EPHEMERAL, CreateCompletion, (void*)regInfo);
	if(ret != ZOK) {
		LOG_ERROR(REG_LOGGER, "Register::CreateNode|create node failed and wait to retry.ret="<<ret<<"("<<zerror(ret)<<"),path="<<regInfo->path);
	} else {
		regInfo->status = STATUS_PENDING;  // 创建中
		LOG_DEBUG(REG_LOGGER, "Register::CreateNode|create node and wait rsp.path="<<regInfo->path);
	}
}

void Register::GetChildren(RegInfo* regInfo) {
	int ret = zoo_aget_children(mHandler, regInfo->path.c_str(), 1, GetChildrenCompletion, (void*)regInfo);
	if(ret != ZOK) {
		LOG_ERROR(REG_LOGGER, "Register::GetChildren|get children failed and wait to retry.ret="<<ret<<"("<<zerror(ret)<<"),path="<<regInfo->path);
	} else {
		regInfo->status = STATUS_PENDING;  // 获取中
		LOG_DEBUG(REG_LOGGER, "Register::GetChildren|get children and wait rsp.path="<<regInfo->path);
	}
}

void Register::GetChildData(RegInfo *regInfo) {
	int ret = zoo_aget(mHandler, regInfo->path.c_str(), 0, GetDataCompletion, regInfo);
	if(ret != ZOK) {
		LOG_ERROR(REG_LOGGER, "Register::GetChildData|get child data failed and wait to retry.ret="<<ret<<"("<<zerror(ret)<<"),childPath="<<regInfo->path);
	} else {
		regInfo->status = STATUS_PENDING;
		LOG_INFO(REG_LOGGER, "Register::GetChildData|get child data and wait rsp.childPath="<<regInfo->path);
	}
}

void Register::CreateCompletion(int rc, const char *value, const void *data) {
	RegInfo *regInfo = (RegInfo*)data;
	string path(value?value:"");
	if(rc == ZOK) {
		regInfo->status = STATUS_FINISHED;
		LOG_INFO(REG_LOGGER, "Register::CreateCompletion|path="<<path<<",realPath="<<regInfo->path);
		return ;
	}

	regInfo->status = STATUS_WAIT;
	regInfo->tryCount++;
	regInfo->nextTs = TimeTool::TimeMS() + (regInfo->tryCount < 5 ? regInfo->tryCount * 200 : 1000);
	LOG_ERROR(REG_LOGGER, "Register::CreateCompletion|create node failed and wait to retry.rc="<<rc<<"("<<zerror(rc)<<"),path="<<path<<",realPath="<<regInfo->path);
}

void Register::GetChildrenCompletion(int rc, const struct String_vector *strings, const void *data) {
	RegInfo *regInfo = (RegInfo*)data;
	if(rc == ZOK) {
		regInfo->status = STATUS_FINISHED;
		regInfo->mRegister->OnGetChildren(regInfo, strings);
		return ;
	}

	regInfo->status = STATUS_WAIT;
	regInfo->tryCount++;
	regInfo->nextTs = TimeTool::TimeMS() + (regInfo->tryCount < 5 ? regInfo->tryCount * 200 : 1000);
	LOG_ERROR(REG_LOGGER, "Register::GetChildrenCompletion|get children failed and wait to retry.rc="<<rc<<"("<<zerror(rc)<<"),path="<<regInfo->path);
}

void Register::GetDataCompletion(int rc, const char *value, int value_len, const struct Stat *stat, const void *data) {
	RegInfo *regInfo = (RegInfo*)data;
	if(rc == ZOK) {
		regInfo->status = STATUS_FINISHED;
		regInfo->value.assign(value, value_len);
		regInfo->mRegister->OnGetChildData(regInfo);
		return ;
	}

	regInfo->status = STATUS_WAIT;
	regInfo->tryCount++;
	regInfo->nextTs = TimeTool::TimeMS() + (regInfo->tryCount < 5 ? regInfo->tryCount * 200 : 1000);
	LOG_ERROR(REG_LOGGER, "Register::GetDataCompletion|get data failed and wait to retry.rc="<<rc<<"("<<zerror(rc)<<"),path="<<regInfo->path);
}


#endif

