/*
 * Notifier.h
 *
 *  Created on: Nov 29, 2020
 *      Author: bright
 */

#ifndef SRC_NOTIFIER_H_
#define SRC_NOTIFIER_H_

#include <assert.h>
#include <event.h>
#include "TCPSocket.h"

namespace enet {

template<typename T>
class Notifier {

public:
	typedef void (T::*Method)();

	void Init(struct event_base *eventBase, T *inst, Method method) {
		assert(eventBase != NULL && inst != NULL && method != NULL);

		mEventBase = eventBase;
		mInst = inst;
		mMethod = method;

		int ret = pipe(pipeFd);
		assert(ret == 0);
		ret = TCPSocket::SetNoBlock(pipeFd[0]);
		assert(ret == 0);
		ret = event_assign(&mEvent, mEventBase, pipeFd[0], EV_PERSIST | EV_READ, _Callback, (void*)this);
		assert(ret == 0);
		ret = event_add(&mEvent, NULL);
		assert(ret == 0);
	}

	void Notify() {
		size_t ret = write(pipeFd[1], " ", 1);
		assert(ret == 1);
	}

private:
	int pipeFd[2];

	struct event mEvent;
	struct event_base *mEventBase;

	T *mInst;
	Method mMethod;

	static void _Callback(evutil_socket_t fd, short events, void* arg) {
		for(char buff[1024]; read(fd, buff, 1024) >= 1024; ) {}
		Notifier<T> *notify = (Notifier<T>*)arg;
		(notify->mInst->*notify->mMethod)();
	}
};


}
#endif /* SRC_NOTIFIER_H_ */
