/*
 * NetThreadPool.cpp
 *
 *  Created on: Nov 6, 2020
 *      Author: bright
 */
#include "NetThreadPool.h"

#include "NetThread.h"
using namespace enet;

Thread* NetThreadPool::CreateThread(int index) {
	NetThread *thread = new NetThread();
	thread->Init(index, "UpThread");
	return thread;
}

void NetThreadPool::DestroyThread(Thread* thread) {
	if(thread != NULL) {
		delete thread;
	}
}

// 分发链接
void NetThreadPool::DispatchConn(ConnId connId) {
	int index = ConnIdToFd(connId) % mThreads.size();
	((NetThread*)mThreads[index])->RecvConn(connId);
}




