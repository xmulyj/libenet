/*
 * Conn.h
 *
 *  Created on: Nov 5, 2020
 *      Author: bright
 */

#ifndef SRC_CONN_H_
#define SRC_CONN_H_

#include <event.h>

#include <atomic>
#include <list>
using std::atomic_flag;
using std::list;

#include "Lock.h"
#include "Net.h"
namespace enet {

class NetThread;

class SendNode {
public:
	string pack;          // 待发送数据
	uint32_t sendSize;    // 已发送长度
	uint64_t sendTime;    // 首次发送时间
	SendCallback cb;      // 回调接口
	void *userData;       // 回调用户数据

	SendNode(const string &pack, uint32_t sendSize, uint64_t sendTime, SendCallback cb, void *userData);
	void SendFinished(Net *net, ConnId connId, SendCode sendCode);
};

class Conn {
public:
	Conn();

	// 初始化链接
	void Init(NetThread *thread, ConnId connId);
	// 关闭链接
	void Close();

public:
	// 基础信息
	ConnId mConnId;            // 链接id
	NetThread *mThread;        // 所属线程
	uint64_t mActiveTs;        // 读写时间戳

	// 读缓冲区
	string mBuff;              // 缓冲区
	uint64_t mPackReadTs;      // 当前包接收时间戳
	int mPackSize;             // 一个完整数据包的长度
	void *mPackUserData;       // 分包时分包器设置的数据

	// 待发送数据列表
	atomic_flag mSendListLock = ATOMIC_FLAG_INIT;
	list<SendNode> mSendList;  // 待发送队列

	// 读写事件
	struct event mReadEvent;   // 可读事件
	struct event mWriteEvent;  // 可写事件
};


}
#endif /* SRC_CONN_H_ */
