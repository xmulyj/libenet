/*
 * NetConf.cpp
 *
 *  Created on: Nov 18, 2020
 *      Author: bright
 */
#include "NetConf.h"
#include "Net.h"
#include "TCPSocket.h"
using namespace enet;

#include <assert.h>
#include <string.h>

#include<iostream>
#include<fstream>
using namespace std;

IMPL_LOGGER_CLASS_NAME(NetConf, downLogger, "down");
IMPL_LOGGER_CLASS_NAME(NetConf, netLogger, "net");
IMPL_LOGGER_CLASS_NAME(NetConf, regLogger, "reg");
IMPL_LOGGER_CLASS_NAME(NetConf, svrLogger, "svr");

NetConf::NetConf() {
	listenIP = "";
	listenPort = 0;
	netThreadNum = 1;
	idleTime = 30;
	readTime = 3;
	writeTime = 3;
	maxPackLen = 4 * 1024;

	workerThreadNum = 1;
	queueSize = 128;
	maxSessionNum = 128;
	downIdleTime = 10;

	groupId = -1;
	routeType = ROUTE_NONE;
	groupSize = -1;
	groupIndex = -1;
	rangeFrom = -1;
	rangeStop = -1;
	regSessionExpire = 2;
	downGroupIdSet.clear();
}


// 从文件解析参数
void NetConf::ParseFromFile(const char *file) {
	ifstream f(file);
	char line[1024];
	assert(f.good());

	while(f.getline(line, sizeof(line), '\n')) {
		if(strchr(line, '#') != NULL || strchr(line, '[') != NULL) {
			continue;
		}
		char *key = line;
		char *split = strchr(line, '=');
		if(split == NULL) {
			continue;
		}
		*split = '\0';
		char *value = split + 1;
		// 去掉key左右两边的空白符
		while(*key == ' ' || *key == '\t') {
			++key;
		}
		if(key >= split) {
			continue;
		}
		split--;
		while(*split == ' ' || *split == '\t') {
			*split-- = '\0';
		}
		if(key >= split) {
			continue;
		}
		// 去掉value两边的空白符
		while(*value == ' ' || *value == '\t') {
			++value;
		}
		for(int i = strlen(value) - 1; i >= 0; --i) {
			if(value[i] == ' ' || value[i] == '\t' || value[i] == '\r' || value[i] == '\n') {
				value[i] = '\0';
			}
		}
		if(strlen(value) == 0) {
			continue;
		}
		// 保留key-value
		mKeyValMap[key] = value;
	}
	f.close();
	// 解析配置项
	for(map<string, string>::iterator it = mKeyValMap.begin(); it != mKeyValMap.end(); ++it) {
		if(it->first == "listenIP") {
			listenIP = it->second;
		} else if(it->first == "listenPort") {
			listenPort = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "netThreadNum") {
			netThreadNum = strtol(it->second.c_str(), NULL, 10);
			if(netThreadNum <= 0) {
				netThreadNum = 1;
			}
		} else if(it->first == "idleTime") {
			idleTime = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "readTime") {
			readTime = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "writeTime") {
			writeTime = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "maxPackLen") {
			maxPackLen = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "workerThreadNum") {
			workerThreadNum = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "queueSize") {
			queueSize = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "maxSessionNum") {
			maxSessionNum = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "downIdleTime") {
			downIdleTime = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "groupId") {
			groupId = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "groupSize") {
			groupSize = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "groupIndex") {
			groupIndex = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "routeType") {
			if(strcmp(it->second.c_str(), "rr") == 0) {
				routeType = ROUTE_RR;
			} else if(strcmp(it->second.c_str(), "hash") == 0) {
				routeType = ROUTE_HASH;
			} else if(strcmp(it->second.c_str(), "range") == 0) {
				routeType = ROUTE_RANGE;
			}
		} else if(it->first == "rangeFrom") {
			rangeFrom = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "rangeStop") {
			rangeStop = strtol(it->second.c_str(), NULL, 10);
		} else if(it->first == "regSessionExpire") {
			regSessionExpire = strtol(it->second.c_str(), NULL, 10);
			if(regSessionExpire <= 0) {
				regSessionExpire = 2;
			}
		} else if(it->first == "regHost") {
			regHost = it->second;
		}
	}
	// 下游节点groupId集合
	if(mKeyValMap.find("downGroupIdSet") != mKeyValMap.end()) {
		const char *splitPtr = NULL;
		const char *groupIdPtr = mKeyValMap["downGroupIdSet"].c_str();
		do {
			splitPtr = strchr(groupIdPtr, ',');
			int32_t groupId = -1;
			int n = sscanf(groupIdPtr, "%d", &groupId);
			if(n == 1 && groupId >= 0) {
				downGroupIdSet.insert(groupId);
			}
			groupIdPtr = splitPtr + 1;
		} while(splitPtr != NULL);
	}
}

