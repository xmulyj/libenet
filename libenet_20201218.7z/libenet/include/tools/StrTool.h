/*
 * StrTool.h
 *
 *  Created on: Jan 19, 2014
 *      Author: bright
 */

#ifndef LIBENET_TOOLS_STRTOOL_H_
#define LIBENET_TOOLS_STRTOOL_H_

#include <sstream>
#include <string>
using std::ostringstream;
using std::string;

namespace enet {

class StrTool {
public:
	template<typename T>
	static string ToStr(T v) {
		ostringstream os;
		os.str("");
		os<<v;
		return os.str();
	}
};



}
#endif /* INCLUDE_LIBENET_TOOLS_STRTOOL_H_ */
