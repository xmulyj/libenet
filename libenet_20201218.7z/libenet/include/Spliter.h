/*
 * Spliter.h
 *
 *  Created on: Nov 7, 2020
 *      Author: bright
 */

#ifndef INCLUDE_SPLITER_H_
#define INCLUDE_SPLITER_H_

namespace enet {

// 分包结果
typedef enum {
	SPLIT_FAIL,      // 分包失败
	SPLIT_WAIT,      // 等待更多数据
	SPLIT_SUCC       // 分包成功,packSize有效(包的数据不一定完整,只要能得到packSize就行)
}SplitStatus;

// 分包接口
class PackSpliter {
public:
	virtual ~PackSpliter() {}

	// 头部长度. 返回>0表示头部长度明确, 返回<=0表示头部长度不明确
	virtual int HeadSize() { return -1; }

	// 分包,获取一个完整数据包的长度
	// 参数:
	//     data: 数据
	//     dataSize: 数据长度
	//     packSize: 一个完整包的长度, 返回SPLIT_SUCC时有效
	//     packUserData: 当返回SPLIT_WAIT时,如果设置了非NULL的packUserData时, 当下次读取更多数据时重新调用Split方法用于辅助分包
	// 返回值:
	//     SPLIT_FAIL: 分包失败,数据错误等原因
	//     SPLIT_WAIT: 需要等待更多数据来解析packSize
	//     SPLIT_SUCC: 成功解析出完整包的包长packSize
	virtual SplitStatus Split(const char *data, int dataSize, int &packSize, void *&packUserData) = 0;

	// 当解析成功或者失败,或者链接结束时, 如果在Split设置了非NULL的packUserData,则本方法被调用用来释放packUserData
	// 参数:
	//     packUserData: Split方法中设置的packUserData
	virtual void Release(void *packUserData) = 0;
};


// 支持http GET和POST协议的分包
class HttpSpliter: public PackSpliter {
public:
	SplitStatus Split(const char *data, int dataSize, int &packSize, void *&packUserData);
	void Release(void *packUserData);
};


// 支持WebSocket的分包
class WebSocketSpliter: public PackSpliter {
public:
	SplitStatus Split(const char *data, int dataSize, int &packSize, void *&packUserData);
	void Release(void *packUserData);
};


// 支持二进制格式的分包: 制定长度的位置,长度是否包含头部
class BinPackSpliter: public PackSpliter {
public:
	int HeadSize() { return mHeadSize; }
	SplitStatus Split(const char *data, int dataSize, int &packSize, void *&packUserData);
	void Release(void *packUserData);

public:
	BinPackSpliter();

	// 初始化
	// 参数:
	//     sizeOffset: 保存长度的偏移位置
	//     bytes: 长度占用的字节数: 1/2/4字节
	//     headSize: 头部长度
	//     includeHeadSize: 长度是否保护头部的长度. false不包含, true包含
	void Init(unsigned int sizeOffset, unsigned int sizeBytes, unsigned int headSize, bool includeHeadSize);

private:
	unsigned int mSizeOffset;  // 保存长度的位置
	unsigned int mSizeBytes;   // 长度占用字节数
	unsigned int mHeadSize;    // 头部长度
	bool mIncludeHeadSize;     // 长度是否包含头部长度
};

}
#endif /* INCLUDE_SPLITER_H_ */
