/*
 * NetThreadPool.h
 *
 *  Created on: Nov 6, 2020
 *      Author: bright
 */

#ifndef SRC_NETTHREADPOOL_H_
#define SRC_NETTHREADPOOL_H_

#include "Net.h"
#include "Thread.h"
namespace enet {

class NetThreadPool: public ThreadPool {
	friend class XNet;

private:  // 实现接口方法
	// 创建线程实例
	Thread* CreateThread(int index);

	// 销毁线程实例
	void DestroyThread(Thread* thread);

public:
	// 分发链接
	void DispatchConn(ConnId connId);
};

}
#endif /* SRC_NETTHREADPOOL_H_ */
