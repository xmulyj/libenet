/*
 * Spliter.cpp
 *
 *  Created on: Nov 7, 2020
 *      Author: bright
 */
#include "Spliter.h"

#include "tools/NetTool.h"
using namespace enet;

#include <assert.h>
#include <ctype.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/////////////////////////////
//////    HttpSplier   //////
/////////////////////////////

// 查找"\r\n"的位置
static int FindCRLF(const char *dataBegin, const char *dataEnd) {
	const char *ptr = dataBegin;
	while(ptr < dataEnd -1) {
		if(ptr[0] == '\r' && ptr[1] == '\n') {
			return ptr - dataBegin;
		}
		++ptr;
	}
	return -1;
}

SplitStatus HttpSpliter::Split(const char *data, int dataSize, int &packSize, void *&packUserData) {
	if(dataSize < 4) {
		packUserData = NULL;
		return SPLIT_WAIT;
	}

	if(strncmp(data, "GET ", 4) == 0) {
		// 查找"\r\n\r\n"
		uint64_t lastPos = (packUserData == NULL ? 0: (uint64_t)packUserData);  // 上次正在解析的行的起始位置
		assert(lastPos >= 0 && lastPos <= dataSize);
		const char *dataBegin = data + lastPos;
		const char *dataEnd = data + dataSize;

		while(true) {
			int pos = FindCRLF(dataBegin, dataEnd);
			if(pos < 0) {
				packUserData = (void*)(dataBegin - data);
				return SPLIT_WAIT;
			}
			dataBegin += pos + 2;
			if(dataBegin[0] == '\r' && dataBegin[1] == '\n' && dataBegin + 2 <= dataEnd) {
				dataBegin += 2;
				packSize = dataBegin - data;
				packUserData = NULL;
				return SPLIT_SUCC;
			}
		}
	} else if(strncmp(data, "POST ", 5) == 0) {
		// 查找Content-Length: 123\r\n
		uint64_t lastPos = (packUserData == NULL ? 0: (uint64_t)packUserData);  // 上次正在解析的行的起始位置
		assert(lastPos >= 0 && lastPos <= dataSize);
		const char *dataBegin = data + lastPos;
		const char * const dataEnd = data + dataSize;

		while(true) {
			int pos = FindCRLF(dataBegin, dataEnd);
			if(pos < 0) {
				packUserData = (void*)(dataBegin - data);
				return SPLIT_WAIT;
			}
			if(strncmp(dataBegin, "Content-Length", 14) != 0) {
				dataBegin += pos + 2;
				continue;
			}
			packUserData = (void*)(dataBegin - data);  // 记录Content-Length的位置,下次直接跳到这里继续解析
			// 解析包长
			int contentLength = 0;
			const char *lineEnd = dataBegin + pos;
			while(dataBegin < lineEnd) {
				if(!isdigit(dataBegin[0])) {
					++dataBegin;
					continue;
				}
				contentLength = atol(dataBegin);
				if(contentLength < 0) {
					return SPLIT_FAIL;
				}
				break;
			}
			if(dataBegin >= lineEnd) {  // 读不到Content-Length的长度
				break;
			}
			// 获取包头长度
			dataBegin = lineEnd + 2;
			while(true) {
				int pos = FindCRLF(dataBegin, dataEnd);
				if(pos < 0) {
					return SPLIT_WAIT;
				}
				dataBegin += pos + 2;
				if(dataBegin[0] == '\r' && dataBegin[1] == '\n' && dataBegin + 2 <= dataEnd) {
					dataBegin += 2;
					int headSize = dataBegin - data;
					packSize = headSize + contentLength;
					packUserData = NULL;
					return SPLIT_SUCC;
				}
			}
		}
	}
	packUserData = NULL;
	return SPLIT_FAIL;
}

void HttpSpliter::Release(void *packUserData) {
	return ;
}


/////////////////////////////
////// WebSocketSplier //////
/////////////////////////////

SplitStatus WebSocketSpliter::Split(const char *data, int dataSize, int &packSize, void *&packUserData) {
	if(dataSize < 2) {
		return SPLIT_WAIT;
	}
	// http协议转换请求
	if(strncmp(data, "GET ", 4) == 0) {
		// 查找"\r\n\r\n"
		uint64_t lastPos = (packUserData == NULL ? 0: (uint64_t)packUserData);  // 上次正在解析的行的起始位置
		assert(lastPos >= 0 && lastPos <= dataSize);
		const char *dataBegin = data + lastPos;
		const char *dataEnd = data + dataSize;

		while(true) {
			int pos = FindCRLF(dataBegin, dataEnd);
			if(pos < 0) {
				packUserData = (void*)(dataBegin - data);
				return SPLIT_WAIT;
			}
			dataBegin += pos + 2;
			if(dataBegin[0] == '\r' && dataBegin[1] == '\n' && dataBegin + 2 <= dataEnd) {
				dataBegin += 2;
				packSize = dataBegin - data;
				packUserData = NULL;
				return SPLIT_SUCC;
			}
		}
	}
	// WebSocket二进制协议
	packUserData = NULL;
	uint32_t headSize = 2;
	uint32_t bodySize = 0;
	unsigned char *dataBegin = (unsigned char*)data;
	unsigned char msgOpcode = dataBegin[0]&0x0F;
	unsigned char msgFin = (dataBegin[0] >> 7)&0x01;
	unsigned char msgMask = (dataBegin[1] >> 7)&0x01;
	if(msgMask == 1) { //带有掩码,4个字节的key
		headSize += 4;
	}
	unsigned int lengthField = dataBegin[1]&0x7F;
	if(lengthField <= 125) {
		bodySize = lengthField;
	} else if(lengthField == 126) {
		headSize += 2;
		if(headSize > dataSize) {
			return SPLIT_WAIT;
		}
		unsigned short temp = *(unsigned short*)(dataBegin+2);  //浏览器里面发过来的是小端的,客户端发的是大端的)所以还是按规范来
		bodySize = ntohs(temp);
	} else if(lengthField == 127) {
		headSize += 8;
		if(headSize > dataSize) {
			return SPLIT_WAIT;
		}
		uint64_t temp = *(uint64_t*)(dataBegin+2);  //浏览器里面发过来的是小端的,客户端发的是大端的)所以还是按规范来
		bodySize = NetTool::ntohll(temp);
	} else {
		return SPLIT_FAIL;
	}
	packSize = headSize + bodySize;
	return (packSize < 0 ? SPLIT_FAIL : SPLIT_SUCC);
}

void WebSocketSpliter::Release(void *packUserData) {
	return ;
}


/////////////////////////////
//////     BinSplier   //////
/////////////////////////////
BinPackSpliter::BinPackSpliter() {
	mSizeOffset = -1;
	mSizeBytes = 0;
	mHeadSize = 0;
	mIncludeHeadSize = 0;
}

void BinPackSpliter::Init(unsigned int sizeOffset, unsigned int sizeBytes, unsigned int headSize, bool includeHeadSize) {
	assert(sizeBytes == 1 || sizeBytes == 2 || sizeBytes == 4);
	assert(sizeOffset + sizeBytes <= headSize);

	mSizeOffset = sizeOffset;
	mSizeBytes = sizeBytes;
	mHeadSize = headSize;
	mIncludeHeadSize = includeHeadSize;
}

SplitStatus BinPackSpliter::Split(const char *data, int dataSize, int &packSize, void *&packUserData) {
	assert(mSizeBytes > 0);
	packUserData = NULL;
	if(dataSize < mSizeOffset + mSizeBytes) {
		return SPLIT_WAIT;
	}
	int size = 0;
	if(mSizeBytes == 1) {
		unsigned char *ptrSize = (unsigned char *)(data + mSizeOffset);
		size = (int)*ptrSize;
	} else if(mSizeBytes == 2) {
		unsigned short *ptrSize = (unsigned short *)(data + mSizeOffset);
		size = (int)ntohs(*ptrSize);
	} else if(mSizeBytes == 4) {
		int *ptrSize = (int *)(data + mSizeOffset);
		size = (int)ntohl(*ptrSize);
	} else {
		assert(false);
	}
	if(mIncludeHeadSize == false) {
		size += mHeadSize;
	}
	packSize = size;
	return (packSize < 0 ? SPLIT_FAIL : SPLIT_SUCC);
}

void BinPackSpliter::Release(void *packUserData) {
	return ;
}
