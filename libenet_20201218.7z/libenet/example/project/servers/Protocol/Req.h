/*
 * Req.h
 *
 *  Created on: Dec 7, 2020
 *      Author: bright
 */

#ifndef PROJECT_SERVERS_PROTOCOL_REQ_H_
#define PROJECT_SERVERS_PROTOCOL_REQ_H_

#include <stdint.h>
#include <string>
#include <vector>
using std::string;
using std::vector;

#include "Common/AppPack.h"
#include "Common/ErrCode.h"
#include "Common/ServiceId.h"


class RspHandler {
public:
	virtual ~RspHandler() {}

	// 解析回包数据
	// 参数:
	//    data: 应用层回包数据
	//    size: 数据大小
	virtual ErrCode OnPsp(AppHead &appHead) = 0;
};

class Req {
public:
	uint32_t groupId;
	uint64_t key;
	string cmd;
	string req;

	bool needRsp;             // 是否需要回包. 当不需要回包时,该请求发送失败时将被忽略掉,不影响session的错误码
	bool finished;            // 是否已经处理完成
	int retCode;              // 返回码
	RspHandler *rspHandler;   // 回包处理器
	uint32_t reqTimeout;      // 回包超时时间(秒, 需要回包时有效, 0时使用默认的超时时间)

	void Reset(uint32_t groupId, uint64_t key, const char *cmd, bool needRsp, RspHandler *rspHandler, uint32_t reqTimeout = 2) {
		this->groupId = groupId;
		this->key = key;
		this->needRsp = needRsp;
		this->rspHandler = rspHandler;
		this->cmd = cmd;

		this->req.clear();
		this->finished = false;
		this->retCode = 0;
		this->reqTimeout = reqTimeout + 1;
	}
};

#endif /* PROJECT_SERVERS_PROTOCOL_REQ_H_ */
