/*
 * Server.h
 *
 *  Created on: Nov 17, 2020
 *      Author: bright
 */

#ifndef PROJECT_SERVERS_TESTSVR_SERVER_H_
#define PROJECT_SERVERS_TESTSVR_SERVER_H_

#include "Net.h"
using namespace enet;

#include "Session.h"

class Server: public TaskHandler {
public:
	bool OnTask(void *task);

public:
	Server(Net *net);
	~Server();

	NetHandler *mUpStreamHandler;
	NetHandler *mDownStreamHandler;

	int TaskNum();

public:
	Net *mNet;
};




#endif /* PROJECT_SERVERS_TESTSVR_SERVER_H_ */
