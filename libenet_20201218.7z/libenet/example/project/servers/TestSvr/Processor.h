/*
 * Processor.h
 *
 *  Created on: Nov 19, 2020
 *      Author: bright
 */

#ifndef PROJECT_SERVERS_TESTSVR_PROCESSOR_H_
#define PROJECT_SERVERS_TESTSVR_PROCESSOR_H_

#include "Session.h"

class Processor {
public:
	virtual ~Processor(){}
	virtual bool ReadOnly() = 0;  // 是否只读操作
	virtual void GenCallStack(Session *session) = 0;

	template<typename T>
	static Processor* NewInstance() {
		return new T;
	}
};

#define PUSH_METHOD(c, t, p) c->Push(new Invoker<t>(this, &t::p))
#define PUSH_FUNC(c, p) c->Push(new Invoker<void>(&p))

#define COMMIT(c) c->Commit()

#endif /* PROJECT_SERVERS_TESTSVR_PROCESSOR_H_ */
