/*
 * CmdSet.h
 *
 *  Created on: Nov 16, 2020
 *      Author: bright
 */

#ifndef APPLICATION_CMDSET_H_
#define APPLICATION_CMDSET_H_

#include <map>
#include <string>
using std::map;
using std::string;

#include "../Processor.h"

class CmdSet {
public:
	void LoadCmd();

	Processor* operator[](string cmd) {
		Processor* processor = NULL;
		map<string, Processor*>::iterator it = mCmdProcessorMap.find(cmd);
		if(it != mCmdProcessorMap.end()) {
			processor = it->second;
		}
		return processor;
	}

private:
	map<string, Processor*> mCmdProcessorMap;
};

#endif /* APPLICATION_CMDSET_H_ */
