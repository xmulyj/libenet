/*
 * Client.cpp
 *
 *  Created on: Nov 15, 2020
 *      Author: bright
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <string>
using std::string;

#include "tools/BinPackTool.h"
#include "TCPSocket.h"
using namespace enet;

#include "Common/AppPack.h"

int main(int argc, char **argv) {
	if(argc < 4) {
		printf("usage: client ip port repeatTimes\n");
		return 0;
	}
	char *ip = argv[1];
	int port = atoi(argv[2]);
	int repeatTimes = atoi(argv[3]);

	int fd = TCPSocket::Connect(argv[1], port, true, 1);
	if(fd < 0) {
		printf("connect to %s:%d failed(%s)\n", ip, port, strerror(errno));
		return 0;
	}
	char msg[1024];
	for(int i = 0; i < repeatTimes; ++i) {
		uint32_t tid = i;
		uint32_t rid = Rid(tid, 0);
		string cmd = "test";
		string data = "{\"key\":\"hello\"}";
		string reqStr = AppPack::MakeReq(tid, rid, cmd, data);
		int sendSize = TCPSocket::SendAll(fd, reqStr.data(), reqStr.size());
		printf("i=%d,sendSize=%d,size=%ld,msg=%s\n", i, sendSize, reqStr.size(), data.c_str());


		int recvSize = TCPSocket::Recv(fd, msg, sizeof(msg) - 1);
		if(recvSize <= 0) {
			printf("recv failed.ret=%d,errMsg=%s\n", recvSize, strerror(errno));
			continue;
		}
		AppHead appHead;
		int ret = AppPack::Parse(msg, recvSize, appHead);
		if(ret != 0) {
			printf("parse fail.ret=%d,recvSize=%d\n", ret, recvSize);
			continue;
		}
		string rspStr(appHead.data, appHead.dataSize);
		printf("parse succ.tid=%d,reqSeq=%d,reqIndex=%d,retCode=%d,cmd=%s,rsp=%s\n",
				appHead.tid, ReqSeq(appHead.rid), ReqIndex(appHead.rid),
				appHead.retCode, appHead.cmd.c_str(), rspStr.c_str());
		//sleep(1);
	}
	TCPSocket::CloseSocket(fd);
	return 0;
}



