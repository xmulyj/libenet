/*
 * Workers.cpp
 *
 *  Created on: Nov 9, 2020
 *      Author: bright
 */
#include "Workers.h"

#include "tools/LogTool.h"
using namespace enet;

#include <assert.h>


#define LOGGER(t) (t == 0 ? NetConf::netLogger : NetConf::downLogger)

namespace enet {

// 上游处理器代理类
#define GetHandler() (mType == 0 ? mWorkers->mUpStreamHandler: mWorkers->mDownStreamHandler)
class HandlerProxy: public NetHandler {
public:
	HandlerProxy(Workers *workers, int type) {
		mWorkers = workers;
		mType = type;
	}
	void OnConnected(Net *net, ConnId connId, const DownNodeId &downNodeId, void *userData) {
		NetHandler *handler = GetHandler();
		handler->OnConnected(net, connId, downNodeId, userData);
	}
	void OnClosed(Net *net, ConnId connId) {
		NetHandler *handler = GetHandler();
		handler->OnClosed(net, connId);
	}
	bool OnIdle(Net *net, ConnId connId) {
		NetHandler *handler = GetHandler();
		return handler->OnIdle(net, connId);
	}
	void OnTimer() {
		NetHandler *handler = GetHandler();
		handler->OnTimer();
	}
	bool OnPack(Net *net, ConnId connId, const string &pack, uint64_t readTime) {
		Workers::WorkerPack workerPack;
		workerPack.type = (mType == 0 ? Workers::TYPE_REQ : Workers::TYPE_RSP);
		workerPack.readTime = readTime;
		workerPack.netPack.net = net;
		workerPack.netPack.connId = connId;
		workerPack.netPack.pack = pack;

		int ret = 0;
		int retryCount = 0;
		while((ret = mWorkers->mBlockQueue.Push(workerPack)) != 0 && retryCount++ < 10) {
			LOG_ERROR(LOGGER(mType), "HandlerProxy::OnPack|push net pack failed,ret="<<ret<<",retryCount="<<retryCount<<".fd="<<ConnIdToFd(connId)<<",connId="<<connId);
			usleep(1000);
		}
		return (ret == 0 ? true : false);
	}

	bool OnTask(void *task) {
		if(task == NULL) {
			return false;
		}
		Workers::WorkerPack workerPack;
		workerPack.type = Workers::TYPE_TASK;
		workerPack.netPack.task = task;

		int ret = 0;
		int retryCount = 0;
		while((ret = mWorkers->mBlockQueue.Push(workerPack)) != 0 && retryCount++ < 10) {
			LOG_ERROR(LOGGER(mType), "HandlerProxy::OnTask|push task failed,ret="<<ret<<",retryCount="<<retryCount);
			usleep(1000);
		}
		assert(ret == 0);
		return true;
	}
private:
	int mType;  // 0代理上游, 1代理下游
	Workers *mWorkers;
};

// 工作线程
class WorkerThread: public Thread {
public:
	WorkerThread() {
		mWorkers = NULL;
	}

	void SetWorkers(Workers *workers) {
		mWorkers = workers;
	}

private:
	Workers *mWorkers;

private:  // 线程接口实现
	// 唤醒线程
	void WakeUp() {
		Workers::WorkerPack workerPack;
		workerPack.type = Workers::TYPE_NULL;

		int ret = 0;
		int retryCount = 0;
		while((ret = mWorkers->mBlockQueue.Push(workerPack)) != 0 && retryCount++ < 300) {
			LOG_ERROR(LOGGER(0), "WorkerThread::WakeUp|push null pack failed,ret="<<ret<<",retryCount="<<retryCount);
			sleep(1);
		}
	}

	// 运行线程
	int Run() {
		LOG_INFO(LOGGER(0), "WorkerThread::Run|begin.index="<<Index()<<",name="<<Name());
		bool needStop = false;
		uint32_t tryCount = 0;
		while(!IsNeedStop()) {
			// 获取数据包
			Workers::WorkerPack workerPack;
			LOG_DEBUG(LOGGER(0), "WorkerThread::Run|before pop");
			int ret = mWorkers->mBlockQueue.Pop(workerPack);
			LOG_DEBUG(LOGGER(0), "WorkerThread::Run|after pop.ret="<<ret);
			if(ret != 0) {
				uint32_t ts = ++tryCount * 1000;
				ts = (ts < 1000000 ? ts : 1000000);
				usleep(ts);
				LOG_ERROR(LOGGER(0), "WorkerThread::Run|pop net pack failed.ret="<<ret<<",tryCount="<<tryCount);
				continue;
			}
			tryCount = 0;
			// 处理数据包
			if(workerPack.type == Workers::TYPE_NULL) {
				LOG_INFO(LOGGER(0), "WorkerThread::Run|get break net pack");
				assert(IsNeedStop() == true);
				continue;
			} else if(workerPack.type == Workers::TYPE_REQ) {
				Workers::NetPack &netPack = workerPack.netPack;
				bool processRet = mWorkers->mUpStreamHandler->OnPack(netPack.net, netPack.connId, netPack.pack, workerPack.readTime);
				if(processRet == false) {
					LOG_ERROR(LOGGER(0), "WorkerThread::Run|process req pack failed and close connect.fd="<<ConnIdToFd(netPack.connId)<<",connId="<<netPack.connId);
					netPack.net->CloseConn(netPack.connId);
				}
				continue;
			} else if(workerPack.type == Workers::TYPE_RSP) {
				Workers::NetPack &netPack = workerPack.netPack;
				bool processRet = mWorkers->mDownStreamHandler->OnPack(netPack.net, netPack.connId, netPack.pack, workerPack.readTime);
				if(processRet == false) {
					LOG_ERROR(LOGGER(1), "WorkerThread::Run|process rsp pack failed and close connect.fd="<<ConnIdToFd(netPack.connId)<<",connId="<<netPack.connId);
					netPack.net->CloseConn(netPack.connId);
				}
				continue;
			} else if(workerPack.type == Workers::TYPE_TASK) {
				Workers::NetPack &netPack = workerPack.netPack;
				mWorkers->mDownStreamHandler->OnTask(netPack.task);
			} else {
				assert(false);
			}
		}
		LOG_ERROR(LOGGER(0), "WorkerThread::Run|end.index="<<Index()<<",name="<<Name());
		return 0;
	}
};

}  // namespace



// 创建线程实例
Thread* Workers::CreateThread(int index) {
	WorkerThread *thread = new WorkerThread();
	thread->Init(index, "WorkThread");
	thread->SetWorkers(this);
	return thread;
}

// 销毁线程实例
void Workers::DestroyThread(Thread* thread) {
	if(thread != NULL) {
		delete thread;
	}
}

Workers::Workers() {
	mUpStreamHandler = NULL;
	mDownStreamHandler = NULL;
	mUpStreamProxy = new HandlerProxy(this, 0);
	mDownStreamProxy = new HandlerProxy(this, 1);
}

NetHandler* Workers::ProxyUpStreamHandler(NetHandler *handler) {
	assert(handler != NULL);
	mUpStreamHandler = handler;
	return mUpStreamProxy;
}

NetHandler* Workers::ProxyDownStreamHandler(NetHandler *handler) {
	assert(handler != NULL);
	mDownStreamHandler = handler;
	return mDownStreamProxy;
}

void Workers::Start(unsigned threadNum, unsigned queueSize) {
	// 初始化阻塞队列
	assert(threadNum > 0 && queueSize > 0);
	int ret = mBlockQueue.Init(queueSize);
	assert(ret == 0);
	// 初始化线程池
	ThreadPool *threadPool = this;
	threadPool->Prepare(threadNum);
	threadPool->Start();
	// 检查所有线程是否都运行中
	bool allRunning = threadPool->WaitAllRunning(3);
	assert(allRunning == true);
	LOG_INFO(LOGGER(0), "Workers::Start|end");
}

