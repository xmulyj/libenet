/*
 * TCPSocket.cpp
 *
 *  Created on: 2014-6-26
 *      Author: bright
 */
// 支持跨平台: linux, windows
#include "TCPSocket.h"
using namespace enet;

#include <signal.h>

bool TCPSocket::IsIp(const char *addr) {
	if(addr == NULL) {
		return false;
	}
	int d[4];
	int32_t i = sscanf_s(addr, "%d.%d.%d.%d", &d[0], &d[1], &d[2], &d[3]);
	if(i != 4) {
		return false;
	}
	if(d[0] < 0 || d[0] > 255 || d[1] < 0 || d[1] > 255 || d[2] < 0 || d[2] > 255 || d[3] < 0 || d[3] > 255) {
		return false;
	}
	for(i = 0; addr[i] != '\0'; ++i) {  //判断是否有其他非法字符
		if(addr[i] != '.' && (addr[i] < '0' || addr[i] > '9')) {
			return false;
		}
	}
	return true;
}

int TCPSocket::CreateSocket(bool block/*=true*/, bool close_exec/*=false*/) {
	SOCKET fd = socket(AF_INET, SOCK_STREAM, 0);
	if(fd == INVALID_SOCKET) {
		return -1;
	}

#if defined(linux) || defined(__linux__)
	if(block == true && close_exec == false) {
		return fd;
	}
	int flags = fcntl(fd, F_GETFL, 0);
	if(flags == -1) {
		close(fd);
		return -2;
	}
	if(block == false) {  //no block
		flags |= O_NONBLOCK;
	}
	if(close_exec == true) {
		flags |= FD_CLOEXEC; //close on exec
	}
	if(fcntl(fd, F_SETFL, flags) == -1) {
		CloseSocket(fd);
		return -3;
	}
#elif defined(WIN32)
    if(block == false) {
        u_long iMode=1;
        if(ioctlsocket(fd, FIONBIO, &iMode) != 0) {
            CloseSocket(fd);
            return -3;
        }
    }

    //fd = _open_osfhandle(fd, 0);
#endif
	return fd;
}

int TCPSocket::CloseSocket(int fd) {
#if defined(linux) || defined(__linux__)
	return close(fd);
#elif defined(WIN32)
    return closesocket(fd);
#endif
}

int TCPSocket::Connect(const char *ip, int port, bool block/*=false*/, unsigned int wait_ms/*=0*/) {
	int fd = -1;
	if((fd = CreateSocket(block, true)) == -1) {
		return -1;
	}
	//连接到服务器
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	if(IsIp(ip)) {
		addr.sin_addr.s_addr = inet_addr(ip);
	} else {
		struct hostent *hent = gethostbyname(ip);
		if(hent == NULL || (hent->h_addrtype != AF_INET && hent->h_addrtype != AF_INET6)) {
			CloseSocket(fd);
			return -2;
		}
		addr.sin_addr = *((struct in_addr *) hent->h_addr);
	}
	if(connect(fd, (struct sockaddr*) &addr, sizeof(addr)) == 0) {  //成功直接返回
		return fd;
	}
	if(block || (!SOCKET_WOULDBLOCK && _errno_ != EINPROGRESS)) {
		CloseSocket(fd);
		return -3;
	}
	if(wait_ms == 0) {  //不需要等直接返回
		return fd;
	}
	//非阻塞并且等待建立连接
	struct timeval tval;
	fd_set rset, wset;
	FD_ZERO(&rset);
	FD_SET(fd, &rset);
	FD_ZERO(&wset);
	FD_SET(fd, &wset);

	tval.tv_sec = wait_ms / 1000;
	tval.tv_usec = (wait_ms % 1000) * 1000;
	int32_t tmp = select(fd + 1, (fd_set*) &rset, (fd_set*) &wset, (fd_set*) NULL, &tval);
	if(tmp <= 0) {
		CloseSocket(fd);
		return -4;
	}
	if(FD_ISSET(fd, &rset) || FD_ISSET(fd, &wset)) {
		int error;
		int len = sizeof(error);
#if defined(linux) || defined(__linux__)
		tmp = getsockopt(fd, SOL_SOCKET, SO_ERROR, (void*) &error, (socklen_t*) &len);
#elif defined(WIN32)
        tmp = getsockopt(fd, SOL_SOCKET, SO_ERROR, (char*)&error, (socklen_t*)&len);
#endif
		if(tmp < 0 || (tmp == 0 && error != 0)) {
			CloseSocket(fd);
			return -5;
		}
	}
	return fd;
}

int TCPSocket::Listen(int port, bool block/*=false*/, int backlog/*=128*/, bool reuse/*=true*/) {
	return Listen(NULL, port, block, backlog, reuse);
}

int TCPSocket::Listen(const char *ip, int port, bool block/*=false*/, int backlog/*=128*/, bool reuse/*=true*/) {
	int fd = CreateSocket(block, true);
	if(fd == -1) {
		return -1;
	}
	/*
	 #if defined(linux)
	 SOCKET handle = fd;
	 #elif defined(WIN32)
	 SOCKET handle = _get_osfhandle(fd);
	 #endif
	 */
	if(reuse == true) {
		int _reuse = 1;
#if defined(linux) || defined(__linux__)
		if(setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (const void*) &_reuse, sizeof(_reuse)) == -1)
#elif defined(WIN32)
        if(setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (const char*)&_reuse, sizeof(_reuse)) == -1)
#endif
				{
			CloseSocket(fd);
			return -2;
		}
	}
	//绑定到端口
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	if(ip == NULL || ip[0] == '\0') {
		addr.sin_addr.s_addr = htonl(INADDR_ANY);
	} else if(IsIp(ip)) {  //ip地址
		addr.sin_addr.s_addr = inet_addr(ip);
	} else {  //域名
		struct hostent *hent = gethostbyname(ip);
		if(hent == NULL || (hent->h_addrtype != AF_INET && hent->h_addrtype != AF_INET6)) {
			CloseSocket(fd);
			return -3;
		}
		addr.sin_addr = *((struct in_addr *) hent->h_addr);
	}
	if(bind(fd, (struct sockaddr*) &addr, sizeof(addr)) == -1) {
		CloseSocket(fd);
		return -4;
	}
	if(listen(fd, backlog) == -1) {
		CloseSocket(fd);
		return -5;
	}
	return fd;
}

int TCPSocket::Recv(int fd, char *buffer, int size) {
	while(true) {
		int temp = recv(fd, buffer, size, 0);
		if(temp < 0 && _errno_ == EINTR) {
			continue;
		}
		return temp;
	}
	return 0;
}

int TCPSocket::RecvAll(int fd, char *buffer, int size) {
	int total_recv = 0;
	while(total_recv < size) {
		int temp = recv(fd, buffer + total_recv, size - total_recv, 0);
		if(temp > 0) {
			total_recv += temp;
			continue;
		}
		if(temp == 0 || !SOCKET_WOULDBLOCK) {
			return temp;
		}
		continue;
	}
	return total_recv;
}

int TCPSocket::Send(int fd, const char *buffer, int size) {
#if defined(linux) || defined(__linux__)
	return send(fd, buffer, size, MSG_NOSIGNAL);
#elif defined(WIN32)
    return send(fd, buffer, size, 0);
#endif
}

int TCPSocket::SendAll(int fd, const char *buffer, int size) {
	int total_send = 0;
	while(total_send < size) {
#if defined(linux) || defined(__linux__)
		int temp = send(fd, buffer + total_send, size - total_send, MSG_NOSIGNAL);
#elif defined(WIN32)
        int temp = send(fd, buffer + total_send, size - total_send, 0);
#endif
		if(temp >= 0) {
			total_send += temp;
			continue;
		}
		if(_errno_ == EAGAIN || _errno_ == EINTR || _errno_ == EWOULDBLOCK) {
			continue;
		}
		return temp;
	}
	return total_send;
}

bool TCPSocket::IsBlock(int fd) {
#if defined(linux) || defined(__linux__)
	int flags = fcntl(fd, F_GETFL, 0);
	if(flags == -1) {
		return false;
	}
	return ((flags & O_NONBLOCK) == 0);
#elif defined(WIN32)
    //TODO
    return false;
#endif
}

int TCPSocket::SetBlock(int fd) {
#if defined(linux) || defined(__linux__)
	int flags = fcntl(fd, F_GETFL, 0);
	if(flags == -1) {
		return -1;
	}
	if((flags & O_NONBLOCK) == 0) {
		return 0;
	}
	flags &= ~O_NONBLOCK;
	if(fcntl(fd, F_SETFL, flags) == -1) {
		return -2;
	}
	return 0;
#elif defined(WIN32)
    u_long iMode = 0;
    if(ioctlsocket(fd, FIONBIO, &iMode) != 0) {
        return -1;
    }
    return 0;
#endif
}

int TCPSocket::SetNoBlock(int fd) {
#if defined(linux) || defined(__linux__)
	int flags = fcntl(fd, F_GETFL, 0);
	if(flags == -1) {
		return -1;
	}
	if((flags & O_NONBLOCK) != 0) {
		return 0;
	}
	flags |= O_NONBLOCK;
	if(fcntl(fd, F_SETFL, flags) == -1) {
		return -2;
	}
	return 0;
#elif defined(WIN32)
    u_long iMode = 1;
    if(ioctlsocket(fd, FIONBIO, &iMode) != 0) {
        return -1;
    }
    return 0;
#endif
}

int TCPSocket::SetCloseExec(int fd) {
#if defined(linux) || defined(__linux__)
	int flags = fcntl(fd, F_GETFL, 0);
	if(flags == -1) {
		return -1;
	}
	flags |= FD_CLOEXEC; //close on exec
	if(fcntl(fd, F_SETFL, flags) == -1) {
		return -2;
	}
#endif
	return 0;
}

int TCPSocket::Accept(int fd) {
	SOCKET new_fd = accept(fd, NULL, NULL);
	return new_fd >= 0 ? new_fd : -1;
}

int TCPSocket::Accept(int fd, struct sockaddr_in &peer_addr) {
	socklen_t peer_addr_len = sizeof(peer_addr);
	SOCKET new_fd = accept(fd, (struct sockaddr*)&peer_addr, &peer_addr_len);
	return new_fd >= 0 ? new_fd : -1;
}

int TCPSocket::WaitRead(int fd, int wait_ms/*=1000*/) {
	fd_set rset;
	FD_ZERO(&rset);
	FD_SET(fd, &rset);

	int32_t tmp = 0;
	if(wait_ms < 0) {
		tmp = select(fd + 1, (fd_set*) &rset, (fd_set*) NULL, (fd_set*) NULL, NULL);
	} else {
		struct timeval tval;
		tval.tv_sec = wait_ms / 1000;
		tval.tv_usec = (wait_ms % 1000) * 1000;
		tmp = select(fd + 1, (fd_set*) &rset, (fd_set*) NULL, (fd_set*) NULL, &tval);
	}
	if(tmp < 0) {  //错误
		return -1;
	} else if(tmp == 0) {  //超时
		return -2;
	}
	//可读(或者fd错误发生,让外部调用读数据相关函数发生错误时检查什么错误)
	return 0;
}

int TCPSocket::WaitWrite(int fd, int wait_ms/*=1000*/) {
	fd_set wset;
	FD_ZERO(&wset);
	FD_SET(fd, &wset);

	int32_t tmp = 0;
	if(wait_ms < 0) {
		tmp = select(fd + 1, (fd_set*) NULL, (fd_set*) &wset, (fd_set*) NULL, NULL);
	} else {
		struct timeval tval;
		tval.tv_sec = wait_ms / 1000;
		tval.tv_usec = (wait_ms % 1000) * 1000;
		tmp = select(fd + 1, (fd_set*) NULL, (fd_set*) &wset, (fd_set*) NULL, &tval);
	}
	if(tmp < 0) { //错误
		return -1;
	} else if(tmp == 0) { //超时
		return -2;
	}
	//可写(或者fd错误发生,让外部调用写数据相关函数发生错误时检查什么错误)
	return 0;
}

struct sockaddr_in TCPSocket::GetSocketAddr(int fd) {
	struct sockaddr_in addr;
    unsigned int len = sizeof(addr);
	memset(&addr, 0, len);
    getpeername(fd, (struct sockaddr*)&addr, &len);
    return addr;
}
