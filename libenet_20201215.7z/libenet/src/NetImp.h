/*
 * XNet.h
 *
 *  Created on: Nov 24, 2020
 *      Author: bright
 */

#ifndef SRC_NETIMP_H_
#define SRC_NETIMP_H_
#include "Net.h"

#include "Lock.h"
#include "NetThreadPool.h"
#include "Register.h"
#include "Workers.h"

namespace enet {

class NetThread;
class XNet: public Net {
	friend class NetThread;
	friend class WorkerThread;
	friend class Workers;

public:
	void Start();
	void Stop();
	void StopListen();
	void CloseConn(ConnId connId);

	int AddDownNode(const DownNodeId &downNodeId, void *userData = NULL);
	void DelDownNode(uint32_t groupId, uint16_t groupIndex);

	void SendRsp(ConnId connId, const string &pack, SendCallback cb = NULL, void *userData = NULL);
	void SendReq(uint32_t groupId, uint64_t key, const string &pack, SendCallback cb = NULL, void *userData = NULL);
	void SendReq(ConnId connId, const string &pack, SendCallback cb = NULL, void *userData = NULL);

	void KeepService(uint32_t waitMS = 100);
	void StopService();

public:
	XNet();

private:
	bool mActive;
	// 上游线程池
	NetThreadPool mNetThreadPool;
	void NetThreadPoolStart();
	// 下游线程
	NetThread *mDownStreamThread;
	// 工作者线程池
	Workers mWorkers;
	// 服务注册
	Register mRegister;
};


}
#endif /* SRC_NETIMP_H_ */
