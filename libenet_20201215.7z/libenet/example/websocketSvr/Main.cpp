/*
 * Main.cpp
 *
 *  Created on: Nov 7, 2020
 *      Author: bright
 */
#include <stdio.h>
#include <unistd.h>

#include "Net.h"
#include "Spliter.h"

#include "tools/LogTool.h"
#include "tools/WebSocketTool.h"
using namespace enet;

#define LOGGER NetConf::svrLogger

class WebSocketHandler: public NetHandler {
public:
	static void SendRspCallback(Net *net, ConnId connId, SendCode sendCode, const string &pack, uint32_t sendSize, void *userData) {
		if(sendCode == SEND_SUCC) {
			LOG_DEBUG(LOGGER, "UpStreamHandler::SendRspCallback|sendSucc,data="<<pack<<",size="<<pack.size()<<",sendSize="<<sendSize<<".connId="<<connId);
		} else {
			LOG_ERROR(LOGGER, "UpStreamHandler::SendRspCallback|sendError,data="<<pack<<",size="<<pack.size()<<",sendSize="<<sendSize<<".connId="<<connId);
		}
	}

public:
	bool OnPack(Net *net, ConnId connId, const string &pack, uint64_t readTime) {
		WebSocketFrame frame;
		bool ret = frame.Parse((char*)pack.data(), pack.size());
		if(ret == false) {
			return false;
		}
		if(frame.IsHandShakeFrame()) {
			LOG_DEBUG(LOGGER, "WebSocketHandler::OnPack|hand shake.connId="<<connId);
			HttpReq httpReq;
			if(httpReq.Parse(pack.data(), pack.size()) == false) {
				LOG_ERROR(LOGGER, "WebSocketHandler::OnPack|parse handshake req failed.req="<<pack);
				return -2;
			}
			string handShakeRsp = frame.MakeHandShakeRsp(httpReq);
			if(handShakeRsp.empty()) {
				LOG_ERROR(LOGGER, "WebSocketHandler::OnPack|make handshake rsp failed.req="<<pack);
				return -3;
			}
			net->SendRsp(connId, handShakeRsp, SendRspCallback, this);
			return true;
		}
		// 数据帧
		if(frame.IsWebSocketFrame()) {
			if(frame.FrameType() == WebSocketFrame::TYPE_PING) {
				LOG_DEBUG(LOGGER, "WebSocketHandler::OnPack|ping frame.isFin="<<frame.IsFinFrame()<<",type="<<frame.FrameType()<<",hasMask="<<frame.HasMask()<<".connId="<<connId);
				const string &frameStr = WebSocketFrame::PongFrame();
				net->SendRsp(connId, frameStr, SendRspCallback, this);
				return true;
			} else if(frame.FrameType() == WebSocketFrame::TYPE_CLOSE) {
				LOG_DEBUG(LOGGER, "WebSocketHandler::OnPack|close frame.isFin="<<frame.IsFinFrame()<<",type="<<frame.FrameType()<<",hasMask="<<frame.HasMask()
						<<",closeCode="<<frame.CloseCode()<<",closeReason="<<string(frame.CloseReason(), frame.CloseReasonSize())<<".connId="<<connId);

				if(true) {
					// 收到关闭帧后,发送数据对端有时有收到,有时没有...比较奇怪
					string msg = "recv close frame";
					//const char* maskKey = "FANG";
					const char* maskKey = NULL;
					string frameStr = WebSocketFrame::MakeFrame(WebSocketFrame::TYPE_TXT, msg, maskKey);
					net->SendRsp(connId, frameStr, SendRspCallback, this);
				}

				if(true) {
					// 回复close帧,浏览器正常关闭,转为closed状态
					const string &frameStr = WebSocketFrame::CloseFrame();
					net->SendRsp(connId, frameStr, SendRspCallback, this);
				}
				return true;
			}
			char *data = frame.Data();
			uint64_t size = frame.DataSize();
			string msg(data, size);
			LOG_DEBUG(LOGGER, "WebSocketHandler::OnPack|isFin="<<frame.IsFinFrame()<<",type="<<frame.FrameType()<<",hasMask="<<frame.HasMask()<<".msg="<<msg<<".connId="<<connId);
			msg += "[rsp]";

			const char* maskKey = NULL;  // 服务端的回包做掩码处理时, firefox可以正常处理. chrome会断开
			// maskKey = "FANG";

			string frameStr = WebSocketFrame::MakeFrame(WebSocketFrame::TYPE_TXT, msg, maskKey);
			net->SendRsp(connId, frameStr.data(), SendRspCallback, this);

			frame.Reset();
			ret = frame.Parse((char*)frameStr.data(), frameStr.size());

			// 发送close帧,浏览器回复close帧后转为closed状态
			if(true) {
				frameStr = WebSocketFrame::CloseFrame();
				net->SendRsp(connId, frameStr, SendRspCallback, this);
			}
			return true;
		}
		return 999;
	}

	bool OnIdle(Net *net, ConnId connId) {
		LOG_DEBUG(LOGGER, "WebSocketHandler::OnIdle|go to stop connect.connId="<<connId);
		return false;
	}

	void OnClosed(Net *net, ConnId connId) {
		LOG_DEBUG(LOGGER, "WebSocketHandler::OnClosed|connId="<<connId);
		return ;
	}
};

int main() {
	INIT_LOGGER("../conf/log4cplus.conf");

	WebSocketSpliter spliter;
	WebSocketHandler handler;
	Net *net = Net::New("../conf/net.conf");
	net->SetUpSteamHandler(&spliter, &handler);
	net->Start();

	while(true) {
		sleep(300);
		break;
	}
	LOG_INFO(LOGGER, "main|begin stop");
	net->Stop();
	LOG_INFO(LOGGER, "main|end stop");
	return 0;
}


