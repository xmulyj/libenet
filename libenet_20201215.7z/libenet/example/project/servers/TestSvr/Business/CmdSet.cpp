/*
 * CmdSet.cpp
 *
 *  Created on: Nov 19, 2020
 *      Author: bright
 */
#include "CmdSet.h"
#include "ProcessorPing.h"
#include "ProcessorTest.h"

#define REG_CMD(cmd, type) assert(mCmdProcessorMap.find(cmd) == mCmdProcessorMap.end()); \
mCmdProcessorMap.insert(std::make_pair(cmd, Processor::NewInstance<type>()))

void CmdSet::LoadCmd() {
	REG_CMD("ping", ProcessorPing);
	REG_CMD("test", ProcessorTest);
	REG_CMD("test1", ProcessorTest1);
	REG_CMD("test2", ProcessorTest2);
}
