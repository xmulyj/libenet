/*
 * Main.cpp
 *
 *  Created on: Nov 7, 2020
 *      Author: bright
 */
#include <stdio.h>
#include <unistd.h>

#include <Net.h>
using namespace enet;

#include "Server.h"

#define LOG_CONF    "../conf/log4cplus.conf"
#define LOGGER NetConf::svrLogger

#define NET_CONF    "../conf/net.conf"
#define SVR_CONF    "../conf/svr.conf"
#define REG_CONF    "../conf/reg.conf"
#define ZK_CONF     "../../zk.conf"

#define QUIT_FLAG   "quit.flag"

typedef enum {
	STATUS_RUNNING,
	STATUS_STOPPING,
	STATUS_STOPPED
}SvrStatus;
static SvrStatus gSvrStatus;

int main() {
	INIT_LOGGER(LOG_CONF);
	LOG_INFO(LOGGER, "main|start");
	gSvrStatus = STATUS_RUNNING;

	// 设置分包器
	BinPackSpliter spliter;
	spliter.Init(AppPack::SizeOffset, AppPack::SizeBytes, AppPack::HeadSize, AppPack::IncludeHeadSize);
	// 创建网络实例
	NetConf netConf;
	netConf.ParseFromFile(NET_CONF);
	netConf.ParseFromFile(SVR_CONF);
	netConf.ParseFromFile(REG_CONF);
	netConf.ParseFromFile(ZK_CONF);
	Net *net = Net::New(&netConf);
	// 创建服务器实例
	Server server(net);

	// 启动网络模块
	net->SetUpSteamHandler(&spliter, server.mUpStreamHandler);
	net->SetDownSteamHandler(&spliter, server.mDownStreamHandler);
	net->Start();

	// 添加下游节点
	/*
	sleep(1);
	DownNodeId downNode;
	downNode.groupId = netConf.groupId;
	downNode.groupSize = netConf.groupSize;
	downNode.groupIndex = netConf.groupIndex;
	downNode.routeType = (RouteType)netConf.routeType;
	downNode.rangeFrom = netConf.rangeFrom;
	downNode.rangeStop = netConf.rangeStop;
	downNode.host = net->GetConf()->listenIP;
	downNode.port = net->GetConf()->listenPort;
	int addRet = net->AddDownNode(downNode, NULL);
	LOG_INFO(LOGGER, "main|add down node ret="<<addRet<<",groupId="<<downNode.groupId<<",groupIndex="<<downNode.groupIndex
			<<",routeType="<<downNode.routeType<<",host="<<downNode.host<<",port="<<downNode.port);
	*/
	// 开始监控
	while(true) {
		// 保持注册服务
		if(gSvrStatus == STATUS_RUNNING) {
			net->KeepService();
		} else {
			usleep(100000);
		}
		// 检查任务数
		if(gSvrStatus != STATUS_RUNNING && server.TaskNum() == 0) {
			LOG_INFO(LOGGER, "main|not task is running now...");
			break;
		}
		// 检查退出标记
		if(gSvrStatus == STATUS_RUNNING && access(QUIT_FLAG, 0) == 0) {
			remove(QUIT_FLAG);
			LOG_INFO(LOGGER, "main|find quit flag...");
			gSvrStatus = STATUS_STOPPING;
			// 断开注册
			LOG_INFO(LOGGER, "main|stop reg...");
			net->StopService();
			// 断开监听
			usleep(500 * 1000);
			LOG_INFO(LOGGER, "main|stop listen...");
			net->StopListen();
		}
	}
	// 完全停止网络模块
	LOG_INFO(LOGGER, "main|stop net...");
	net->Stop();
	gSvrStatus = STATUS_STOPPED;

	LOG_INFO(LOGGER, "main|end");
	return 0;
}


