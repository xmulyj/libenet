/*
 * Invoker.h
 *
 *  Created on: Nov 20, 2020
 *      Author: bright
 */

#ifndef PROJECT_SERVERS_COMMON_INVOKER_H_
#define PROJECT_SERVERS_COMMON_INVOKER_H_


class Session;
class IInvoker {
public:
	virtual ~IInvoker(){}
	virtual void Invoke(Session *session) = 0;
};


template<typename T>
class Invoker: public IInvoker {
public:
	typedef void (T::*InvokerMethod)(Session *session);

	Invoker(T *instance, InvokerMethod method) {
		mInstance = instance;
		mMethod = method;
	}

	void Invoke(Session *session) {
		(mInstance->*mMethod)(session);
	}

private:
	T *mInstance;
	InvokerMethod mMethod;
};


template<>
class Invoker<void>: public IInvoker {
public:
	typedef void (*InvokerMethod)(Session *session);

	Invoker(InvokerMethod method) {
		mMethod = method;
	}

	void Invoke(Session *session) {
		(*mMethod)(session);
	}

private:
	InvokerMethod mMethod;
};



#endif /* PROJECT_SERVERS_COMMON_INVOKER_H_ */
