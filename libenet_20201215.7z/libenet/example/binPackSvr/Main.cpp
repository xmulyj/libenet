/*
 * Main.cpp
 *
 *  Created on: Nov 7, 2020
 *      Author: bright
 */
#include <stdio.h>
#include <unistd.h>

#include "Net.h"
#include "Spliter.h"

#include "tools/LogTool.h"
#include "tools/BinPackTool.h"
using namespace enet;

IMPL_LOGGER_NAME(logger, "server");

#define SEND_PING  true
#define SEND_REQ   true

class UpStreamHandler: public NetHandler {
public:
	static void SendRspCallback(Net *net, ConnId connId, SendCode sendCode, const string &pack, uint32_t sendSize, void *userData) {
		if(sendCode == SEND_SUCC) {
			LOG_DEBUG(logger, "UpStreamHandler::SendRspCallback|sendSucc,data="<<pack<<",size="<<pack.size()<<",sendSize="<<sendSize<<".connId="<<connId);
		} else {
			LOG_ERROR(logger, "UpStreamHandler::SendRspCallback|sendError,data="<<pack<<",size="<<pack.size()<<",sendSize="<<sendSize<<".connId="<<connId);
		}
	}
public:
	bool OnPack(Net *net, ConnId connId, const string &pack, uint64_t readTime) {
		BinPack binPack;
		if(binPack.Parse(pack.data(), pack.size()) != 0) {
			LOG_ERROR(logger, "UpStreamHandler::OnPack|parse pack failed.req="<<pack);
			return false;
		}

		string data(binPack.Data(), binPack.DataSize());
		LOG_DEBUG(logger, "UpStreamHandler::OnPack|isFin="<<binPack.IsFinFrame()<<",data="<<data<<".connId="<<connId);

		data += "[rsp]";
		string binPackStr = BinPack::MakeFrame(data);
		net->SendRsp(connId, binPackStr, SendRspCallback, this);
		return true;
	}

	bool OnIdle(Net *net, ConnId connId) {
		LOG_DEBUG(logger, "UpStreamHandler::OnIdle|go to stop connect.connId="<<connId);
		return false;
	}

	void OnClosed(Net *net, ConnId connId) {
		LOG_DEBUG(logger, "UpStreamHandler::OnClosed|connId="<<connId);
		return ;
	}
};

class DownStreamHandler: public NetHandler {
public:
	static void SendReqCallback(Net *net, ConnId connId, SendCode sendCode, const string &pack, uint32_t sendSize, void *userData) {
		if(sendCode == SEND_SUCC) {
			LOG_DEBUG(logger, "DownStreamHandler::SendReqCallback|sendSucc,data="<<pack<<",size="<<pack.size()<<",sendSize="<<sendSize<<".connId="<<connId);
		} else {
			LOG_ERROR(logger, "DownStreamHandler::SendReqCallback|sendError,data="<<pack<<",size="<<pack.size()<<",sendSize="<<sendSize<<".connId="<<connId);
		}
	}

public:
	bool OnPack(Net *net, ConnId connId, const string &pack, uint64_t readTime) {
		BinPack binPack;
		if(binPack.Parse(pack.data(), pack.size()) != 0) {
			LOG_ERROR(logger, "DownStreamHandler::OnPack|parse pack failed.req="<<pack);
			return false;
		}

		string data(binPack.Data(), binPack.DataSize());
		LOG_DEBUG(logger, "DownStreamHandler::OnPack|isFin="<<binPack.IsFinFrame()<<",data="<<data<<".connId="<<connId);
		return true;
	}

	bool OnIdle(Net *net, ConnId connId) {
		if(SEND_PING) {
			string data = "ping";
			string binPackStr = BinPack::MakeFrame(data);
			net->SendReq(connId, binPackStr, SendReqCallback, this);
			LOG_DEBUG(logger, "DownStreamHandler::OnIdle|send ping pack.connId="<<connId);
		}
		return true;
	}

	void OnTimer() {
		LOG_DEBUG(logger, "DownStreamHandler::OnTimer|timer trigger");
	}

	void OnConnected(Net *net, ConnId connId, const DownNodeId &downNodeId, void *userData) {
		LOG_DEBUG(logger, "DownStreamHandler::OnConnected|connId="<<connId<<",groupId="<<downNodeId.groupId<<",groupIndex="<<downNodeId.groupIndex
				<<",host="<<downNodeId.host<<",port="<<downNodeId.port);
		return ;
	}

	void OnClosed(Net *net, ConnId connId) {
		LOG_DEBUG(logger, "DownStreamHandler::OnClosed|connId="<<connId);
		return ;
	}
};

int main() {
	INIT_LOGGER("../conf/log4cplus.conf");

	BinPackSpliter spliter;
	spliter.Init(BinPack::SizeOffset, BinPack::SizeBytes, BinPack::HeadSize, BinPack::IncludeHeadSize);
	UpStreamHandler upStreamHandler;
	DownStreamHandler downStreamHandler;
	Net *net = Net::New("../conf/net.conf");
	net->SetUpSteamHandler(&spliter, &upStreamHandler);
	net->SetDownSteamHandler(&spliter, &downStreamHandler, 3000);
	net->Start();

	// 添加下游节点
	sleep(2);
	DownNodeId downNode;
	downNode.groupId = 1;
	downNode.groupIndex = 0;
	downNode.groupSize = 10;
	downNode.routeType = ROUTE_RR;
	downNode.rangeFrom = 0;
	downNode.rangeStop = 0;
	downNode.host = "127.0.0.1";
	downNode.port = 8080;
	int addRet = net->AddDownNode(downNode, NULL);
	LOG_INFO(logger, "main|add down node ret="<<addRet<<",groupId="<<downNode.groupId<<",groupIndex="<<downNode.groupIndex
			<<",routeType="<<downNode.routeType<<",host="<<downNode.host<<",port="<<downNode.port);

	while(true) {
		sleep(23);
		if(SEND_REQ) {
			string data = "hello,world";
			string binPackStr = BinPack::MakeFrame(data);
			net->SendReq(1, 0, binPackStr, DownStreamHandler::SendReqCallback, &downStreamHandler);
			LOG_DEBUG(logger, "main|send pack");
		}
		continue;
	}
	LOG_INFO(logger, "main|begin stop");
	net->Stop();
	LOG_INFO(logger, "main|end stop");
	return 0;
}


