/*
 * SHA1Tool.h
 *
 *  Created on: Nov 13, 2020
 *      Author: bright
 */

#ifndef INCLUDE_TOOLS_SHA1TOOL_H_
#define INCLUDE_TOOLS_SHA1TOOL_H_

#include <openssl/sha.h>
#include <string>
using std::string;

namespace enet {

class SHA1Tool {
public:
	static string SHA1Sum(const string &src, bool uppercase=true);
	static string SHA1Sum(const char *src, int size, bool uppercase=true);
};

inline
string SHA1Tool::SHA1Sum(const string &src, bool uppercase) {
	return SHA1Sum(src.data(), src.size(), uppercase);
}

inline
string SHA1Tool::SHA1Sum(const char *src, int size, bool uppercase) {
	string dst = "";
	if(src == NULL || size <= 0) {
		return dst;
	}

	unsigned char digest[SHA_DIGEST_LENGTH];
	SHA1((const unsigned char*)src, (size_t)size, digest);

	char buff[SHA_DIGEST_LENGTH * 2 + 1];
	const char *fmt = (uppercase ? "%02X" : "%02x");
	for(int i = 0; i < SHA_DIGEST_LENGTH; i++) {
		sprintf(buff + (i * 2), fmt, digest[i]);
	}
	buff[SHA_DIGEST_LENGTH * 2] = 0;

	dst = buff;
	return dst;
}

}
#endif /* INCLUDE_TOOLS_SHA1TOOL_H_ */
