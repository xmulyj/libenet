/*
 * TimeTool.h
 *
 *  Created on: Dec 28, 2019
 *      Author: bright
 */

#ifndef LIBENET_TOOLS_TIMETOOL_H_
#define LIBENET_TOOLS_TIMETOOL_H_

#include <unistd.h>
#include <stdint.h>
#include <time.h>
#include <sys/time.h>

namespace enet {

class TimeTool {
public:
	static uint64_t Time() {
		return time(NULL);
	}

	static uint64_t TimeMS() {
		timeval tv;
		gettimeofday(&tv, NULL);
		return tv.tv_sec * 1000 + tv.tv_usec / 1000;
	}

	static uint64_t TimeUS() {
		timeval tv;
		gettimeofday(&tv, NULL);
		return tv.tv_sec * 1000000 + tv.tv_usec;
	}
};

}

#endif /* LIBENET_TOOLS_TIMETOOL_H_ */
