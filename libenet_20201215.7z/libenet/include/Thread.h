/*
 * Thread.h
 *
 *  Created on: Dec 1, 2019
 *      Author: bright
 */

#ifndef LIBENET_THREAD_H_
#define LIBENET_THREAD_H_

#include <pthread.h>
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <sys/prctl.h>
#include <unistd.h>

#include <string>
#include <vector>
using std::string;
using std::vector;

namespace enet {

class Thread {
public:
	Thread() {
		Clear();
		Init();
	}

	Thread(int index, const char* name) {
		Clear();
		Init(index, name);
	}

	virtual ~Thread() {}

	void Init(int index = -1, const char* name = NULL) {
		assert(mRunning == false);
		mIndex = index;
		char threadName[32];
		if(name == NULL) {
			name = "thread";
		}
		if(index >= 0) {
			snprintf(threadName, sizeof(threadName), (const char*) "%s%d", name, index);
		} else {
			snprintf(threadName, sizeof(threadName), (const char*) "%s", name);
		}
		mName = threadName;
	}

	int Index() {
		return mIndex;
	}

	string Name() {
		return mName;
	}

	void Start() {
		if(mRunning) {
			return;
		}
		mRunning = true;
		mNeedStop = false;
		int ret = pthread_create(&mThreadId, NULL, _ThreadStart, (void*)this);
		assert(ret == 0);
	}

	void Stop() {
		mNeedStop = true;
		if(mRunning == true) {
			WakeUp();
		}
	}

	void Wait() {
		int count = 0;
		while(mRunning == true) {
			++count;
			usleep(500);
		}
		Clear();
	}

	void StopAndWait(){
		Stop();
		Wait();
	}

	bool IsRunning(){
		if(mRunning == true && pthread_kill(mThreadId, 0) == ESRCH) {
			Clear();
		}
		return mRunning;
	}

	bool IsNeedStop() {
		return mNeedStop;
	}

protected:
	int mIndex;
	string mName;
	pthread_t mThreadId;

	bool mRunning;
	bool mNeedStop;

	void Clear() {
		mRunning = false;
		mNeedStop = false;
		mThreadId = 0;
	}

	static void* _ThreadStart(void* arg) {
		assert(arg != NULL);
		Thread* thread = (Thread*)arg;
		prctl(PR_SET_NAME, thread->Name().c_str());
		thread->Run();
		thread->Clear();
		return NULL;
	}

public:
	// 唤醒线程
	virtual void WakeUp() {}
	// 运行线程
	virtual int Run() = 0;
};

class ThreadPool {
public:
	virtual ~ThreadPool() {}

	// 线程池大小
	int Size() {
		return mThreads.size();
	}

	// 获取正在运行的线程数
	int RunningNum() {
		int runningCount = 0;
		for(int i = 0; i < mThreads.size(); ++i) {
			if(mThreads[i]->IsRunning() == true) {
				++runningCount;
			}
		}
		return runningCount;
	}

	// 准备线程池: 只能调用一次, 创建size个线程实例
	void Prepare(int size) {
		assert(mThreads.size() == 0 && size > 0);
		mThreads.resize(size);
		for(uint32_t i = 0; i < mThreads.size(); ++i) {
			mThreads[i] = CreateThread(i);
			assert(mThreads[i] != NULL);
		}
	}

	// 启动所有线程
	void Start() {
		assert(mThreads.size() > 0 && mThreads[0] != NULL);
		for(uint32_t i = 0; i < mThreads.size(); ++i) {
			mThreads[i]->Start();
		}
	}

	// 停止所有线程
	void Stop() {
		for(uint32_t i = 0; i < mThreads.size(); ++i) {
			if(mThreads[i] != NULL) {
				mThreads[i]->Stop();
			}
		}
		while(true) {
			int runningCount = 0;
			for(uint32_t i = 0; i < mThreads.size(); ++i) {
				if(mThreads[i] != NULL && mThreads[i]->IsRunning()) {
					++runningCount;
				}
			}
			if(runningCount == 0) {
				break;
			}
			usleep(100);
		}
		for(uint32_t i = 0; i < mThreads.size(); ++i) {
			if(mThreads[i] != NULL) {
				DestroyThread(mThreads[i]);
				mThreads[i] = NULL;
			}
		}
	}

	bool WaitAllRunning(int sec = 3) {
		usleep(100);
		int checkCount = 0;
		while(RunningNum() != mThreads.size()) {
			usleep(100);
			++checkCount;
			if(sec >= 0 && checkCount >= sec * 10) {
				break;
			}
		}
		return RunningNum() == mThreads.size();
	}
protected:
	vector<Thread*> mThreads;

	// 创建线程实例
	virtual Thread* CreateThread(int index) = 0;

	// 销毁线程实例
	virtual void DestroyThread(Thread* thread) = 0;
};

}
#endif /* LIBENET_THREAD_H_ */
